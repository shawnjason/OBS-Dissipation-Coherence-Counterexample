#!/usr/bin/env python3
"""Independent exact-rate/Acb certificate for n11_exact_contraction."""

from __future__ import annotations

import json
from fractions import Fraction

from flint import acb, acb_mat, acb_poly, arb, ctx, fmpq, fmpq_mat, fmpq_poly

from OBS_matched_subdivision_exact_construction import (
    HERE, Z, contracted_rates, generator, polynomial_data, stationary_exact,
)
from OBS_matched_subdivision_interval_checker import (
    arb_bounds, arb_of_fraction, certified_roots, decimal_fraction_mid,
    encloses_in_epsilon, entropy_ball, fq, rat,
)


EPS = Fraction(1, 10**9)


def main() -> None:
    ctx.prec = 512
    q = generator(contracted_rates())
    pdata = polynomial_data()
    roots = certified_roots(pdata["contraction"])
    centers = [(decimal_fraction_mid(r.real), decimal_fraction_mid(r.imag)) for r in roots]
    if not all(encloses_in_epsilon(r, *c) for r, c in zip(roots, centers)):
        raise AssertionError("contraction root containment failed")

    # Independent matrix route: exact Fmpq matrix -> Acb approximate eigenvalue
    # enclosures.  The polynomial route remains the root-count certificate.
    q_exact = fmpq_mat([[fmpq(str(q[i, j])) for j in range(q.cols)] for i in range(q.rows)])
    matrix_eigs = acb_mat(q_exact).eig(tol=arb("1e-60"), algorithm="rump")
    if len(matrix_eigs) != 11:
        raise AssertionError("matrix eigensolver did not return all eleven simple roots")

    target = min(
        (i for i, (_, im) in enumerate(centers) if im > 0),
        key=lambda i: abs(float(centers[i][0]) + 6546.827434621505)
                      + abs(float(centers[i][1]) - 6281.559316241735),
    )
    tr, ti = centers[target]
    visibility_upper = tr + ti + 2 * EPS
    if not visibility_upper < 0:
        raise AssertionError("contraction visibility failure was not certified")
    competitor = max(
        (i for i in range(len(centers))
         if i != target and centers[i][1] >= 0
         and abs(centers[i][0]) + abs(centers[i][1]) > Fraction(1, 1000)),
        key=lambda i: centers[i][0],
    )
    cr, ci = centers[competitor]
    leadership_upper = tr + EPS - (cr - EPS)
    if not leadership_upper < 0:
        raise AssertionError("contraction leadership failure was not certified")

    pi = stationary_exact(q)
    sigma = entropy_ball(q, pi)
    if not sigma.upper() < arb(5400):
        raise AssertionError("coarse entropy bound failed")
    lambda_r_upper = -tr + EPS
    lambda_i_lower = ti - EPS
    y_upper = Fraction(5400) * lambda_r_upper / lambda_i_lower**2
    if not y_upper < 1:
        raise AssertionError("contraction labeled mode Y<1 was not certified")

    entries = []
    for i, (r, (re, im)) in enumerate(zip(roots, centers)):
        entries.append({
            "index": i, "center_re": rat(re), "center_im": rat(im),
            "enclosure_radius": rat(EPS), "acb_root_ball": str(r),
            "role": "labeled_rotating_target" if i == target else
                    "leading_competitor" if i == competitor else "other"
        })
    payload = {
        "system": "n11_exact_contraction",
        "lineage_exclusion": "n11_reoptimized_frontier is a distinct 13-edge cycle-rank-3 system and is not used",
        "root_count_certificate": {
            "method": "exact rational characteristic polynomial with certified Acb roots",
            "degree": 11, "all_roots_returned": True,
            "matrix_cross_check": "independent exact-matrix Acb eig_simple returned eleven simple enclosures"
        },
        "roots": entries,
        "target_index": target, "competitor_index": competitor,
        "stationary_weights_exact": [str(x) for x in pi],
        "entropy": arb_bounds(sigma),
        "failure_certificate": {
            "visibility_upper": rat(visibility_upper),
            "visibility_upper_decimal": f"{float(visibility_upper):.12f}",
            "leadership_gap_upper": rat(leadership_upper),
            "leadership_gap_upper_decimal": f"{float(leadership_upper):.12f}",
            "Y_upper_using_sigma_less_than_5400": rat(y_upper),
            "Y_upper_decimal": f"{float(y_upper):.12f}",
            "classification": "OBS-violating labeled mode (Y<1) but invalid counterexample because invisible and nonleading"
        },
        "endpoint_identity": {
            "exact_limit": "lim_{s->infinity} chi12(z,s)/s = chi11_exact_contraction(z)",
            "finite_root_form": "with t=1/s, t*chi12(z,1/t)=t*chi12(z,15531)+(1-15531*t)*chi11(z)",
            "target": "unique simple contraction root in the target enclosure; linked to the finite-s target by the continuation ledger in OBS_matched_subdivision_root_boxes.json"
        }
    }
    (HERE / "OBS_contraction_spectral_certificate.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload["failure_certificate"], indent=2))


if __name__ == "__main__":
    main()
