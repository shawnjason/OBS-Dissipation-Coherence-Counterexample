# Spectral-spacer theorem/obstruction branch

This directory contains the global spectral analysis of rank-one matched subdivision and a lineage firewall for the two noninterchangeable (n=11) systems.

## Deliverables

- `spectral_spacer_theorem.tex` — exact simple-root susceptibility, interval sufficient condition, exact Markov obstruction, and exceptional-point Puiseux law.
- `counterexample_ledger.csv` — exact rational/integer certificate rows for same-local-invariants opposite root motion.
- `HOSTILE_LINEAGE_AUDIT.md` — adversarial claim audit and translation firewall.
- `n11_translation_ledger.csv` — machine-readable separation of exact contraction, reoptimized frontier, and negative probes.
- `exact_counterexample_certificate.py` — dependency-free exact polynomial generator using `fractions.Fraction`.
- `search_local_invariant_counterexamples.py` — diagnostic search that led to the exact certificate; not itself a proof artifact.

## Main conclusion

Matched subdivision preserves the DC response and selected stationary path invariants, but finite-root direction depends on global Evans/adjoint data.  In particular, `n11_exact_contraction` and `n11_reoptimized_frontier` must remain separate systems.
