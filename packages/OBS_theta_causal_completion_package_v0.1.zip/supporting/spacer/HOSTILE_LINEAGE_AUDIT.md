# Hostile audit: spectral spacer theorem and n11 lineage

## Bottom line

The matched subdivision is an exact causal family, but it is not a local spectral-sign family.  Its finite-root motion is controlled by global Evans/adjoint data.  The package now contains an exact three-state Markov obstruction in which every listed local stationary invariant is identical but finite roots move in opposite real directions.

For the OBS lineage, the only honest matched state-removal control is `n11_exact_contraction`.  It is the $s\to\infty$ endpoint of the fixed state-12 subdivision family and has 12 undirected edges, cycle rank 2, and no $3--9$ chord.  The `n11_reoptimized_frontier` has 13 edges, cycle rank 3, contains the $3--9$ chord, and has independently reoptimized rates.  These objects must never share a row, label, or causal delta without an explicit system switch.

## What is proved

1. The exact boundary reduction is
   
   \[
   S(z,\varepsilon)=S_0(z)+\frac{\varepsilon z}{1+\varepsilon z}cd^{\mathsf T},
   \qquad \varepsilon=s^{-1}.
   \]

2. For any simple finite root with left/right boundary null vectors $y,x$,
   
   \[
   \frac{dz}{d\varepsilon}=-
   \frac{z(y^{\mathsf T}c)(d^{\mathsf T}x)/(1+\varepsilon z)^2}
   {y^{\mathsf T}[S_0'(z)+\varepsilon cd^{\mathsf T}/(1+\varepsilon z)^2]x}.
   \]

3. The derivative of a named relative gap is the real part of the difference of the two exact susceptibilities.  Global leadership additionally requires comparison with every other nonzero root.

4. A useful sufficient hypothesis is uniform interval separation of the two susceptibility enclosures, together with simple-root isolation.  This is checkable by interval eigenvector/Evans enclosures; it is not a sign claim from edge positivity.

5. At a generic real exceptional point, the two roots obey a square-root Puiseux law.  The simple-root susceptibility diverges there, so nearest-root continuation and ordinary differentiation are invalid across the EP.

6. The exact three-state counterexample proves that matched edge rates, split, stationary law on the edge, edge flow/current/traffic/affinity, inserted-mass law, DC response, and local resistance information do not determine the sign of a finite root's real motion.

7. The witness-specific exact/interval certificate in `work/theta_causal_completion/audit/gershgorin_window_certificate.json` establishes an open finite-$s$ region.  On the closed rational interval
   
   \[
   s\in[155289/10,155331/10]
   \]
   
   it gives visibility (>41.5928017977), leadership gap (>0.8214442832), and (Y<0.9029101455).  The exact contraction certificate instead gives visibility (<-265.2681179389) and leadership gap (<-590.9613786218).  Hence some crossover is forced between the certified finite window and the contraction endpoint, but this audit does not claim uniqueness or monotonicity of that crossover.

## Exact local-invariant obstruction

Use the fixed edge $0\to1=2$, $1\to0=1$, split $\alpha=1/2$, and context rates

| context | $0\to2$ | $2\to0$ | $1\to2$ | $2\to1$ |
|---|---:|---:|---:|---:|
| R | 1 | 2 | 2 | 1 |
| L | 2 | 3 | 2 | 1 |

Both generators are irreducible and doubly conservative, so (pi=(1/3,1/3,1/3)).  Both therefore have local forward flow (2/3), backward flow (1/3), current (1/3), traffic (1), affinity (log2), and inserted unnormalized mass (2/s).  The exact Evans pairs are

| context | $P(z)$ | $A(z)$ in $E=P+\frac{\varepsilon z}{1+\varepsilon z}A$ |
|---|---|---|
| R | $z(z^2+9z+21)$ | $3z^2+22z+42$ |
| L | $z(z+5)(z+6)$ | $3z^2+26z+60$ |

At $\varepsilon=0$, $z'=-zA/P'$.  Thus the positive-imaginary R root has $d\operatorname{Re}z/d\varepsilon=5/2$, while the L root $-5$ has derivative $-5$.  The other L root, $-6$, has derivative $12$.  The certificate is exact integer algebra and is reproducible by `exact_counterexample_certificate.py`.

Hostile conclusion: any proposed local rule must either include global context data under a different name or is false.  In particular, the sign cannot be inferred from positivity, current direction, affinity direction, local traffic, resistance increase, or inserted-state stationary mass.

## Data actually necessary for a relative-root claim

At a minimum, an honest claim about $G=\operatorname{Re}(z_{\rm rot}-z_{\rm rel})$ needs:

- a root-isolating definition of both branches over the parameter interval;
- left and right boundary null vectors, or equivalent full left/right eigenvectors;
- the complex couplings $(y^{\mathsf T}c)(d^{\mathsf T}x)$ for both roots;
- the Evans derivative denominators for both roots;
- exceptional-point exclusion, or a two-root Puiseux/contour treatment at an EP;
- the full competing spectrum if “leading” rather than merely “relative to a chosen root” is asserted;
- independent thermodynamic evaluation if a (Y) claim is added, since normalized stationary weights vary with (s).

The zero-frequency invariants are still valuable: they isolate the dynamic defect.  They do not determine its spectral phase.

## n11 translation firewall

| property | `n11_exact_contraction` | `n11_reoptimized_frontier` |
|---|---|---|
| causal relationship to n12 center | exact $s\to\infty$ endpoint | none within the fixed matched-$s$ family |
| removed state/segment | state 12 from (11-12-10) | separate Schur-shortening lineage followed by reoptimization |
| support | 12 undirected edges | 13 undirected edges |
| cycle rank | 2 | 3 |
| (3--9) chord | absent | present |
| rates | all unaffected rates frozen; exact effective pair | globally reoptimized floating rates |
| target scale | about (-6547+6282i) | about (-3.9624+3.9728i) |
| (Y) | (0.8958887<1) for the labeled continued mode | (1.0214186>1) |
| visibility | certified negative | small positive |
| leadership | certified negative | small positive in prior high-precision audit |
| permissible description | nonvisible, nonleading causal contraction control | separate reoptimized near-frontier |

The scale difference alone is a bright-line alarm.  A table that combines the contraction's topology with the reoptimized root or entropy has silently crossed systems.

## Hostile attacks and dispositions

| attack | disposition |
|---|---|
| “The inserted state preserves current and affinity, so it must move the rotating root right.” | False.  Proposition-level exact Markov counterexample. |
| “All rates are positive, so the susceptibility numerator has a fixed phase.” | False.  Left/right eigenvectors and Evans denominator are complex global data. |
| “The resistance defect has a fixed sign, hence root motion has a fixed sign.” | False.  Resistance is a zero/low-frequency scalar; the root samples a complex dynamic response. |
| “The finite-(s) witness and exact contraction have the same (Y<1), so the conjecture persists at n11.” | False.  The contraction's labeled mode is neither visible nor leading. |
| “The valid n11 point is what remains after removing state 12.” | False.  It has an extra chord and reoptimized rates; it is not the matched contraction. |
| “The certified endpoint signs prove monotone crossover.” | Not proved.  They prove at least one sign change by continuity, subject to correct root tracking. |
| “Different roots can be matched by nearest Euclidean distance through an EP.” | Unsafe.  Use a quadratic factor, contour count, or Puiseux continuation. |
| “A pairwise rotating-vs-relaxing gap proves global leadership.” | False unless all remaining roots are enclosed to the left. |
| “The exact three-state obstruction directly reproduces the OBS rotating/competitor taxonomy.” | Not claimed.  It disproves a general local finite-root sign rule; witness taxonomy still needs its own global data. |
| “The interval theorem here duplicates the matched-window certificate.” | No.  This branch consumes its endpoint facts only as lineage anchors; the proof and package stay in the audit/matched-window branches. |

## Claims deliberately not made

- No universal monotonicity in $s$ or $\varepsilon$.
- No uniqueness of the visibility or leadership boundary.
- No claim that local invariants are irrelevant to magnitude; only that they do not fix the sign.
- No claim that the reoptimized n11 frontier is a causal descendant under the single matched-state intervention.
- No claim that (Y<1) for an arbitrarily selected nonleading mode is an OBS counterexample.
- No claim that the simple-root formula remains valid at an exceptional point.

## Required package labels

Use these exact identifiers everywhere:

- `n12_matched_family_center`
- `n11_exact_contraction`
- `n11_reoptimized_frontier`

The structured values and translation rules are in `n11_translation_ledger.csv`.  Any downstream prose should cite that ledger before merging tables from separate branches.
