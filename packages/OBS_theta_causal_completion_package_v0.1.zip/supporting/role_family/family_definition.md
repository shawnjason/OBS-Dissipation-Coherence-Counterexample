# Constant-complexity role-layer family

For each integer `L>=2`, use branch vertices `u,v`, a three-edge reservoir
path, and two `L`-edge paths. Normalize five positive role masses
`m_u,m_v,M1,M2,M3`. Split `M1` between the two reservoir states by `rho`, and
assign `M2/(L-1)` and `M3/(L-1)` to the internal states of the two long paths.

Choose currents `J1,J2`, with `J3=-J1-J2`. The reservoir traffics are three
independent entrance/middle/exit values. Path 2 repeats one bulk traffic and
has one exit correction. Path 3 has one entrance correction and repeats one
bulk traffic. Every traffic must exceed its path-current magnitude. Rates are

\[
k_{ij}=(T_r+J_r)/(2\pi_i),\qquad
k_{ji}=(T_r-J_r)/(2\pi_j).
\]

The raw parameter count is 15 for every `L` (14 effective after common mass
scale). No list grows with `L`. The exact rational center is in
`exact_member.json`.
