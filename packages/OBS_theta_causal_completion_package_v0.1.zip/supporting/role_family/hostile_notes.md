# Hostile certification notes

* The exact member is rational; the certificate does not infer exactness from
  rounded eigenvalues.
* Each nonzero root is isolated by a disjoint rational disk. The Rouché test
  compares the exact linear Taylor term with exact rational upper bounds for
  all remaining terms. Eleven disks plus the exact stationary root exhaust
  the degree at `L=5`.
* Entropy is bounded with rational atanh series after power-of-two range
  reduction. Thus `Y<1` is not based on a floating logarithm.
* The member has a rigorous full-dimensional open successful neighborhood by
  simple-root persistence and continuity. No explicit rational half-width box
  was propagated, so `interval_box.json` must not be called a certified box.
* `L=3,4` are killed by certified negative visibility, not by a failed search.
  `L=10,11,12` are killed by certified `Y>1` despite positive visibility and
  leadership.
* The numerical upward trend through `L=20` is not proof for all `L>=10`.
  The missing uniform Chebyshev root bound is stated explicitly.
* The family uses 15 raw role parameters independent of `L`; no edgewise array
  is hidden in the definition.
