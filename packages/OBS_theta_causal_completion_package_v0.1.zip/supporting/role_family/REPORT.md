# Transparent role-layer certification report

## Exact family and member

The role-layer `Theta_(3,L,L)` family has 15 raw parameters independent of
`L`. The exact `L=5` member is rational and stored in `exact_member.json`.

## Exact certification route

`scripts/exact_member_certificate.py` constructs the generator over the
rationals, computes its exact characteristic polynomial, proves square
freeness, and isolates every nonzero root in disjoint rational Rouché disks.
It independently bounds every logarithm in entropy production by rational
atanh series. For `L=5` it proves

* `Y < 0.893201865220479`;
* visibility is strictly positive (lower bound approximately `59.21728`);
* the complete-spectrum leading gap is strictly positive (lower bound
  approximately `43.58682`).

This is an exact computational certificate, not a floating-spectrum claim.
An independent implementation reconstructs the family directly from its 15
parameters and diagonalizes at 80 decimal digits for `L=3,...,9`; its results
are in `data/independent_mpmath_L3_L9.json`. This is the second spectral route
and agrees with every exact classification, but it is labeled numerical.

## Open region

The exact polynomial is square-free and all three success inequalities have
strict certified margins. Analytic simple-root persistence and continuity of
entropy therefore prove a nonempty full-dimensional open successful
neighborhood in the 15 raw parameters. No explicit rational box width was
certified; `interval_box.json` records that limitation.

## Exact length classification

The same independent rational route gives:

* `L=3,4`: certified nonvisible;
* `L=5,6,7,8,9`: certified counterexamples with complete leadership;
* `L=10,11,12`: certified nonviolating (`Y>1`) despite visibility and
  leadership.

The finite successful window through 12 is therefore exact. The numerical
scan through 20 remains nonviolating after 10, but an all-`L>=10` theorem is
open. The exact entropy is affine and increasing in `L`; the missing lemma is
a uniform Chebyshev/transfer bound on `b_L^2/a_L`.

## Claim level

The transparent family, exact member, `L=5` success, open-neighborhood
existence, and classifications through `L=12` are proved/certified. An
explicit interval box and the infinite tail are not resolved.
