# Hostile causal-certificate audit

## Verdict

**PASS WITH AUDITABILITY OBJECTIONS.** I could not falsify the closed rational
window

\[
155289/10 \le s \le 155331/10.
\]

The exact affine family, rate positivity, normalized stationary law, entropy
scaling, fixed-disc inequalities, root labels, stationary-root exclusion,
visibility, leadership, and `Y<1` bound all survive independent reconstruction.
The exact contraction also survives, and it is not the reoptimized 11-state
frontier.

## Independent checks

- The four subdivision rates reconstruct the integer center checkpoint exactly:
  `977`, `14747`, `784`, `13636` at `s=15531`. The two DC-contracted rates are
  exactly `765968/15531` and `201090092/15531`. All present rates remain strictly
  positive on the closed interval.
- Solving the exact rational stationary equations reproduces the recorded old
  weights. The unnormalized inserted weight is `pi_12(15531)*15531/s` and the
  normalized law is `rho(s)/Z(s)`. Symbolically, `rho(s) Q(s)=0`; normalized
  stationarity and positivity were also checked separately at both endpoints.
- Every forward and reverse **unnormalized stationary edge flux** is independent
  of `s`. Therefore the unnormalized entropy production is constant and
  `sigma(s)=sigma(15531)/Z(s)`. Since `Z(s)` decreases, the upper endpoint is the
  entropy maximum. The independent upper balls are
  `sigma < 5288.219538122839` and `Y < 0.902910145442301`.
- The emitted rational similarity matrix was inverted exactly. All 12 fixed
  disks and all 66 pairwise disjointness inequalities were recomputed. The
  target is disk 1, its conjugate mate is disk 2, the stationary disk is 0, and
  the active nonstationary competitor is disk 3. The uniform exact lower bounds
  are visibility `41.5928017977979` and leadership `0.821444283285605`.
- Gershgorin usage is valid: for every allowed `s`, each actual transformed row
  disk is contained in its corresponding fixed disk. Pairwise disjoint fixed
  disks imply pairwise disjoint actual row disks, so the second Gershgorin
  theorem assigns exactly one eigenvalue to every disk. Because `Q(s) 1=0` and
  only disk 0 contains zero, exclusion of the stationary root is justified.
- As a distinct spectral route, I formed the exact degree-12 rational
  characteristic polynomial at **both** rational endpoints. Exact rational
  Rouche inequalities isolate all 12 roots in disjoint disks of radius `1e-5`.
  At the lower endpoint the certified visibility/leadership bounds are
  `49.00134551` / `41.78414637`; at the upper endpoint they are
  `49.03929163` / `41.67000396`.
- The exact contraction's support independently counts as 11 states, 12
  undirected edges, cycle rank 2, with no 3--9 chord. Its target is invisible
  and nonleading: visibility upper `-265.268117938985`, leadership upper
  `-590.961378621862`. The separately reoptimized frontier independently counts
  as 11 states, 13 edges, cycle rank 3, and does contain the 3--9 chord.

## Precise objections

1. `gershgorin_window_certificate.py` computes `target_mate_index` and
   `stationary_index` but drops both fields from the emitted
   `window_certificate` JSON.
2. `verify_exact_gershgorin_certificate.py` trusts the emitted target and
   competitor labels. It never reconstructs the target mate or stationary disk,
   so its leadership check does not itself verify that the excluded roots are
   exactly the conjugate mate and the stationary root.
3. The producer's docstring states the one-root-per-fixed-disk conclusion, but
   the JSON/transcript does not record the actual-row-disk containment argument
   needed before applying the second Gershgorin theorem.

These are certificate-interface and verifier-coverage defects, not discovered
counterexamples. `hostile_verify.py` closes all three independently. Exact
machine-readable results are in `hostile_verification.json`.
