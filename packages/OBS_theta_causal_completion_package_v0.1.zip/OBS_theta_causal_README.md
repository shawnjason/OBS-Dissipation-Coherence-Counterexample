# OBS theta causal completion package v0.1

## Outcome

`RESOLVED — CERTIFIED CAUSAL WINDOW`

For the exact matched subdivision

`11→12=977`, `12→11=14747*s/15531`,
`12→10=784*s/15531`, `10→12=13636`,

every `s` in the closed interval `[15530,15532]` is a rigorously certified
OBS counterexample.  Uniform primary-certificate margins are

- visibility `> 47.020348992241`;
- complete-spectrum leadership `> 39.727092946595`;
- `Y < 0.901947534017196`.

The same invariantly continued target is invisible for every `s>=158828` and
is invisible and nonleading at the exact 11-state contraction `s=∞`.  Exact DC
response, unnormalized stationary current, path affinity, and unnormalized
segment entropy are matched; the rank-one finite-frequency response changes.

Read `OBS_theta_causal_completion_report.md` for the theorem, proof levels,
secondary role-family results, global obstruction, and limitations.

## One-command reproduction

Python 3.11 or newer is recommended.  From an extracted package directory:

```powershell
python -m pip install -r requirements.txt
powershell -ExecutionPolicy Bypass -File .\run_all_checks.ps1 -PythonExe python
```

If a specific interpreter is required:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_all_checks.ps1 -PythonExe C:\path\to\python.exe
```

The command reconstructs the exact family, reruns the uniform Rouché window,
reruns the exact contraction spectrum, checks the independent exact-similarity
certificate without an eigensolver, certifies the role member and every listed
length through 12, audits the explicit-box claim firewall, and verifies the
exact local-invariant obstruction.  Any failed assertion or checker exit code
terminates the run.

For this workspace's bundled runtime, the verified invocation is recorded in
`supporting/audit/run_all_checks_transcript.txt`.

## Certificate map

- `OBS_matched_subdivision_exact_construction.py`: exact family, stationary
  law, response, and characteristic-polynomial identities.
- `OBS_matched_subdivision_interval_checker.py`: primary uniform rational
  Rouché proof on `[15530,15532]` and branch-continuation ledger.
- `OBS_contraction_spectral_certificate.py`: complete exact contraction
  spectrum and strict failure margins.
- `OBS_independent_spectral_audit.py`: independent exact rational similarity
  and Gershgorin verification on `[155289/10,155331/10]`, without eigensolving.
- `OBS_spectral_spacer_theorem.tex` and its exact counterexample ledger: global
  susceptibility condition, exceptional-point law, and refutation of any
  local-invariant-only sign rule.
- `OBS_role_layer_exact_checker.py`: exact rational role-family member and
  fixed-length certificates.
- `OBS_role_layer_interval_checker.py`: verifies the certified exact member and
  prevents an explicit-box overclaim.
- `OBS_theta_causal_theorem_ledger.csv`: all claims with the required proof
  level tags.
- `OBS_theta_lineage_manifest.csv`: input hashes and the firewall between the
  two noninterchangeable 11-state systems.

## Scope firewall

The package proves a witness-specific causal window, not a universal monotone
subdivision theorem.  The explicit rational full-dimensional role-family box
and the all-`L>=10` failure theorem remain open.  The available predecessor is
v0.2; the corrected v0.2.1 archive named by the assignment was absent locally,
so its correction is imported only from the frozen prompt and no archive hash
is invented.
