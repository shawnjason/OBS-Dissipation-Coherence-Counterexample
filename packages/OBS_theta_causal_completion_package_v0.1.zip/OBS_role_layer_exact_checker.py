#!/usr/bin/env python3
"""Exact rational characteristic polynomial, Rouche disks, and log bound."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json, math
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'OBS_role_layer_exact_member.json').read_text())['parameters']
f=lambda x:F(P[x])

def build(L=5):
 raw=[f(x) for x in ('m_u','m_v','M1','M2','M3')]; Z=sum(raw)
 pi=[raw[0]/Z,raw[1]/Z,f('M1')*f('rho')/Z,f('M1')*(1-f('rho'))/Z]
 pi += [f('M2')/(L-1)/Z]*(L-1)+[f('M3')/(L-1)/Z]*(L-1)
 paths=[[0,2,3,1],[0,*range(4,L+3),1],[0,*range(L+3,2*L+2),1]]
 Js=[f('J1'),f('J2'),-f('J1')-f('J2')]
 Ts=[[f('T1_in'),f('T1_mid'),f('T1_out')],
     [f('T2_bulk')]*(L-1)+[f('T2_exit')],
     [f('T3_entry')]+[f('T3_bulk')]*(L-1)]
 n=2*L+2;k=[[F(0) for _ in range(n)]for _ in range(n)]
 for ns,J,ts in zip(paths,Js,Ts):
  for a,b,T in zip(ns,ns[1:],ts):
   assert T>abs(J);k[a][b]=(T+J)/(2*pi[a]);k[b][a]=(T-J)/(2*pi[b])
 q=[row[:] for row in k]
 for i in range(n):q[i][i]=-sum(q[i])
 return pi,k,q

def cpow(c,n):
 out=(F(1),F(0))
 for _ in range(n):out=(out[0]*c[0]-out[1]*c[1],out[0]*c[1]+out[1]*c[0])
 return out
def cadd(a,b):return(a[0]+b[0],a[1]+b[1])
def cmul(a,b):return(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def up(a):return abs(a[0])+abs(a[1])
def low(a):return max(abs(a[0]),abs(a[1]))

def taylor(asc,c):
 n=len(asc)-1;out=[]
 for k in range(n+1):
  s=(F(0),F(0))
  for j in range(k,n+1):s=cadd(s,cmul((asc[j]*math.comb(j,k),F(0)),cpow(c,j-k)))
  out.append(s)
 return out

def log_bounds(x,N=80):
 if x<1:
  lo,hi=log_bounds(1/x,N);return -hi,-lo
 m=0;u=x
 while u>=2:u/=2;m+=1
 while u<1:u*=2;m-=1
 def atanh_series(y):
  s=F(0)
  for n in range(N+1):s+=2*y**(2*n+1)/F(2*n+1)
  rem=2*y**(2*N+3)/(F(2*N+3)*(1-y*y))
  return s,s+rem
 l2=atanh_series(F(1,3));lu=atanh_series((u-1)/(u+1))
 if m>=0:return m*l2[0]+lu[0],m*l2[1]+lu[1]
 return m*l2[1]+lu[0],m*l2[0]+lu[1]

ap=argparse.ArgumentParser();ap.add_argument('--length',type=int,default=5);args=ap.parse_args()
pi,k,q=build(args.length)
z=sp.symbols('z');M=sp.Matrix([[sp.Rational(x.numerator,x.denominator) for x in row] for row in q])
coeff=[F(int(x.p),int(x.q)) for x in M.charpoly(z).all_coeffs()]
assert coeff[-1]==0
qdesc=coeff[:-1];qasc=list(reversed(qdesc))
vals=np.linalg.eigvals(np.array([[float(x) for x in row]for row in q]))
vals=[x for x in vals if abs(x)>1e-5]
centers=[]
for x in vals:
 centers.append((F(round(x.real,6)),F(round(x.imag,6))))
disks=[]
for c in centers:
 a=taylor(qasc,c); chosen=None
 for power in range(-8,3):
  r=F(10)**power
  if low(a[1])*r > up(a[0])+sum(up(a[j])*r**j for j in range(2,len(a))):chosen=r;break
 assert chosen is not None
 disks.append(chosen)
for i in range(len(disks)):
 for j in range(i):
  dx=centers[i][0]-centers[j][0];dy=centers[i][1]-centers[j][1]
  assert dx*dx+dy*dy>(disks[i]+disks[j])**2

siglo=sighi=F(0)
for i in range(len(k)):
 for j in range(i+1,len(k)):
  if k[i][j]:
   J=pi[i]*k[i][j]-pi[j]*k[j][i];lo,hi=log_bounds(k[i][j]/k[j][i])
   if J>=0:siglo+=J*lo;sighi+=J*hi
   else:siglo+=J*hi;sighi+=J*lo

target=max([(c,r) for c,r in zip(centers,disks) if c[1]>0],key=lambda x:float(x[0][0]))
(cr,ci),r=target
Yupper=sighi*(-cr+r)/(ci-r)**2
Ylower=siglo*(-cr-r)/(ci+r)**2
other_right=max(c[0]+rr for c,rr in zip(centers,disks)
                if c!=target[0] and c!=(target[0][0],-target[0][1]) and c[0]<0)
other_left=max(c[0]-rr for c,rr in zip(centers,disks)
               if c!=target[0] and c!=(target[0][0],-target[0][1]) and c[0]<0)
vislo=ci-r+cr-r;vishi=ci+r+cr+r;gaplo=(cr-r)-other_right
cert={"degree":len(coeff)-1,"square_free":sp.gcd(M.charpoly(z).as_expr(),sp.diff(M.charpoly(z).as_expr(),z))==1,
 "rouche_disks":[{"center":[str(c[0]),str(c[1])],"radius":str(r)}for c,r in zip(centers,disks)],
 "sigma_interval_decimal":[float(siglo),float(sighi)],"Y_lower":float(Ylower),"Y_upper":float(Yupper),
 "length":args.length,"visibility_lower":str(vislo),"visibility_upper":str(vishi),
 "leading_gap_lower":str(gaplo),"leadership_failure_margin":str(other_left-(cr+r)),
 "success_certified":bool(Yupper<1 and vislo>0 and gaplo>0),
 "nonvisibility_certified":bool(vishi<0),"nonviolation_certified":bool(Ylower>1)}
outdir=ROOT/'supporting'/'role_family';outdir.mkdir(parents=True,exist_ok=True)
out=outdir/('exact_member_certificate_regenerated.json' if args.length==5 else f'exact_length_L{args.length}_regenerated.json')
out.write_text(json.dumps(cert,indent=2))
print(json.dumps({k:cert[k] for k in ('length','degree','square_free','Y_lower','Y_upper','visibility_lower','leading_gap_lower','success_certified','nonvisibility_certified','nonviolation_certified')},indent=2))
