# OBS theta causal-window and family-completion report

## Primary resolution

`RESOLVED — CERTIFIED CAUSAL WINDOW`

The exact matched-subdivision family replacing the contracted directed edge
between states 11 and 10 is

\[
 k_{11,12}=977,\qquad
 k_{12,11}=\frac{14747}{15531}s,\qquad
 k_{12,10}=\frac{784}{15531}s,\qquad
 k_{10,12}=13636,
\]

with all other rates fixed at the exact integer 12-state theta witness.  Its
matching data are

\[
 \alpha=\frac{784}{15531},\qquad
 p=\frac{765968}{15531},\qquad
 q=\frac{201090092}{15531},\qquad s>0.
\]

Every generator in the closed rational interval

\[
 \boxed{15530\le s\le15532}
\]

is certified to be a valid OBS counterexample.  The uniform conservative
bounds from the primary rational Rouché certificate are

\[
 \lambda_I-\lambda_R>47.020348992241,
\]

\[
 g_{\rm lead}>39.727092946595,
\]

\[
 Y<0.901947534017196<1.
\]

The proof controls the fixed stationary root and all eleven nonzero roots
uniformly; it is not a parameter grid.  Eleven pairwise disjoint rational
radius-one Rouché disks each contain exactly one nonzero root for the entire
interval.  Exact positivity and irreducibility hold for every `s>0`.

At `s=15531`, the target is the unique upper-half-plane root in the disk
centered at

\[
 -\frac{2884831166722723}{500000000000}
 +i\frac{5818682682437687}{10^{12}}
 \approx-5769.662333445446+5818.682682437687i,
\]

of radius one.  Its conjugate is separately isolated.  The active relaxation
competitor is the isolated almost-real pair centered near
`-5811.389426392041 ± 60.220759297817 i`; every other root is farther left by
the recorded exact disk inequalities.

## Certified causal separation

The singular endpoint `s=∞` is the exact 11-state contraction
`n11_exact_contraction`.  Its complete exact-rational characteristic
polynomial has eleven certified roots.  The continued target is

\[
 -6546.827434621515+6281.559316241731i,
\]

while the true leading competitor is

\[
 -5955.866054709765+412.815606560995i.
\]

The target still has `Y<0.895963`, but it is strictly invalid:

\[
 \lambda_I-\lambda_R<-265.268118377784,
 \qquad
 g_{\rm lead}<-590.961379909750.
\]

A 17-link chain of overlapping exact Rouché parameter intervals in
`t=1/s` connects this contraction root to the finite-window target without
sorting roots by real or imaginary part.  The first link also certifies the
same labeled target as invisible for every

\[
 s\ge158828.
\]

Thus a certified invalid tail and the exact invalid contraction are separated
from a certified finite valid interval along one and the same exact family and
one invariantly labeled spectral branch.

## What is preserved and what changes

The exact Schur response identity is

\[
 A_{\rm sub}(z)-A_{\rm edge}(z)
 =\frac{z}{z+s}R_\alpha,
 \qquad \operatorname{rank}R_\alpha=1.
\]

Consequently the DC response is exactly matched.  The unnormalized stationary
current, path affinity, and segment entropy production are also independent
of `s`.  On the old states

\[
 \pi_i(s)=\frac{s\pi_i^{\rm con}}{s+C},
 \qquad
 \pi_{12}(s)=\frac{C}{s+C},
\]

with the exact rational `C` stored in `OBS_matched_subdivision_family.json`.
Normalized full-system fluxes and entropy therefore change only by the exact
normalizer forced by the inserted stationary mass.  The finite-frequency
rank-one response changes, and with it visibility and spectral leadership.

This proves a witness-specific causal statement: inserting the matched Markov
state changes spectral ordering while the zero-frequency path data remain
matched.  It does not claim a universal monotone sign for arbitrary matched
subdivisions.

## Independent spectral route and hostile audit

An independent construction uses an exact rational `QQ(i)` similarity and
fixed pairwise-disjoint Gershgorin disks.  It proves the wider closed interval

\[
 155289/10\le s\le155331/10
\]

with visibility greater than `41.5928017977979`, leadership greater than
`0.821444283285605`, and `Y<0.902910145442301`.  It reconstructs the target,
conjugate mate, stationary root, and active competitor directly from the exact
disks and uses no eigensolver.  Exact endpoint characteristic-polynomial
Rouché checks provide a third cross-check.

The hostile audit initially found three auditability omissions: two disk
indices were not emitted, the verifier trusted rather than reconstructed two
labels, and the fixed-disk containment argument was not serialized.  All three
were corrected.  A separate early contraction audit also exposed an erroneous
stationary-root competitor selection; the final certificate correctly selects
the nonzero pair near `-5955.866±412.816i`.  These corrections strengthen the
certificate interface and do not alter the valid interval or its margins.

## Global spectral-spacer result

### Exact symbolic theorem

For a simple Evans root, the exact matched-spacer susceptibility is expressed
through the global left/right boundary modes and the rank-one residue.  The
package gives a checkable interval sufficient condition for relative target
versus competitor motion and the exceptional-point Puiseux law

\[
 z_\pm(s)=z_c+O(s-s_c)
 \pm\sqrt{-2\frac{P_s}{P_{zz}}(s-s_c)+O((s-s_c)^2)}.
\]

### Sharp obstruction

Local matched-edge data alone cannot determine the sign.  Two exact
Markov-compatible contexts share

`p=2`, `q=1`, `alpha=1/2`, stationary endpoint flows `2/3` and `1/3`, current
`1/3`, traffic `1`, affinity `log(2)`, and inserted mass law `2/s`, yet one
root has `Re(dz/d(1/s))=+5/2` and another has `-5`.  The missing invariant is
global Evans/adjoint-mode geometry.  Therefore the unconditional local form
of `MS6` is refuted; global residue/phase information is necessary.

## Transparent role-layer family

The role-layer `Theta_(3,L,L)` construction uses 15 raw rational parameters,
14 effective parameters after the overall mass-scale redundancy, independent
of `L`; it contains no edge-by-edge `L`-dependent optimized array.

For the exact rational `L=5` member, an exact characteristic polynomial,
square-free check, disjoint rational Rouché disks, and rational atanh-series
logarithm bounds certify

\[
 Y<0.893201865220479,
\]

with visibility greater than approximately `59.21728` and complete-spectrum
leadership greater than approximately `43.58682`.  An independent 80-decimal
reconstruction agrees.

At the same fixed profile, exact certificates classify:

- `L=3,4`: nonvisible;
- `L=5,6,7,8,9`: valid OBS counterexamples;
- `L=10,11,12`: visible and leading, but `Y>1`.

Strict simple-root and thermodynamic margins prove that some full-dimensional
open neighborhood of the `L=5` member is valid.  No explicit positive-width
rational 15-dimensional box was obtained, so `RF4` remains `OPEN`.  The exact
entropy is affine and increasing in `L`, but the missing uniform
Chebyshev/transfer bound on the rotating root prevents promotion of the
finite `L≤12` classification to an all-`L≥10` theorem; `LW2` remains `OPEN`.

## Eleven-state firewall

Only `n11_exact_contraction` is an endpoint of the certified family: 11
states, 12 undirected edges, cycle rank 2, pure theta, and no `3–9` chord.
The separately reoptimized `n11_reoptimized_frontier` has 11 states, 13
edges, cycle rank 3, a `3–9` chord, different rates and scale, and `Y>1`.
No spectral datum, exceptional-point claim, or causal delta from that frontier
is used in the causal-window proof.  No new certified 11-state counterexample
was found; structured repair remains open.

## Proof-level summary

- `PROVED — SYMBOLIC`: family parametrization, response identity, stationary
  scaling, DC invariants, susceptibility formula, local-invariant obstruction,
  and exceptional-point local law.
- `CERTIFIED — EXACT/INTERVAL`: contraction failure, the closed causal window,
  the invalid finite tail, exact target continuation, role member `L=5`, and
  fixed-profile classifications through `L=12`.
- `NUMERICAL — HIGH PRECISION`: independent 80-decimal role-family audit and
  predecessor numerical boundary estimates outside the certified interior.
- `OPEN`: explicit full-dimensional rational role box, the infinite length
  tail, and a certified 11-state structured repair.

The merged machine-readable claim status is in
`OBS_theta_causal_theorem_ledger.csv`; provenance and hashes are in
`OBS_theta_lineage_manifest.csv` and `SHA256SUMS.txt`.
