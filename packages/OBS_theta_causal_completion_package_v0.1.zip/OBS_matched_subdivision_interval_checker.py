#!/usr/bin/env python3
"""Uniform exact/ball certificate on 15530 <= s <= 15532.

The proof is Rouché-based, not a parameter grid.  Certified Acb root balls at
s0 are enclosed by rational epsilon-disks.  Exact rational lower and upper
bounds then prove that each radius-one disk contains one continued nonzero
root for every parameter in the whole closed interval.
"""

from __future__ import annotations

import csv
import json
import math
from fractions import Fraction
from pathlib import Path

import sympy as sp
from flint import acb, acb_poly, arb, ctx, fmpq, fmpq_poly

from OBS_matched_subdivision_exact_construction import (
    HERE, S0, Z, contracted_rates, family_rates, generator, polynomial_data,
    stationary_exact,
)


S_MINUS = Fraction(15530)
S_PLUS = Fraction(15532)
DELTA = Fraction(1)
ROUCHE_RADIUS = Fraction(1)
ROOT_ENCLOSURE = Fraction(1, 10**9)
DISTANCE_SCALE = 10**6
CHAIN_RADIUS = Fraction(100)


def fq(x: sp.Expr) -> Fraction:
    x = sp.Rational(x)
    return Fraction(int(x.p), int(x.q))


def fmpq_poly_from_sympy(poly: sp.Poly) -> fmpq_poly:
    return fmpq_poly([fmpq(str(c)) for c in reversed(poly.all_coeffs())])


def certified_roots(poly: sp.Poly) -> list[acb]:
    roots = acb_poly(fmpq_poly_from_sympy(poly)).roots(tol=arb("1e-80"), maxprec=8192)
    if len(roots) != poly.degree():
        raise AssertionError("Acb did not return a complete root list")
    return sorted(roots, key=lambda z: (float(z.real), float(z.imag)))


def decimal_fraction_mid(x: arb, digits: int = 12) -> Fraction:
    # The midpoint only proposes a rational center; containment is checked
    # afterward using the full Arb ball, so this conversion need not be an
    # outward rounding operation.
    return Fraction(f"{float(x.mid()):.{digits}f}")


def arb_of_fraction(x: Fraction) -> arb:
    return arb(x.numerator) / arb(x.denominator)


def encloses_in_epsilon(root: acb, re: Fraction, im: Fraction) -> bool:
    dz = root - acb(arb_of_fraction(re), arb_of_fraction(im))
    return bool(abs(dz).upper() < arb_of_fraction(ROOT_ENCLOSURE))


def floor_sqrt_fraction(x: Fraction, scale: int) -> Fraction:
    n = (x.numerator * scale * scale) // x.denominator
    ans = Fraction(math.isqrt(n), scale)
    if ans * ans > x:
        raise AssertionError("internal lower-distance rounding error")
    return ans


def ceil_sqrt_fraction(x: Fraction, scale: int) -> Fraction:
    n = (x.numerator * scale * scale) // x.denominator
    k = math.isqrt(n)
    ans = Fraction(k, scale)
    if ans * ans < x:
        ans = Fraction(k + 1, scale)
    if ans * ans < x:
        raise AssertionError("internal upper-distance rounding error")
    return ans


def ceil_abs_plus(re: Fraction, im: Fraction, extra: Fraction) -> int:
    d2 = re * re + im * im
    low = math.isqrt(d2.numerator // d2.denominator)
    while Fraction(low * low) < d2:
        low += 1
    return low + math.ceil(extra)


def poly_abs_upper(coeffs_low: list[Fraction], modulus_upper: int) -> Fraction:
    return sum(abs(a) * modulus_upper**k for k, a in enumerate(coeffs_low))


def rat(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def sci(x: Fraction, digits: int = 8) -> str:
    return f"{float(x):.{digits}e}"


def arb_bounds(x: arb) -> dict:
    return {"ball": str(x), "lower": str(x.lower()), "upper": str(x.upper())}


def entropy_ball(q: sp.Matrix, pi: list[sp.Rational]) -> arb:
    total = arb(0)
    for i in range(q.rows):
        for j in range(i + 1, q.cols):
            kij, kji = q[i, j], q[j, i]
            if kij > 0 and kji > 0:
                f = sp.factor(pi[i] * kij)
                b = sp.factor(pi[j] * kji)
                af, ab = arb_of_fraction(fq(f)), arb_of_fraction(fq(b))
                total += (af - ab) * (af / ab).log()
    return total


def classify(centers: list[tuple[Fraction, Fraction]]) -> tuple[int, int, list[int]]:
    target = min(
        (i for i, (_, im) in enumerate(centers) if im > 0),
        key=lambda i: abs(float(centers[i][0]) + 5769.662333445)
                       + abs(float(centers[i][1]) - 5818.682682437),
    )
    mate = min(range(len(centers)),
               key=lambda i: abs(float(centers[i][0] - centers[target][0]))
                             + abs(float(centers[i][1] + centers[target][1])))
    others = [i for i in range(len(centers)) if i not in (target, mate)]
    return target, mate, others


def exact_poly_at_t(a: sp.Poly, b: sp.Poly, t: Fraction) -> sp.Poly:
    return sp.Poly(a.as_expr() + sp.Rational(t.numerator, t.denominator) * b.as_expr(),
                   Z, domain=sp.QQ)


def root_factor_circle_bounds(poly: sp.Poly, chosen: int,
                              centers: list[tuple[Fraction, Fraction]],
                              radius: Fraction) -> Fraction:
    cre, cim = centers[chosen]
    lower = abs(fq(poly.LC())) * (radius - ROOT_ENCLOSURE)
    for j, (ore, oim) in enumerate(centers):
        if j == chosen:
            continue
        dlow = floor_sqrt_fraction((cre - ore)**2 + (cim - oim)**2,
                                   DISTANCE_SCALE)
        term = dlow - radius - ROOT_ENCLOSURE
        if term <= 0:
            raise AssertionError("continuation disk contains another anchor root")
        lower *= term
    return lower


def fixed_poly_circle_upper(poly: sp.Poly,
                            poly_centers: list[tuple[Fraction, Fraction]],
                            cre: Fraction, cim: Fraction,
                            radius: Fraction) -> Fraction:
    upper = abs(fq(poly.LC()))
    for are, aim in poly_centers:
        dup = ceil_sqrt_fraction((cre - are)**2 + (cim - aim)**2,
                                 DISTANCE_SCALE)
        upper *= dup + radius + ROOT_ENCLOSURE
    return upper


def certified_target_chain(pdata: dict) -> list[dict]:
    """Cover t=1/s from the contraction endpoint through s=15530.

    Each record is a genuine parameter interval on which a fixed rational
    disk contains exactly one root.  The next anchor root is required to lie
    in the preceding disk, preserving identity without real-part sorting.
    """
    a = pdata["slope_nonzero"]
    b = sp.Poly(pdata["center_nonzero"].as_expr()
                - S0 * pdata["slope_nonzero"].as_expr(), Z, domain=sp.QQ)
    b_roots = certified_roots(b)
    b_centers = [(decimal_fraction_mid(r.real), decimal_fraction_mid(r.imag))
                 for r in b_roots]
    if not all(encloses_in_epsilon(r, *c) for r, c in zip(b_roots, b_centers)):
        raise AssertionError("B-polynomial root enclosure failed")

    milestones = [Fraction(1, 15531), Fraction(1, 15530)]
    goal = milestones[-1]
    t = Fraction(0)
    previous_center = Fraction("-6546.827434622"), Fraction("6281.559316242")
    records = []
    for step_index in range(1000):
        poly = exact_poly_at_t(a, b, t)
        roots = certified_roots(poly)
        centers = [(decimal_fraction_mid(r.real), decimal_fraction_mid(r.imag))
                   for r in roots]
        if not all(encloses_in_epsilon(r, *c) for r, c in zip(roots, centers)):
            raise AssertionError("continuation anchor root enclosure failed")
        chosen = min(range(len(centers)),
                     key=lambda i: float((centers[i][0] - previous_center[0])**2
                                         + (centers[i][1] - previous_center[1])**2))
        cre, cim = centers[chosen]
        if step_index and ((cre - previous_center[0])**2
                           + (cim - previous_center[1])**2) >= (CHAIN_RADIUS - ROOT_ENCLOSURE)**2:
            raise AssertionError("next anchor target is not inside previous root disk")
        lower = root_factor_circle_bounds(poly, chosen, centers, CHAIN_RADIUS)
        upper = fixed_poly_circle_upper(b, b_centers, cre, cim, CHAIN_RADIUS)
        halfwidth = lower / upper
        if halfwidth <= 0:
            raise AssertionError("nonpositive continuation halfwidth")
        record = {
            "step": step_index, "anchor_t": rat(t),
            "anchor_s": "infinity" if t == 0 else rat(1 / t),
            "target_center_re": rat(cre), "target_center_im": rat(cim),
            "disk_radius": rat(CHAIN_RADIUS),
            "parameter_halfwidth_lower": rat(halfwidth),
            "covered_t_left": rat(max(Fraction(0), t - halfwidth)),
            "covered_t_right": rat(min(goal, t + halfwidth)),
            "rouche_lower": rat(lower), "perturbation_per_unit_t_upper": rat(upper),
            "root_ball": str(roots[chosen]),
        }
        records.append(record)
        if t == goal:
            break
        # Advance by 3/4 of the certified halfwidth, stopping exactly at the
        # two requested rational milestones so the center witness is explicit.
        candidate = t + Fraction(3, 4) * halfwidth
        future_milestones = [m for m in milestones if m > t]
        next_milestone = min(future_milestones) if future_milestones else goal
        tnext = min(candidate, next_milestone, goal)
        if not tnext > t or not tnext - t < halfwidth:
            raise AssertionError("continuation cover failed to advance with overlap")
        previous_center = (cre, cim)
        t = tnext
    else:
        raise AssertionError("continuation chain exceeded 1000 certified disks")
    if Fraction(records[-1]["anchor_t"]) != goal:
        raise AssertionError("continuation chain did not reach s=15530")
    return records


def main() -> None:
    ctx.prec = 512
    pdata = polynomial_data()
    roots = certified_roots(pdata["center_nonzero"])
    centers = [(decimal_fraction_mid(r.real), decimal_fraction_mid(r.imag)) for r in roots]
    if not all(encloses_in_epsilon(r, *c) for r, c in zip(roots, centers)):
        raise AssertionError("a center root ball escaped its rational epsilon enclosure")

    contraction_roots = certified_roots(pdata["slope_nonzero"])
    contraction_centers = [(decimal_fraction_mid(r.real), decimal_fraction_mid(r.imag))
                           for r in contraction_roots]
    if not all(encloses_in_epsilon(r, *c)
               for r, c in zip(contraction_roots, contraction_centers)):
        raise AssertionError("a contraction root escaped its rational epsilon enclosure")
    records = []
    for i, ((cre, cim), root) in enumerate(zip(centers, roots)):
        lower = ROUCHE_RADIUS - ROOT_ENCLOSURE
        pair_bounds = []
        for j, (ore, oim) in enumerate(centers):
            if i == j:
                continue
            d2 = (cre - ore)**2 + (cim - oim)**2
            dlow = floor_sqrt_fraction(d2, DISTANCE_SCALE)
            term = dlow - ROUCHE_RADIUS - ROOT_ENCLOSURE
            if term <= 0:
                raise AssertionError("Rouché disks are not separated")
            lower *= term
            pair_bounds.append(rat(dlow))
        modulus_upper = ceil_abs_plus(cre, cim, ROUCHE_RADIUS)
        contraction_distance_uppers = []
        upper_a = Fraction(1)
        for are, aim in contraction_centers:
            d2 = (cre - are)**2 + (cim - aim)**2
            dup = ceil_sqrt_fraction(d2, DISTANCE_SCALE)
            contraction_distance_uppers.append(rat(dup))
            upper_a *= dup + ROUCHE_RADIUS + ROOT_ENCLOSURE
        perturb_upper = DELTA * upper_a
        if not perturb_upper < lower:
            raise AssertionError(f"Rouché inequality failed for root {i}: {float(perturb_upper/lower)}")
        records.append({
            "index": i,
            "center_re": rat(cre), "center_im": rat(cim),
            "rouche_radius": rat(ROUCHE_RADIUS),
            "certified_center_root_ball": str(root),
            "center_ball_within_epsilon": rat(ROOT_ENCLOSURE),
            "other_center_distance_lower_bounds": pair_bounds,
            "circle_modulus_upper": modulus_upper,
            "contraction_root_distance_upper_bounds": contraction_distance_uppers,
            "center_polynomial_modulus_lower": rat(lower),
            "perturbation_modulus_upper": rat(perturb_upper),
            "upper_over_lower_scientific": sci(perturb_upper / lower),
            "conclusion": "exactly one root for every 15530 <= s <= 15532"
        })

    target, mate, others = classify(centers)
    tr, ti = centers[target]
    visibility_lower = tr + ti - 2 * ROUCHE_RADIUS
    lambda_r_upper = -tr + ROUCHE_RADIUS
    lambda_i_lower = ti - ROUCHE_RADIUS
    competitor_real_upper = max(centers[i][0] + ROUCHE_RADIUS for i in others)
    leadership_lower = tr - ROUCHE_RADIUS - competitor_real_upper
    if min(visibility_lower, lambda_i_lower, leadership_lower) <= 0:
        raise AssertionError("geometric CDC bound failed")

    qcon = generator(contracted_rates())
    picon = stationary_exact(qcon)
    sigma_con = entropy_ball(qcon, picon)
    center_pi = stationary_exact(generator(family_rates(S0)))
    pix = fq(center_pi[11])
    c_mass = Fraction(15531) * pix / (1 - pix)
    scale_upper = arb_of_fraction(S_PLUS / (S_PLUS + c_mass))
    sigma_upper_ball = sigma_con * scale_upper
    if not sigma_upper_ball.upper() < arb(5290):
        raise AssertionError("entropy upper bound 5290 was not certified")
    y_upper = Fraction(5290) * lambda_r_upper / (lambda_i_lower * lambda_i_lower)
    if not y_upper < 1:
        raise AssertionError("Y<1 was not certified")

    root_payload = {
        "proof_method": "uniform Rouché theorem on rational disks; no s-grid",
        "parameter_interval_closed": [rat(S_MINUS), rat(S_PLUS)],
        "affine_identity": "chi12(z,s)/z = p0(z) + (s-15531) chi11(z)/z",
        "root_count": {"fixed_zero_root": 1, "certified_nonzero_disks": len(records)},
        "target_index": target, "target_conjugate_index": mate,
        "root_disks": records,
        "uniform_target_bounds": {
            "visibility_lower": rat(visibility_lower),
            "lambda_R_upper": rat(lambda_r_upper),
            "lambda_I_lower": rat(lambda_i_lower),
            "leadership_gap_lower": rat(leadership_lower),
            "competitor_real_upper": rat(competitor_real_upper),
            "entropy_contraction": arb_bounds(sigma_con),
            "entropy_at_s_plus_upper_ball": arb_bounds(sigma_upper_ball),
            "entropy_coarse_rational_upper": "5290",
            "Y_rational_upper": rat(y_upper),
            "Y_upper_decimal": f"{float(y_upper):.15f}"
        },
        "target_identity": {
            "definition": "the unique root in the listed target disk, selected at s0 by the certified center near -5769.662333445+5818.682682437i",
            "continuation": "disjoint uniform one-root disks give a unique continuous/analytic simple-root branch across the full interval",
            "complete_spectrum_control": "the zero root plus eleven one-root disks account for all twelve roots"
        },
    }
    chain = certified_target_chain(pdata)
    first_chain = chain[0]
    tail_halfwidth = Fraction(first_chain["parameter_halfwidth_lower"])
    endpoint_target_re = Fraction(first_chain["target_center_re"])
    endpoint_target_im = Fraction(first_chain["target_center_im"])
    tail_visibility_upper = (endpoint_target_re + endpoint_target_im
                             + 2 * (CHAIN_RADIUS + ROOT_ENCLOSURE))
    if not tail_visibility_upper < 0:
        raise AssertionError("continuation disk does not certify an invisible tail")
    tail_s_coarse = Fraction(158828)
    if not tail_s_coarse > 1 / tail_halfwidth:
        raise AssertionError("coarse invalid-tail threshold is not conservative")
    root_payload["contraction_to_window_target_chain"] = {
        "variable": "t=1/s",
        "normalized_polynomial": "G(z,t)=chi11(z)/z+t*(chi12(z,15531)/z-15531*chi11(z)/z)",
        "proof": "overlapping Rouché parameter intervals; every next anchor target lies in the preceding unique-root disk",
        "chain_reaches": "t=1/15530 and includes the exact milestone t=1/15531",
        "record_count": len(chain),
        "records": chain,
    }
    root_payload["certified_invalid_contraction_tail"] = {
        "t_interval": f"0 <= t < {rat(tail_halfwidth)}",
        "exact_equivalent_s_region": f"s > {rat(1 / tail_halfwidth)}",
        "simple_certified_subregion": "s >= 158828",
        "failure": "the same labeled target remains invisible",
        "visibility_upper": rat(tail_visibility_upper),
        "proof": "first continuation Rouché disk about the exact contraction root"
    }
    (HERE / "OBS_matched_subdivision_root_boxes.json").write_text(json.dumps(root_payload, indent=2) + "\n")

    rows = [
        ["rates_positive_and_irreducible", "15530 <= s <= 15532", "proved", "all fixed rates positive and s>0; fixed strongly connected support"],
        ["complete_root_count", "15530 <= s <= 15532", "proved", "fixed zero plus 11 disjoint Rouché disks"],
        ["target_visibility", "15530 <= s <= 15532", "proved", f"lambda_I-lambda_R >= {rat(visibility_lower)} > 0"],
        ["target_leadership", "15530 <= s <= 15532", "proved", f"real-part gap >= {rat(leadership_lower)} > 0"],
        ["entropy", "15530 <= s <= 15532", "proved", "sigma(s) increasing and sigma(15532)<5290 by Arb"],
        ["Y", "15530 <= s <= 15532", "proved", f"Y <= {rat(y_upper)} < 1"],
        ["strict_valid_interval", "15530 < s < 15532", "proved", "follows from stronger closed-interval certificate"],
        ["numerical_leadership_boundaries", "approximately 15064.601910 and 17119.286131", "informational_only", "not used in proof"],
        ["contraction_endpoint", "s=infinity", "invalid", "separate exact contraction spectral certificate"],
        ["strict_invalid_tail", "s >= 158828", "proved", f"same target visibility <= {rat(tail_visibility_upper)} < 0"],
    ]
    with (HERE / "OBS_matched_subdivision_boundary_ledger.csv").open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["condition", "parameter_region", "status", "certificate"])
        w.writerows(rows)
    print(json.dumps(root_payload["uniform_target_bounds"], indent=2))


if __name__ == "__main__":
    main()
