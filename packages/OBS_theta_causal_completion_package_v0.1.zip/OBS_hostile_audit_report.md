# Hostile audit report

## Verdict

`PASS` for the primary resolution `RESOLVED — CERTIFIED CAUSAL WINDOW`.

No hostile test falsified the exact family, its stationary/thermodynamic
matching, the complete-spectrum valid interval, the invariant target label,
the invalid contraction, or the finite invalid tail.  Secondary role-family
claims pass only at the levels explicitly recorded: the exact member and
finite lengths are certified, while an explicit rational box and the infinite
tail remain open.

## Causal-window attacks

The independent hostile route reconstructed the exact generator rather than
loading a floating matrix.  It checked:

- all four subdivision rates and both exact contracted rates;
- strict positivity and bidirectional support on the closed interval;
- symbolic stationarity of the unnormalized weights and the exact normalizer;
- independence of every unnormalized stationary segment flux from `s`;
- affinity, current, entropy, rate-index, row/column, and logarithm conventions;
- exact affine dependence of the generator on `s`;
- all pairwise disk separations and actual-row-disk containment;
- exactly one root in each disk, including the stationary disk;
- reconstruction of the target, its conjugate mate, stationary root, and
  nonstationary active competitor;
- visibility, full leadership, entropy, and `Y<1` margins;
- exact endpoint characteristic-polynomial Rouché isolations as a distinct
  spectral route;
- exact-contraction support, full spectrum, visibility failure, and leadership
  failure;
- the 17-link continuation chain and the finite invalid tail.

The independent similarity/Gershgorin audit proves the wider interval
`155289/10 <= s <= 155331/10`.  This contains the primary reported interval
`[15530,15532]`.

## Defects found and corrected

The audit found three interface defects in the first independent certificate:

1. the target-mate and stationary indices were computed but not emitted;
2. the first verifier trusted target/competitor labels instead of
   reconstructing every role from exact disks;
3. the serialized certificate omitted the actual-row-disk containment
   statement required before invoking the second Gershgorin theorem.

The producer now emits both missing indices and the containment theorem.  The
portable verifier `OBS_independent_spectral_audit.py` independently identifies
all four roles and checks the theorem hypotheses exactly.

An earlier contraction certificate also treated the stationary root as a
leadership competitor.  Hostile review caught this.  The final certificate
excludes zero and the target conjugate, selects the genuine pair near
`-5955.866±412.816i`, and certifies the corrected leadership upper bound
`-590.961379909750`.

These defects were discovered before packaging and are not present in the
final claim paths.

## Lineage attack

The audit deliberately attempted to merge the two 11-state systems.  The
attempt fails on support and hash alone:

- `n11_exact_contraction`: 12 edges, cycle rank 2, pure theta, no `3–9` chord,
  exact matched rates, witness scale;
- `n11_reoptimized_frontier`: 13 edges, cycle rank 3, contains `3–9`, separately
  optimized floating rates, different scale and spectrum.

Only the first is the `s=∞` endpoint.  The frontier exceptional-point spacer
is not imported into the causal proof.  The named corrected predecessor v0.2.1
archive was not present locally; this is recorded rather than silently
substituting the available v0.2 archive.

## Spectral-spacer theorem attack

Removing global adjoint/Evans information destroys any universal sign claim.
The exact obstruction reuses identical `p,q,alpha`, stationary flows, current,
traffic, affinity, and inserted-mass law in two Markov contexts but produces
opposite root-motion signs.  This refutes local-data-only `MS6` and identifies
the missing global invariant.  The positive sufficient condition in
`OBS_spectral_spacer_theorem.tex` is therefore explicitly global and local in
the simple-root parameter regime.  At a double root it is replaced by the
Puiseux cluster law; no simple-root formula is applied across an exceptional
point.

## Transparent-family attack

The role-family audit reconstructed rates directly from 15 raw rational role
parameters and confirmed that parameter count is independent of `L`.  It used
an exact rational characteristic polynomial, square-free test, disjoint
Rouché disks, and rational logarithm bounds.  A separate 80-decimal
implementation agrees for `L=3,...,9`.

The audit rejected two tempting upgrades:

- strict center margins imply existence of an open full-dimensional
  neighborhood, but do not provide explicit rational half-widths;
- exact classification through `L=12` and numerical failure through `L=20`
  do not prove failure for every `L>=10`.

Accordingly `RF4` and `LW2` remain `OPEN` in the merged ledger.

## Reproduction evidence

Machine-readable hostile evidence is retained under `supporting/audit/`, and
the role/spacer branch reports are under `supporting/role_family/` and
`supporting/spacer/`.  `run_all_checks.ps1` reruns all decisive packaged
certificates and fails on a nonzero checker exit status.
