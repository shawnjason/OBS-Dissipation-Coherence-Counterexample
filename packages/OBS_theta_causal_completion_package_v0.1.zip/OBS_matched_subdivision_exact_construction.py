#!/usr/bin/env python3
"""Exact construction for the matched 11--12--10 subdivision family.

All matrices use the row-generator convention.  The family parameter ``s``
is symbolic; its characteristic polynomial is affine in ``s``.  This module
contains no floating-point arithmetic and is imported by the interval and
contraction checkers.
"""

from __future__ import annotations

import json
from fractions import Fraction
from pathlib import Path

import sympy as sp


HERE = Path(__file__).resolve().parent
WORK = HERE
SOURCE = HERE / "supporting/exact_inputs/n12_e13.json"

S0 = sp.Integer(15531)
ALPHA = sp.Rational(784, 15531)
P = sp.Rational(765968, 15531)       # contracted 11 -> 10
QBACK = sp.Rational(201090092, 15531)  # contracted 10 -> 11
INSERTED = 11                        # zero-based state 12
U = 10                               # zero-based state 11
V = 9                                # zero-based state 10
S = sp.Symbol("s", positive=True)
Z = sp.Symbol("z")


def source_rates() -> sp.Matrix:
    payload = json.loads(SOURCE.read_text())
    d = sp.Integer(payload["denominator"])
    return sp.Matrix([[sp.Rational(x, d) for x in row]
                      for row in payload["integer_rate_numerators"]])


def generator(rates: sp.Matrix) -> sp.Matrix:
    out = rates.copy()
    for i in range(out.rows):
        out[i, i] = -sum(rates[i, j] for j in range(out.cols) if j != i)
    return out


def family_rates(s: sp.Expr = S) -> sp.Matrix:
    rates = source_rates()
    for i, j in ((U, INSERTED), (INSERTED, U),
                 (INSERTED, V), (V, INSERTED)):
        rates[i, j] = 0
    rates[U, INSERTED] = P / ALPHA             # 977
    rates[INSERTED, U] = (1 - ALPHA) * s      # 14747*s/15531
    rates[INSERTED, V] = ALPHA * s            # 784*s/15531
    rates[V, INSERTED] = QBACK / (1 - ALPHA)  # 13636
    return rates


def contracted_rates() -> sp.Matrix:
    base = source_rates()
    keep = [i for i in range(12) if i != INSERTED]
    out = base.extract(keep, keep)
    out[U, V] = P
    out[V, U] = QBACK
    return out


def stationary_exact(q: sp.Matrix) -> list[sp.Rational]:
    # Replace one dependent stationarity equation by normalization.
    a = q.T.copy()
    rhs = sp.zeros(q.rows, 1)
    for j in range(q.cols):
        a[q.rows - 1, j] = 1
    rhs[q.rows - 1] = 1
    sol = a.inv() * rhs
    return [sp.factor(x) for x in sol]


def polynomial_data() -> dict:
    qfam = generator(family_rates(S))
    chi = sp.Poly(qfam.charpoly(Z).as_expr(), Z, S, domain=sp.QQ)
    if sp.degree(chi.as_expr(), S) != 1:
        raise AssertionError("family characteristic polynomial is not affine in s")
    chi0 = sp.Poly(chi.as_expr().subs(S, S0), Z, domain=sp.QQ)
    if chi0.eval(0) != 0:
        raise AssertionError("Markov zero root is missing")
    nonzero0 = sp.Poly(sp.cancel(chi0.as_expr() / Z), Z, domain=sp.QQ)
    slope = sp.Poly(sp.diff(chi.as_expr(), S), Z, domain=sp.QQ)
    if slope.eval(0) != 0:
        raise AssertionError("the fixed zero root must also divide the slope")
    nonzero_slope = sp.Poly(sp.cancel(slope.as_expr() / Z), Z, domain=sp.QQ)
    qcon = generator(contracted_rates())
    contraction = sp.Poly(qcon.charpoly(Z).as_expr(), Z, domain=sp.QQ)
    if slope != contraction:
        raise AssertionError("leading-s polynomial is not the exact contraction charpoly")
    return {
        "family": chi,
        "center": chi0,
        "center_nonzero": nonzero0,
        "slope": slope,
        "slope_nonzero": nonzero_slope,
        "contraction": contraction,
    }


def rat_string(x: sp.Expr) -> str:
    return str(sp.factor(x))


def polynomial_record(poly: sp.Poly) -> dict:
    return {
        "variables": [str(g) for g in poly.gens],
        "degree_z": int(poly.degree(Z)),
        "coefficients_descending_in_z": [rat_string(c) for c in sp.Poly(poly, Z).all_coeffs()],
        "expression": str(sp.factor(poly.as_expr())),
    }


def write_exact_artifacts() -> None:
    pdata = polynomial_data()
    center_pi = stationary_exact(generator(family_rates(S0)))
    contraction_pi = stationary_exact(generator(contracted_rates()))
    inserted = center_pi[INSERTED]
    c_mass = sp.factor(S0 * inserted / (1 - inserted))
    family_pi = []
    old_index = 0
    for i in range(12):
        if i == INSERTED:
            family_pi.append(sp.factor(c_mass / (S + c_mass)))
        else:
            family_pi.append(sp.factor(S * contraction_pi[old_index] / (S + c_mass)))
            old_index += 1
    qfam = generator(family_rates(S))
    if sp.simplify((sp.Matrix([family_pi]) * qfam)) != sp.zeros(1, 12):
        raise AssertionError("closed-form family stationary law failed exact verification")
    if sp.simplify(sum(family_pi) - 1) != 0:
        raise AssertionError("closed-form family stationary law is not normalized")
    payload = {
        "schema": "OBS matched-subdivision family v1",
        "lineage_separation": {
            "used_control": "n11_exact_contraction (11 states, 12 undirected edges, cycle rank 2, pure theta, no 3--9 chord)",
            "excluded_system": "n11_reoptimized_frontier (11 states, 13 undirected edges, cycle rank 3, contains 3--9 chord)",
            "non_interchangeability": "No rate, eigenvalue, entropy, or root label from the excluded system is used here."
        },
        "source": str(SOURCE.relative_to(WORK.parent)).replace("\\", "/"),
        "states_one_based": {"u": 11, "inserted_x": 12, "v": 10},
        "parameters": {
            "s0": str(S0), "alpha": str(ALPHA),
            "p_effective_11_to_10": str(P),
            "q_effective_10_to_11": str(QBACK),
            "p1_11_to_12": "977",
            "q1_12_to_11": "14747*s/15531",
            "p2_12_to_10": "784*s/15531",
            "q2_10_to_12": "13636"
        },
        "certified_interval": {
            "closed_proved": ["15530", "15532"],
            "requested_strict_valid_interval": "15530 < s < 15532",
            "relation_to_numerical_boundary_estimates": "strictly inside 15064.601910 < s < 17119.286131"
        },
        "stationary_scaling": {
            "center_inserted_mass": rat_string(inserted),
            "C_equals_s0_pix_over_1_minus_pix": rat_string(c_mass),
            "contracted_stationary_weights": [rat_string(x) for x in contraction_pi],
            "family_formula": "pi_i(s)=s*pi_contracted_i/(s+C) for old i; pi_12(s)=C/(s+C)",
            "exact_checks": ["pi(s) Q(s)=0", "sum_i pi_i(s)=1", "all entries positive for s>0"]
        },
        "response_identity": {
            "formula": "A_sub(z)-A_edge(z)=z/(z+s) R_alpha",
            "R_alpha_rank": 1,
            "R_alpha": [[rat_string(P*(1-ALPHA)/ALPHA), rat_string(P)],
                         [rat_string(QBACK), rat_string(QBACK*ALPHA/(1-ALPHA))]]
        }
    }
    (HERE / "OBS_matched_subdivision_family.json").write_text(json.dumps(payload, indent=2) + "\n")
    polynomials = {
        "identity": "chi_12(z,s)=chi_12(z,s0)+(s-s0)chi_11_contraction(z)",
        "center_s0": polynomial_record(pdata["center"]),
        "center_nonzero_divided_by_z": polynomial_record(pdata["center_nonzero"]),
        "s_slope_equals_contraction": polynomial_record(pdata["slope"]),
        "contraction": polynomial_record(pdata["contraction"]),
        "slope_nonzero_divided_by_z": polynomial_record(pdata["slope_nonzero"]),
    }
    (HERE / "OBS_matched_subdivision_exact_polynomials.json").write_text(
        json.dumps(polynomials, indent=2) + "\n")
    rates = {
        "system": "n11_exact_contraction",
        "state_count": 11,
        "edge_count_undirected": 12,
        "cycle_rank": 2,
        "has_3_9_chord": False,
        "removed_state_one_based": 12,
        "replacement_edge_one_based": [11, 10],
        "replacement_rates": {"11_to_10": str(P), "10_to_11": str(QBACK)},
        "rate_matrix_rows_one_based": [[rat_string(x) for x in row]
                                       for row in contracted_rates().tolist()]
    }
    (HERE / "OBS_contraction_exact_rates.json").write_text(json.dumps(rates, indent=2) + "\n")


if __name__ == "__main__":
    write_exact_artifacts()
    print("exact family, contraction rates, and polynomial identity written")
