param(
    [string]$PythonExe = "python"
)

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Invoke-Checker {
    param([string]$Script, [string[]]$Arguments = @())
    Write-Host "==> $Script $($Arguments -join ' ')"
    & $PythonExe (Join-Path $PackageRoot $Script) @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Checker failed: $Script"
    }
}

Push-Location $PackageRoot
try {
    Invoke-Checker "OBS_matched_subdivision_exact_construction.py"
    Invoke-Checker "OBS_matched_subdivision_interval_checker.py"
    Invoke-Checker "OBS_contraction_spectral_certificate.py"
    Invoke-Checker "OBS_independent_spectral_audit.py"
    Invoke-Checker "OBS_role_layer_exact_checker.py" @("--length", "5")
    foreach ($Length in 3,4,6,7,8,9,10,11,12) {
        Invoke-Checker "OBS_role_layer_exact_checker.py" @("--length", "$Length")
    }
    Invoke-Checker "OBS_role_layer_interval_checker.py"
    Invoke-Checker "scripts/independent_mpmath_audit.py"
    Invoke-Checker "scripts/exact_counterexample_certificate.py"
    Invoke-Checker "scripts/hostile_verify.py"
    Write-Host "ALL PACKAGED CHECKS PASSED"
}
finally {
    Pop-Location
}
