#!/usr/bin/env python3
"""Verifier for the emitted causal-window certificate; no eigensolver used."""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp
from flint import arb, ctx


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "supporting/exact_inputs/n12_e13.json"
CERT = ROOT / "supporting/audit/gershgorin_window_certificate.json"
OUT = ROOT / "supporting/audit/gershgorin_verification_regenerated.json"


def parse(x: str) -> sp.Expr:
    return sp.sympify(x, locals={"I": sp.I})


def matrix(rows: list[list[str]]) -> sp.Matrix:
    return sp.Matrix([[parse(x) for x in row] for row in rows])


def l1(x: sp.Expr) -> sp.Rational:
    x = sp.expand_complex(x)
    return abs(sp.Rational(sp.re(x))) + abs(sp.Rational(sp.im(x)))


def row_generator(k: sp.Matrix) -> sp.Matrix:
    q = k.copy()
    for i in range(q.rows):
        q[i, i] = -sum(q[i, j] for j in range(q.cols) if j != i)
    return q


def build() -> tuple[sp.Matrix, sp.Matrix, sp.Matrix, sp.Symbol]:
    raw = json.loads(SOURCE.read_text(encoding="utf-8"))
    k0 = sp.Matrix([[sp.Rational(x, raw.get("denominator", 1)) for x in row]
                    for row in raw["integer_rate_numerators"]])
    s = sp.Symbol("s", positive=True)
    alpha = sp.Rational(784, 15531)
    p = sp.Rational(765968, 15531)
    qrate = sp.Rational(201090092, 15531)
    k = k0.copy()
    for i, j in ((10, 11), (11, 10), (11, 9), (9, 11)):
        k[i, j] = 0
    k[10, 11] = p / alpha
    k[11, 10] = (1 - alpha) * s
    k[11, 9] = alpha * s
    k[9, 11] = qrate / (1 - alpha)
    q = row_generator(k)
    q0 = q.subs(s, 15531)
    direction = q.diff(s)
    assert q == q0 + (s - 15531) * direction
    keep = list(range(11))
    kc = k0.extract(keep, keep)
    kc[10, 9], kc[9, 10] = p, qrate
    qc = row_generator(kc)
    return q, q0, direction, qc, s


def verify_discs(q0: sp.Matrix, direction: sp.Matrix, v: sp.Matrix,
                 h: sp.Rational, recorded: list[dict]) -> list[dict]:
    b0 = sp.simplify(v.inv() * q0 * v)
    b1 = sp.simplify(v.inv() * direction * v)
    discs = []
    for i in range(q0.rows):
        center = sp.expand_complex(b0[i, i])
        radius = h * l1(b1[i, i])
        radius += sum(l1(b0[i, j]) + h * l1(b1[i, j])
                      for j in range(q0.cols) if i != j)
        assert sp.cancel(center - parse(recorded[i]["center"])) == 0
        assert sp.cancel(radius - parse(recorded[i]["radius"])) == 0
        discs.append({"center": center, "radius": radius})
    for i, di in enumerate(discs):
        for j in range(i):
            delta = sp.expand_complex(di["center"] - discs[j]["center"])
            strict = sp.re(delta) ** 2 + sp.im(delta) ** 2
            strict -= (di["radius"] + discs[j]["radius"]) ** 2
            assert sp.factor(strict) > 0
    return discs


def stationary(q: sp.Matrix) -> list[sp.Rational]:
    a = q.T.copy()
    a[-1, :] = sp.ones(1, q.rows)
    rhs = sp.zeros(q.rows, 1)
    rhs[-1] = 1
    return [sp.Rational(x) for x in a.inv() * rhs]


def arbq(x: sp.Expr) -> arb:
    x = sp.Rational(x)
    return arb(int(sp.numer(x))) / arb(int(sp.denom(x)))


def entropy(q: sp.Matrix, pi: list[sp.Rational]) -> arb:
    result = arb(0)
    for i in range(q.rows):
        for j in range(i + 1, q.cols):
            if q[i, j] > 0:
                fij, fji = pi[i] * q[i, j], pi[j] * q[j, i]
                result += arbq(fij - fji) * (arbq(fij) / arbq(fji)).log()
    return result


def main() -> None:
    ctx.prec = 160
    cert = json.loads(CERT.read_text(encoding="utf-8"))
    q, q0, direction, qc, s = build()
    s_lo, s_hi = map(parse, cert["family"]["s_interval"])
    assert s_lo < 15531 < s_hi and 15531 - s_lo == s_hi - 15531
    h = sp.Rational(s_hi - 15531)

    wc = cert["window_certificate"]
    v = matrix(wc["rational_similarity_matrix"])
    discs = verify_discs(q0, direction, v, h, wc["discs"])
    # Reconstruct every label from the exact discs; do not trust producer
    # indices.  This is part of the hostile branch-switching audit.
    dbounds = [{
        "re_lo": sp.re(d["center"]) - d["radius"],
        "re_hi": sp.re(d["center"]) + d["radius"],
        "im_lo": sp.im(d["center"]) - d["radius"],
        "im_hi": sp.im(d["center"]) + d["radius"],
    } for d in discs]
    targets = [i for i, d in enumerate(dbounds)
               if d["im_lo"] > 5000 and -7000 < d["re_lo"] < -5000]
    mates = [i for i, d in enumerate(dbounds)
             if d["im_hi"] < -5000 and -7000 < d["re_lo"] < -5000]
    stationary_candidates = [i for i, d in enumerate(dbounds)
                             if d["re_lo"] <= 0 <= d["re_hi"]
                             and d["im_lo"] <= 0 <= d["im_hi"]]
    assert len(targets) == len(mates) == len(stationary_candidates) == 1
    target_i, mate_i, stationary_i = targets[0], mates[0], stationary_candidates[0]
    others = [i for i in range(len(discs))
              if i not in (target_i, mate_i, stationary_i)]
    comp_i = max(others, key=lambda i: dbounds[i]["re_hi"])
    assert target_i == wc["target_index"]
    assert mate_i == wc["target_mate_index"]
    assert stationary_i == wc["stationary_index"]
    assert comp_i == wc["competitor_index"]
    target, comp = discs[target_i], discs[comp_i]
    vis_lo = sp.re(target["center"]) - target["radius"]
    vis_lo += sp.im(target["center"]) - target["radius"]
    lead_lo = sp.re(target["center"]) - target["radius"]
    lead_lo -= sp.re(comp["center"]) + comp["radius"]
    assert sp.cancel(vis_lo - parse(wc["visibility_lower_exact"])) == 0
    assert sp.cancel(lead_lo - parse(wc["leadership_lower_exact"])) == 0
    assert vis_lo > 0 and lead_lo > 0

    pi0 = stationary(q0)
    inserted = pi0[11] * 15531 / s
    rho = sp.Matrix([[*pi0[:11], inserted]])
    assert all(sp.cancel(x) == 0 for x in rho * q)
    normalizer = sum(pi0[:11]) + inserted
    sigma0 = entropy(q0, pi0)
    sigma_hi = sigma0 / arbq(normalizer.subs(s, s_hi))
    target_re_lo = sp.re(target["center"]) - target["radius"]
    target_im_lo = sp.im(target["center"]) - target["radius"]
    y_hi = sigma_hi * arbq(-target_re_lo) / arbq(target_im_lo) ** 2
    assert y_hi.upper() < 1

    cc = cert["contraction_certificate"]
    vc = matrix(cc["rational_similarity_matrix"])
    cdiscs = verify_discs(qc, sp.zeros(qc.rows), vc, sp.Rational(0), cc["discs"])
    ct, cp = cdiscs[cc["target_index"]], cdiscs[cc["competitor_index"]]
    cvis_hi = sp.re(ct["center"]) + ct["radius"] + sp.im(ct["center"]) + ct["radius"]
    clead_hi = sp.re(ct["center"]) + ct["radius"] - (sp.re(cp["center"]) - cp["radius"])
    assert cvis_hi < 0 and clead_hi < 0
    assert sp.cancel(cvis_hi - parse(cc["visibility_upper_exact"])) == 0
    assert sp.cancel(clead_hi - parse(cc["leadership_upper_exact"])) == 0

    result = {
        "no_eigensolver_used": True,
        "exact_similarity_recomputed": True,
        "window_discs_pairwise_disjoint": True,
        "contraction_discs_pairwise_disjoint": True,
        "s_interval": [str(s_lo), str(s_hi)],
        "visibility_lower": str(sp.N(vis_lo, 25)),
        "leadership_lower": str(sp.N(lead_lo, 25)),
        "Y_upper_arb": str(y_hi),
        "contraction_visibility_upper": str(sp.N(cvis_hi, 25)),
        "contraction_leadership_upper": str(sp.N(clead_hi, 25)),
        "status": "PASS",
    }
    OUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
