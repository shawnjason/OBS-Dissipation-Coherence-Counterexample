#!/usr/bin/env python3
"""Hostile independent audit of the causal Gershgorin window certificate.

This does not import either certificate-producing script.  It reconstructs the
rate family from the integer checkpoint, checks the emitted exact similarity
data, and uses exact rational Rouche tests on characteristic polynomials at the
two rational endpoints as a separate spectral route.
"""

from __future__ import annotations

import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np
import sympy as sp
from flint import arb, ctx


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "supporting/exact_inputs/n12_e13.json"
CERT = ROOT / "supporting/audit/gershgorin_window_certificate.json"
REOPT = ROOT / "supporting/exact_inputs/n11_reoptimized_frontier.json"
OUT = ROOT / "supporting/audit/hostile_verification_regenerated.json"

S0 = sp.Rational(15531)
SLO = sp.Rational(155289, 10)
SHI = sp.Rational(155331, 10)
ALPHA = sp.Rational(784, 15531)
P = sp.Rational(765968, 15531)
QREV = sp.Rational(201090092, 15531)
ROUND_DEN = 10**8
ROOT_RADIUS = sp.Rational(1, 10**5)


def parse(text: str) -> sp.Expr:
    return sp.sympify(text, locals={"I": sp.I})


def parse_matrix(rows: list[list[str]]) -> sp.Matrix:
    return sp.Matrix([[parse(x) for x in row] for row in rows])


def row_generator(k: sp.Matrix) -> sp.Matrix:
    q = k.copy()
    for i in range(k.rows):
        q[i, i] = -sum(k[i, j] for j in range(k.cols) if j != i)
    return q


def l1(z: sp.Expr) -> sp.Rational:
    z = sp.expand_complex(z)
    return abs(sp.Rational(sp.re(z))) + abs(sp.Rational(sp.im(z)))


def linf_lower(z: sp.Expr) -> sp.Rational:
    z = sp.expand_complex(z)
    return max(abs(sp.Rational(sp.re(z))), abs(sp.Rational(sp.im(z))))


def exact_family() -> tuple[sp.Matrix, sp.Matrix, sp.Matrix, sp.Matrix, sp.Symbol]:
    raw = json.loads(SOURCE.read_text(encoding="utf-8"))
    den = sp.Rational(raw.get("denominator", 1))
    k_center = sp.Matrix([[sp.Rational(x) / den for x in row]
                          for row in raw["integer_rate_numerators"]])
    s = sp.Symbol("s", positive=True)
    k = k_center.copy()
    for i, j in ((10, 11), (11, 10), (11, 9), (9, 11)):
        k[i, j] = 0
    # Independent derivation from the matched two-edge subdivision equations.
    k[10, 11] = P / ALPHA
    k[11, 10] = (1 - ALPHA) * s
    k[11, 9] = ALPHA * s
    k[9, 11] = QREV / (1 - ALPHA)
    q = row_generator(k)
    q0 = q.subs(s, S0)
    direction = q.diff(s)
    assert q0 == row_generator(k_center)
    assert q == q0 + (s - S0) * direction
    assert P == k[10, 11] * k[11, 9] / s
    assert QREV == k[9, 11] * k[11, 10] / s

    keep = list(range(11))
    kc = k_center.extract(keep, keep)
    kc[10, 9] = P
    kc[9, 10] = QREV
    qc = row_generator(kc)
    return q, q0, direction, qc, s


def stationary(q: sp.Matrix) -> list[sp.Rational]:
    a = q.T.copy()
    a[-1, :] = sp.ones(1, q.rows)
    rhs = sp.zeros(q.rows, 1)
    rhs[-1] = 1
    pi = [sp.Rational(x) for x in a.inv() * rhs]
    assert all(x > 0 for x in pi)
    assert sum(pi) == 1
    return pi


def arbq(x: sp.Expr) -> arb:
    x = sp.Rational(x)
    return arb(int(sp.numer(x))) / arb(int(sp.denom(x)))


def entropy(q: sp.Matrix, pi: list[sp.Rational]) -> arb:
    value = arb(0)
    for i in range(q.rows):
        for j in range(i + 1, q.cols):
            if q[i, j] > 0 or q[j, i] > 0:
                assert q[i, j] > 0 and q[j, i] > 0
                fij = pi[i] * q[i, j]
                fji = pi[j] * q[j, i]
                value += arbq(fij - fji) * (arbq(fij) / arbq(fji)).log()
    return value


def fixed_disc_audit(q0: sp.Matrix, direction: sp.Matrix, cert: dict) -> dict:
    wc = cert["window_certificate"]
    assert "actual row disk is contained" in wc["gershgorin_containment_argument"]
    v = parse_matrix(wc["rational_similarity_matrix"])
    assert v.det() != 0
    b0 = sp.simplify(v.inv() * q0 * v)
    b1 = sp.simplify(v.inv() * direction * v)
    h = SHI - S0
    assert h == S0 - SLO == sp.Rational(21, 10)
    discs = []
    for i in range(q0.rows):
        center = sp.expand_complex(b0[i, i])
        radius = h * l1(b1[i, i])
        radius += sum(l1(b0[i, j]) + h * l1(b1[i, j])
                      for j in range(q0.cols) if j != i)
        assert sp.cancel(center - parse(wc["discs"][i]["center"])) == 0
        assert sp.cancel(radius - parse(wc["discs"][i]["radius"])) == 0
        discs.append((center, radius))

    separation_slacks = []
    geometric_separations = []
    for i, (ci, ri) in enumerate(discs):
        for j in range(i):
            cj, rj = discs[j]
            delta = sp.expand_complex(ci - cj)
            slack_sq = sp.factor(sp.re(delta)**2 + sp.im(delta)**2 - (ri + rj)**2)
            assert slack_sq > 0
            separation_slacks.append((i, j, slack_sq))
            geometric_separations.append(
                (i, j, sp.sqrt(sp.re(delta)**2 + sp.im(delta)**2) - ri - rj))

    containing_zero = [i for i, (c, r) in enumerate(discs)
                       if sp.re(c)**2 + sp.im(c)**2 <= r**2]
    assert len(containing_zero) == 1
    stationary_i = containing_zero[0]
    assert q0 * sp.ones(q0.rows, 1) == sp.zeros(q0.rows, 1)

    upper = [i for i, (c, r) in enumerate(discs)
             if sp.im(c) - r > 5000 and -7000 < sp.re(c) - r < -5000]
    lower = [i for i, (c, r) in enumerate(discs)
             if sp.im(c) + r < -5000 and -7000 < sp.re(c) - r < -5000]
    assert len(upper) == len(lower) == 1
    target_i, mate_i = upper[0], lower[0]
    assert sp.cancel(discs[target_i][0] - sp.conjugate(discs[mate_i][0])) == 0
    assert discs[target_i][1] == discs[mate_i][1]
    assert target_i == wc["target_index"]
    assert mate_i == wc["target_mate_index"]
    assert stationary_i == wc["stationary_index"]

    others = [i for i in range(len(discs))
              if i not in (target_i, mate_i, stationary_i)]
    competitor_i = max(others, key=lambda i: sp.re(discs[i][0]) + discs[i][1])
    assert competitor_i == wc["competitor_index"]
    tc, tr = discs[target_i]
    cc, cr = discs[competitor_i]
    visibility = sp.re(tc) - tr + sp.im(tc) - tr
    leadership = sp.re(tc) - tr - (sp.re(cc) + cr)
    assert sp.cancel(visibility - parse(wc["visibility_lower_exact"])) == 0
    assert sp.cancel(leadership - parse(wc["leadership_lower_exact"])) == 0
    assert visibility > 0 and leadership > 0
    tight_pair = min(geometric_separations, key=lambda item: float(sp.N(item[2], 20)))

    # Every actual row Gershgorin disk lies in its corresponding fixed disk.
    # Since the fixed disks are disjoint, the actual row disks are disjoint;
    # Gershgorin's second theorem therefore assigns exactly one root to each.
    return {
        "target_index": target_i,
        "mate_index_reconstructed": mate_i,
        "stationary_index_reconstructed": stationary_i,
        "competitor_index": competitor_i,
        "visibility_lower": str(sp.N(visibility, 30)),
        "leadership_lower": str(sp.N(leadership, 30)),
        "pair_count_checked": len(separation_slacks),
        "minimum_geometric_disc_separation": {
            "pair": [tight_pair[0], tight_pair[1]],
            "decimal": str(sp.N(tight_pair[2], 30)),
        },
        "one_root_per_disk_theorem_conditions": True,
    }


def rational_center(z: complex) -> sp.Expr:
    if abs(z.real) < 1e-7 and abs(z.imag) < 1e-7:
        return sp.Integer(0)
    return (sp.Rational(int(round(z.real * ROUND_DEN)), ROUND_DEN)
            + sp.I * sp.Rational(int(round(z.imag * ROUND_DEN)), ROUND_DEN))


def rouche_isolate(poly: sp.Poly, center: sp.Expr, radius: sp.Rational) -> sp.Rational:
    z = poly.gens[0]
    coeffs = [sp.expand(poly.diff((z, k)).eval(center) / math.factorial(k))
              for k in range(poly.degree() + 1)]
    linear_lower = linf_lower(coeffs[1]) * radius
    rest_upper = l1(coeffs[0])
    rest_upper += sum(l1(coeffs[k]) * radius**k for k in range(2, len(coeffs)))
    margin = sp.factor(linear_lower - rest_upper)
    assert margin > 0
    return margin


def endpoint_charpoly_audit(q: sp.Matrix, s: sp.Symbol, endpoint: sp.Rational) -> dict:
    qe = q.subs(s, endpoint)
    z = sp.Symbol("z")
    poly = sp.Poly(qe.charpoly(z).as_expr(), z, domain=sp.QQ)
    assert poly.degree() == 12
    assert poly.eval(0) == 0
    roots_float = np.linalg.eigvals(np.asarray(qe.tolist(), dtype=float))
    centers = [rational_center(complex(x)) for x in roots_float]
    # Numerical values choose boxes only.  Each box is then independently
    # certified by an exact rational Rouche inequality for the exact charpoly.
    margins = [rouche_isolate(poly, c, ROOT_RADIUS) for c in centers]
    for i, ci in enumerate(centers):
        for j in range(i):
            delta = sp.expand_complex(ci - centers[j])
            assert sp.re(delta)**2 + sp.im(delta)**2 > (2 * ROOT_RADIUS)**2

    target = [i for i, c in enumerate(centers)
              if sp.im(c) > 5000 and -7000 < sp.re(c) < -5000]
    mate = [i for i, c in enumerate(centers)
            if sp.im(c) < -5000 and -7000 < sp.re(c) < -5000]
    stationary = [i for i, c in enumerate(centers) if c == 0]
    assert len(target) == len(mate) == len(stationary) == 1
    ti, mi, si = target[0], mate[0], stationary[0]
    assert centers[ti] == sp.conjugate(centers[mi])
    others = [i for i in range(12) if i not in (ti, mi, si)]
    competitor = max(others, key=lambda i: sp.re(centers[i]) + ROOT_RADIUS)
    visibility = (sp.re(centers[ti]) - ROOT_RADIUS
                  + sp.im(centers[ti]) - ROOT_RADIUS)
    leadership = (sp.re(centers[ti]) - ROOT_RADIUS
                  - (sp.re(centers[competitor]) + ROOT_RADIUS))
    assert visibility > 0 and leadership > 0
    return {
        "endpoint": str(endpoint),
        "charpoly_degree": poly.degree(),
        "all_12_roots_exactly_isolated": True,
        "rouche_radius": str(ROOT_RADIUS),
        "minimum_rouche_margin_decimal": str(sp.N(min(margins), 15)),
        "target_center": str(centers[ti]),
        "mate_center": str(centers[mi]),
        "competitor_center": str(centers[competitor]),
        "visibility_lower": str(sp.N(visibility, 20)),
        "leadership_lower": str(sp.N(leadership, 20)),
    }


def contraction_audit(qc: sp.Matrix, cert: dict) -> dict:
    cc = cert["contraction_certificate"]
    v = parse_matrix(cc["rational_similarity_matrix"])
    b = sp.simplify(v.inv() * qc * v)
    discs = []
    for i in range(qc.rows):
        center = sp.expand_complex(b[i, i])
        radius = sum(l1(b[i, j]) for j in range(qc.cols) if j != i)
        assert center == parse(cc["discs"][i]["center"])
        assert radius == parse(cc["discs"][i]["radius"])
        discs.append((center, radius))
    for i, (ci, ri) in enumerate(discs):
        for j in range(i):
            cj, rj = discs[j]
            d = sp.expand_complex(ci - cj)
            assert sp.re(d)**2 + sp.im(d)**2 > (ri + rj)**2
    stationary = [i for i, (c, r) in enumerate(discs)
                  if sp.re(c)**2 + sp.im(c)**2 <= r**2]
    assert len(stationary) == 1
    ti = cc["target_index"]
    mate = [i for i, (c, r) in enumerate(discs)
            if sp.cancel(c - sp.conjugate(discs[ti][0])) == 0 and r == discs[ti][1]]
    assert len(mate) == 1
    others = [i for i in range(len(discs)) if i not in (ti, mate[0], stationary[0])]
    comp = max(others, key=lambda i: sp.re(discs[i][0]) + discs[i][1])
    assert comp == cc["competitor_index"]
    vis_hi = sum((sp.re(discs[ti][0]), sp.im(discs[ti][0]), 2 * discs[ti][1]))
    lead_hi = (sp.re(discs[ti][0]) + discs[ti][1]
               - (sp.re(discs[comp][0]) - discs[comp][1]))
    assert vis_hi < 0 and lead_hi < 0
    return {
        "identifier": cc["identifier"],
        "stationary_index_reconstructed": stationary[0],
        "mate_index_reconstructed": mate[0],
        "competitor_index": comp,
        "visibility_upper": str(sp.N(vis_hi, 25)),
        "leadership_upper": str(sp.N(lead_hi, 25)),
    }


def main() -> None:
    ctx.prec = 180
    cert = json.loads(CERT.read_text(encoding="utf-8"))
    assert list(map(parse, cert["family"]["s_interval"])) == [SLO, SHI]
    assert parse(cert["family"]["alpha"]) == ALPHA
    assert parse(cert["family"]["contracted_rates"]["11_to_10"]) == P
    assert parse(cert["family"]["contracted_rates"]["10_to_11"]) == QREV
    q, q0, direction, qc, s = exact_family()

    # All four present subdivision rates are strictly positive throughout.
    variable_rates = [(1 - ALPHA) * s, ALPHA * s]
    assert all(rate.subs(s, SLO) > 0 and rate.subs(s, SHI) > 0
               for rate in variable_rates)
    for endpoint in (SLO, SHI):
        qe = q.subs(s, endpoint)
        assert all(qe[i, j] >= 0 for i in range(12) for j in range(12) if i != j)
        assert all((qe[i, j] > 0) == (qe[j, i] > 0)
                   for i in range(12) for j in range(12) if i != j)

    pi0 = stationary(q0)
    inserted = pi0[11] * S0 / s
    rho = sp.Matrix([[*pi0[:11], inserted]])
    assert rho * q == sp.zeros(1, 12)
    normalizer = sp.factor(sum(pi0[:11]) + inserted)
    recorded_stationary = cert["family"]["stationary_unnormalized_formula"]
    assert list(map(parse, recorded_stationary["old_state_weights"])) == pi0[:11]
    recorded_inserted = sp.sympify(recorded_stationary["inserted_weight"], locals={"s": s})
    recorded_normalizer = sp.sympify(recorded_stationary["normalizer"], locals={"s": s})
    assert sp.cancel(recorded_inserted - inserted) == 0
    assert sp.cancel(recorded_normalizer - normalizer) == 0
    normalizer_derivative = sp.factor(sp.diff(normalizer, s))
    assert sp.cancel(normalizer_derivative + pi0[11] * S0 / s**2) == 0
    assert pi0[11] * S0 > 0
    for endpoint in (SLO, SHI):
        zval = normalizer.subs(s, endpoint)
        pie = [sp.factor(x.subs(s, endpoint) / zval) for x in rho]
        assert all(x > 0 for x in pie) and sum(pie) == 1
        assert sp.Matrix([pie]) * q.subs(s, endpoint) == sp.zeros(1, 12)

    # Stronger than merely checking the final entropy number: every unordered
    # edge's two unnormalised stationary fluxes are constant in s.
    for i in range(12):
        for j in range(i + 1, 12):
            if q[i, j] != 0 or q[j, i] != 0:
                assert sp.diff(sp.factor(rho[i] * q[i, j]), s) == 0
                assert sp.diff(sp.factor(rho[j] * q[j, i]), s) == 0
    sigma0 = entropy(q0, pi0)
    sigma_hi = sigma0 / arbq(normalizer.subs(s, SHI))

    uniform = fixed_disc_audit(q0, direction, cert)
    endpoint_audits = [endpoint_charpoly_audit(q, s, x) for x in (SLO, SHI)]
    contraction = contraction_audit(qc, cert)

    # Structural lineage firewall, reconstructed from the actual supports.
    contraction_edges = sum(1 for i in range(11) for j in range(i + 1, 11)
                            if qc[i, j] > 0 or qc[j, i] > 0)
    assert contraction_edges == 12
    assert qc[2, 8] == 0 and qc[8, 2] == 0
    reopt_raw = json.loads(REOPT.read_text(encoding="utf-8"))
    reopt = reopt_raw["rates"]
    reopt_edges = sum(1 for i in range(11) for j in range(i + 1, 11)
                      if reopt[i][j] > 0 or reopt[j][i] > 0)
    assert reopt_raw["n"] == 11 and reopt_edges == 13
    assert reopt[2][8] > 0 and reopt[8][2] > 0

    wc = cert["window_certificate"]
    target_disc = wc["discs"][wc["target_index"]]
    target_center = parse(target_disc["center"])
    target_radius = parse(target_disc["radius"])
    y_hi = (sigma_hi * arbq(-(sp.re(target_center) - target_radius))
            / arbq(sp.im(target_center) - target_radius)**2)
    assert y_hi.upper() < 1

    payload = {
        "status": "PASS",
        "exact_family_and_center_checkpoint_match": True,
        "rate_positivity_on_closed_interval": True,
        "normalized_stationary_law_verified_at_both_endpoints": True,
        "stationarity_verified_symbolically_for_all_positive_s": True,
        "all_unnormalized_edge_fluxes_constant_in_s": True,
        "entropy_scaling_sigma_s_equals_sigma_center_over_normalizer": True,
        "sigma_upper_recomputed": str(sigma_hi),
        "Y_upper_recomputed": str(y_hi),
        "uniform_fixed_disc_audit": uniform,
        "independent_exact_endpoint_charpoly_rouche_audits": endpoint_audits,
        "exact_contraction_audit": contraction,
        "lineage_audit": {
            "n11_exact_contraction": "11 states, 12 undirected edges, cycle rank 2, no 3--9 chord (support independently counted)",
            "n11_reoptimized_frontier": "distinct 11-state, 13-edge, cycle-rank-3 system with 3--9 chord (support independently counted); not used",
            "names_not_interchangeable": True,
        },
        "corrected_auditability_objections": [
            "RESOLVED: target_mate_index and stationary_index are emitted and checked.",
            "RESOLVED: the portable verifier reconstructs the target mate, stationary root, and active competitor from exact discs.",
            "RESOLVED: the actual-row-disc containment theorem is serialized and checked.",
        ],
    }
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
