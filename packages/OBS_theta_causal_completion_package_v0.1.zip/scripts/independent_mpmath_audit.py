#!/usr/bin/env python3
"""Independent 80-digit reconstruction of L=3..9 from the parameter rule."""
from fractions import Fraction as F
from pathlib import Path
import json
import mpmath as mp

ROOT=Path(__file__).resolve().parents[1];mp.mp.dps=80
P=json.loads((ROOT/'OBS_role_layer_exact_member.json').read_text())['parameters'];f=lambda x:F(P[x]); mm=lambda x:mp.mpf(x.numerator)/x.denominator
rows=[]
for L in range(3,10):
 raw=[f(x) for x in ('m_u','m_v','M1','M2','M3')];Z=sum(raw)
 pi=[raw[0]/Z,raw[1]/Z,f('M1')*f('rho')/Z,f('M1')*(1-f('rho'))/Z]+[f('M2')/(L-1)/Z]*(L-1)+[f('M3')/(L-1)/Z]*(L-1)
 paths=[[0,2,3,1],[0,*range(4,L+3),1],[0,*range(L+3,2*L+2),1]];Js=[f('J1'),f('J2'),-f('J1')-f('J2')]
 Ts=[[f('T1_in'),f('T1_mid'),f('T1_out')],[f('T2_bulk')]*(L-1)+[f('T2_exit')],[f('T3_entry')]+[f('T3_bulk')]*(L-1)]
 n=2*L+2;k=[[F(0)for _ in range(n)]for _ in range(n)]
 for ns,J,ts in zip(paths,Js,Ts):
  for a,b,T in zip(ns,ns[1:],ts):k[a][b]=(T+J)/(2*pi[a]);k[b][a]=(T-J)/(2*pi[b])
 q=mp.matrix(n)
 for i in range(n):
  for j in range(n):q[i,j]=mm(k[i][j])
  q[i,i]=-sum(mm(x) for x in k[i])
 vals=mp.eig(q,left=False,right=False); target=max((z for z in vals if mp.im(z)>mp.mpf('1e-40')),key=lambda z:mp.re(z))
 others=[mp.re(z) for z in vals if abs(z)>mp.mpf('1e-40') and abs(z-target)>mp.mpf('1e-30') and abs(z-mp.conj(target))>mp.mpf('1e-30')]
 sigma=mp.mpf(0)
 for i in range(n):
  for j in range(i+1,n):
   if k[i][j]:sigma+=(mm(pi[i]*k[i][j]-pi[j]*k[j][i]))*mp.log(mm(k[i][j]/k[j][i]))
 rows.append({"L":L,"lambda_real":mp.nstr(mp.re(target),50),"lambda_imag":mp.nstr(mp.im(target),50),
  "Y":mp.nstr(sigma*(-mp.re(target))/mp.im(target)**2,50),"visibility":mp.nstr(mp.im(target)+mp.re(target),50),
  "leading_gap":mp.nstr(mp.re(target)-max(others),50)})
out=ROOT/'supporting'/'role_family'/'independent_mpmath_L3_L9_regenerated.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
