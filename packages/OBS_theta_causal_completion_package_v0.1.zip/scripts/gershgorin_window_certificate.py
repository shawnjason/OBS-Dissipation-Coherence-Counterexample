#!/usr/bin/env python3
"""Independent exact-similarity certificate for a matched-subdivision window.

The proof uses one fixed rational complex similarity V.  For the affine exact
family Q(s)=Q(s0)+(s-s0)A, every transformed row is enclosed in a fixed
Gershgorin disc over a rational s interval.  Pairwise-disjoint discs certify
one and only one eigenvalue in every disc for every parameter value.  No
floating-point eigenvalue is used in the final inequalities; NumPy is used
only to choose a rational preconditioner V, after which all matrix operations
and comparisons are exact over QQ(i).  Arb is used only for the logarithms in
the entropy upper bound.
"""

from __future__ import annotations

import json
from fractions import Fraction
from pathlib import Path

import numpy as np
import sympy as sp
from flint import arb, ctx


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "supporting/exact_inputs/n12_e13.json"
OUT = ROOT / "supporting/audit/gershgorin_window_certificate_regenerated.json"
S0 = sp.Rational(15531)
H = sp.Rational(21, 10)
ALPHA = sp.Rational(784, 15531)
P = sp.Rational(765968, 15531)
QRATE = sp.Rational(201090092, 15531)
ROUND_DEN = 10**12


def q_from_rates(k: sp.Matrix) -> sp.Matrix:
    q = k.copy()
    for i in range(q.rows):
        q[i, i] = -sum(q[i, j] for j in range(q.cols) if j != i)
    return q


def exact_family() -> tuple[sp.Matrix, sp.Matrix, sp.Matrix]:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    den = sp.Rational(data.get("denominator", 1))
    k0 = sp.Matrix([[sp.Rational(x) / den for x in row]
                    for row in data["integer_rate_numerators"]])
    # Reconstruct rather than trust the four displayed center rates.
    s = sp.Symbol("s", positive=True)
    k = k0.copy()
    for i, j in ((10, 11), (11, 10), (11, 9), (9, 11)):
        k[i, j] = 0
    k[10, 11] = P / ALPHA
    k[11, 10] = (1 - ALPHA) * s
    k[11, 9] = ALPHA * s
    k[9, 11] = QRATE / (1 - ALPHA)
    q = q_from_rates(k)
    q0 = q.subs(s, S0)
    a = q.diff(s)
    assert q == q0 + (s - S0) * a
    assert q0 == q_from_rates(k0)
    return q, q0, a


def contraction(q0: sp.Matrix) -> sp.Matrix:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    k0 = sp.Matrix([[sp.Rational(x) for x in row]
                    for row in data["integer_rate_numerators"]])
    keep = [i for i in range(12) if i != 11]
    k = k0.extract(keep, keep)
    # Old index 10 remains 10; old index 9 remains 9.
    k[10, 9] = P
    k[9, 10] = QRATE
    return q_from_rates(k)


def rationalize_complex(value: complex) -> sp.Expr:
    re = sp.Rational(int(round(value.real * ROUND_DEN)), ROUND_DEN)
    im = sp.Rational(int(round(value.imag * ROUND_DEN)), ROUND_DEN)
    return re + sp.I * im


def rational_preconditioner(q: sp.Matrix) -> sp.Matrix:
    qf = np.asarray(q.tolist(), dtype=float)
    vals, vecs = np.linalg.eig(qf)
    order = sorted(range(len(vals)), key=lambda i: (vals[i].real, vals[i].imag), reverse=True)
    cols = []
    for idx in order:
        v = vecs[:, idx]
        pivot = int(np.argmax(np.abs(v)))
        v = v / v[pivot]
        cols.append([rationalize_complex(complex(x)) for x in v])
    vq = sp.Matrix.hstack(*(sp.Matrix(col) for col in cols))
    assert vq.det() != 0
    return vq


def l1_complex(x: sp.Expr) -> sp.Rational:
    x = sp.expand_complex(x)
    return abs(sp.Rational(sp.re(x))) + abs(sp.Rational(sp.im(x)))


def disc_cover(q0: sp.Matrix, a: sp.Matrix, h: sp.Rational) -> dict:
    v = rational_preconditioner(q0)
    vi = v.inv()
    b0 = sp.simplify(vi * q0 * v)
    b1 = sp.simplify(vi * a * v)
    discs = []
    for i in range(q0.rows):
        center = sp.expand_complex(b0[i, i])
        radius = h * l1_complex(b1[i, i])
        for j in range(q0.cols):
            if i != j:
                radius += l1_complex(b0[i, j]) + h * l1_complex(b1[i, j])
        discs.append({"center": center, "radius": sp.factor(radius)})

    for i in range(len(discs)):
        for j in range(i):
            delta = sp.expand_complex(discs[i]["center"] - discs[j]["center"])
            distance_squared = sp.re(delta) ** 2 + sp.im(delta) ** 2
            radii_squared = (discs[i]["radius"] + discs[j]["radius"]) ** 2
            assert sp.factor(distance_squared - radii_squared) > 0

    def bounds(d: dict) -> dict:
        c, r = d["center"], d["radius"]
        return {
            "re_lo": sp.Rational(sp.re(c)) - r,
            "re_hi": sp.Rational(sp.re(c)) + r,
            "im_lo": sp.Rational(sp.im(c)) - r,
            "im_hi": sp.Rational(sp.im(c)) + r,
        }

    bounded = [bounds(d) for d in discs]
    target_candidates = [i for i, d in enumerate(bounded)
                         if d["im_lo"] > 5000 and -7000 < d["re_lo"] < -5000]
    assert len(target_candidates) == 1
    target_i = target_candidates[0]
    mate_candidates = [i for i, d in enumerate(bounded)
                       if d["im_hi"] < -5000 and -7000 < d["re_lo"] < -5000]
    assert len(mate_candidates) == 1
    mate_i = mate_candidates[0]
    stationary_candidates = [i for i, d in enumerate(bounded)
                             if d["re_lo"] <= 0 <= d["re_hi"]
                             and d["im_lo"] <= 0 <= d["im_hi"]]
    assert len(stationary_candidates) == 1
    stationary_i = stationary_candidates[0]
    others = [i for i in range(len(discs))
              if i not in (target_i, mate_i, stationary_i)]
    competitor_i = max(others, key=lambda i: bounded[i]["re_hi"])
    target, competitor = bounded[target_i], bounded[competitor_i]
    visibility_lower = target["im_lo"] + target["re_lo"]
    leadership_lower = target["re_lo"] - competitor["re_hi"]
    if not (visibility_lower > 0 and leadership_lower > 0):
        print({
            "diagnostic_h": str(h),
            "visibility_lower": str(sp.N(visibility_lower, 18)),
            "leadership_lower": str(sp.N(leadership_lower, 18)),
            "target_radius": str(sp.N(discs[target_i]["radius"], 18)),
            "competitor_radius": str(sp.N(discs[competitor_i]["radius"], 18)),
        }, flush=True)
    assert visibility_lower > 0
    assert leadership_lower > 0
    return {
        "V": v,
        "discs": discs,
        "bounds": bounded,
        "target_index": target_i,
        "target_mate_index": mate_i,
        "stationary_index": stationary_i,
        "competitor_index": competitor_i,
        "visibility_lower": visibility_lower,
        "leadership_lower": leadership_lower,
    }


def stationary_exact(q0: sp.Matrix) -> list[sp.Rational]:
    n = q0.rows
    a = q0.T.copy()
    a[n - 1, :] = sp.ones(1, n)
    rhs = sp.zeros(n, 1)
    rhs[n - 1] = 1
    sol = a.inv() * rhs
    ans = [sp.Rational(x) for x in sol]
    assert all(x > 0 for x in ans) and sum(ans) == 1
    return ans


def arbq(x: sp.Rational) -> arb:
    return arb(int(sp.numer(x))) / arb(int(sp.denom(x)))


def entropy_center(q0: sp.Matrix, pi: list[sp.Rational]) -> arb:
    # q0 is a row generator; positive off-diagonals are rates.
    sigma = arb(0)
    for i in range(q0.rows):
        for j in range(i + 1, q0.cols):
            if q0[i, j] > 0:
                fij = pi[i] * q0[i, j]
                fji = pi[j] * q0[j, i]
                sigma += arbq(fij - fji) * (arbq(fij) / arbq(fji)).log()
    return sigma


def contraction_cover(qc: sp.Matrix) -> dict:
    zero = sp.zeros(qc.rows)
    cover = disc_cover_fixed(qc)
    return cover


def disc_cover_fixed(q: sp.Matrix) -> dict:
    v = rational_preconditioner(q)
    b = sp.simplify(v.inv() * q * v)
    discs, bounds = [], []
    for i in range(q.rows):
        center = sp.expand_complex(b[i, i])
        radius = sum(l1_complex(b[i, j]) for j in range(q.cols) if i != j)
        d = {"center": center, "radius": sp.factor(radius)}
        discs.append(d)
        bounds.append({
            "re_lo": sp.Rational(sp.re(center)) - radius,
            "re_hi": sp.Rational(sp.re(center)) + radius,
            "im_lo": sp.Rational(sp.im(center)) - radius,
            "im_hi": sp.Rational(sp.im(center)) + radius,
        })
    for i in range(len(discs)):
        for j in range(i):
            delta = sp.expand_complex(discs[i]["center"] - discs[j]["center"])
            assert sp.factor(sp.re(delta) ** 2 + sp.im(delta) ** 2
                             - (discs[i]["radius"] + discs[j]["radius"]) ** 2) > 0
    target = [i for i, d in enumerate(bounds)
              if d["im_lo"] > 5000 and -7000 < d["re_lo"] < -6000]
    assert len(target) == 1
    target_i = target[0]
    mate = [i for i, d in enumerate(bounds)
            if d["im_hi"] < -5000 and -7000 < d["re_lo"] < -6000]
    stationary = [i for i, d in enumerate(bounds)
                  if d["re_lo"] <= 0 <= d["re_hi"]
                  and d["im_lo"] <= 0 <= d["im_hi"]]
    assert len(stationary) == 1
    others = [i for i in range(len(bounds))
              if i not in (target_i, *mate, *stationary)]
    competitor_i = max(others, key=lambda i: bounds[i]["re_hi"])
    vis_upper = bounds[target_i]["im_hi"] + bounds[target_i]["re_hi"]
    lead_upper = bounds[target_i]["re_hi"] - bounds[competitor_i]["re_lo"]
    assert vis_upper < 0 and lead_upper < 0
    return {
        "V": v,
        "discs": discs,
        "bounds": bounds,
        "target_index": target_i,
        "competitor_index": competitor_i,
        "visibility_upper": vis_upper,
        "leadership_upper": lead_upper,
    }


def encode(x):
    if isinstance(x, sp.MatrixBase):
        return [[str(x[i, j]) for j in range(x.cols)] for i in range(x.rows)]
    if isinstance(x, dict):
        return {k: encode(v) for k, v in x.items()}
    if isinstance(x, list):
        return [encode(v) for v in x]
    if isinstance(x, sp.Basic):
        return str(x)
    return x


def main() -> None:
    ctx.prec = 160
    q, q0, a = exact_family()
    cover = disc_cover(q0, a, H)
    pi0 = stationary_exact(q0)

    s = sp.Symbol("s", positive=True)
    inserted = pi0[11] * S0 / s
    z_norm = sum(pi0[:11]) + inserted
    rho = sp.Matrix([[*pi0[:11], inserted]])
    assert all(sp.cancel(x) == 0 for x in (rho * q))

    sigma0 = entropy_center(q0, pi0)
    z_min = z_norm.subs(s, S0 + H)
    sigma_upper = sigma0 / arbq(sp.Rational(z_min))
    target = cover["bounds"][cover["target_index"]]
    y_upper = sigma_upper * arbq(-target["re_lo"]) / (arbq(target["im_lo"]) ** 2)
    assert y_upper.upper() < 1

    qc = contraction(q0)
    contraction_result = disc_cover_fixed(qc)
    payload = {
        "method": "exact QQ(i) similarity plus fixed disjoint Gershgorin discs; Arb only for logarithms",
        "family": {
            "s_interval": [str(S0 - H), str(S0 + H)],
            "s_center": str(S0),
            "alpha": str(ALPHA),
            "contracted_rates": {"11_to_10": str(P), "10_to_11": str(QRATE)},
            "Q_affine_verified_exactly": True,
            "stationary_unnormalized_formula": {
                "old_state_weights": [str(x) for x in pi0[:11]],
                "inserted_weight": str(pi0[11] * S0) + "/s",
                "normalizer": str(z_norm),
                "stationarity_verified_symbolically": True,
            },
            "zero_frequency_invariants": ["current", "affinity", "segment entropy", "DC Schur response"],
        },
        "window_certificate": {
            "all_discs_pairwise_disjoint_exactly": True,
            "root_count": q0.rows,
            "target_index": cover["target_index"],
            "target_mate_index": cover["target_mate_index"],
            "stationary_index": cover["stationary_index"],
            "competitor_index": cover["competitor_index"],
            "visibility_lower_exact": str(cover["visibility_lower"]),
            "visibility_lower_decimal": str(sp.N(cover["visibility_lower"], 20)),
            "leadership_lower_exact": str(cover["leadership_lower"]),
            "leadership_lower_decimal": str(sp.N(cover["leadership_lower"], 20)),
            "sigma_center_arb": str(sigma0),
            "sigma_upper_arb": str(sigma_upper),
            "Y_upper_arb": str(y_upper),
            "rational_similarity_matrix": encode(cover["V"]),
            "gershgorin_containment_argument": "For each row and |s-s0|<=h, the actual center displacement is bounded by h*|B1_ii| and every actual off-diagonal modulus by |B0_ij|+h*|B1_ij|. Therefore the actual row disk is contained in the recorded fixed disk. Pairwise-disjoint fixed disks imply pairwise-disjoint actual row disks; Gershgorin's second theorem assigns exactly one eigenvalue to each disk.",
            "discs": encode(cover["discs"]),
            "root_bounds": encode(cover["bounds"]),
        },
        "contraction_certificate": {
            "identifier": "n11_exact_contraction",
            "edge_count": 12,
            "cycle_rank": 2,
            "all_discs_pairwise_disjoint_exactly": True,
            "target_index": contraction_result["target_index"],
            "competitor_index": contraction_result["competitor_index"],
            "visibility_upper_exact": str(contraction_result["visibility_upper"]),
            "visibility_upper_decimal": str(sp.N(contraction_result["visibility_upper"], 20)),
            "leadership_upper_exact": str(contraction_result["leadership_upper"]),
            "leadership_upper_decimal": str(sp.N(contraction_result["leadership_upper"], 20)),
            "rational_similarity_matrix": encode(contraction_result["V"]),
            "discs": encode(contraction_result["discs"]),
            "root_bounds": encode(contraction_result["bounds"]),
        },
        "claim_level": "CERTIFIED - EXACT/INTERVAL",
    }
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({
        "s_interval": payload["family"]["s_interval"],
        "visibility_lower": payload["window_certificate"]["visibility_lower_decimal"],
        "leadership_lower": payload["window_certificate"]["leadership_lower_decimal"],
        "Y_upper": payload["window_certificate"]["Y_upper_arb"],
        "contraction_visibility_upper": payload["contraction_certificate"]["visibility_upper_decimal"],
        "contraction_leadership_upper": payload["contraction_certificate"]["leadership_upper_decimal"],
        "output": str(OUT),
    }, indent=2))


if __name__ == "__main__":
    main()
