#!/usr/bin/env python3
"""Exact polynomial certificate for two matched-subdivision contexts."""

from fractions import Fraction as F
from itertools import permutations
import json


def add(a, b):
    n = max(len(a), len(b)); out = [F(0)] * n
    for i in range(n):
        out[i] = (a[i] if i < len(a) else 0) + (b[i] if i < len(b) else 0)
    while len(out) > 1 and out[-1] == 0: out.pop()
    return out


def mul(a, b):
    out = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): out[i+j] += x*y
    while len(out) > 1 and out[-1] == 0: out.pop()
    return out


def scale(a, c): return [c*x for x in a]


def parity(p):
    return -1 if sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1, len(p))) % 2 else 1


def det(m):
    ans = [F(0)]
    for p in permutations(range(len(m))):
        term = [F(parity(p))]
        for i, j in enumerate(p): term = mul(term, m[i][j])
        ans = add(ans, term)
    return ans


def minor(m, row, col):
    return [[m[i][j] for j in range(len(m)) if j != col] for i in range(len(m)) if i != row]


def matrix(a, b, c, d, p=1, qrate=1):
    # M=zI-Q for fixed p,q on 0--1 and the four context rates.
    q = [[-(p+a), p, a], [qrate, -(qrate+c), c], [b, d, -(b+d)]]
    return [[[F(-q[i][j]), F(1) if i == j else F(0)] for j in range(3)] for i in range(3)]


def fmt(poly):
    return [str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}" for x in poly]


def certificate(a, b, c, d, p=1, qrate=1):
    m = matrix(a, b, c, d, p=p, qrate=qrate)
    ppoly = det(m)
    # alpha=1/2: c=(p,q,0), d=(1,1,0), A=d^T adj(M)c.
    cvec = [F(p), F(qrate)]
    aa = [F(0)]
    for i in range(2):
        for j in range(2):
            cofactor_ji = scale(det(minor(m, j, i)), F((-1) ** (i+j)))
            aa = add(aa, scale(cofactor_ji, cvec[j]))
    return {"context_rates": [a,b,c,d], "P_coefficients_low_to_high": fmt(ppoly), "A_coefficients_low_to_high": fmt(aa)}


if __name__ == "__main__":
    right = certificate(1,2,2,1,p=2,qrate=1)
    left = certificate(2,3,2,1,p=2,qrate=1)
    assert right["P_coefficients_low_to_high"] == ["0", "21", "9", "1"]
    assert right["A_coefficients_low_to_high"] == ["42", "22", "3"]
    assert left["P_coefficients_low_to_high"] == ["0", "30", "11", "1"]
    assert left["A_coefficients_low_to_high"] == ["60", "26", "3"]
    print(json.dumps({
        "exploratory_pair_local_edge": {"p": 1, "q": 1, "alpha": "1/2"},
        "right_motion_context": certificate(1,1,1,2),
        "left_motion_context": certificate(1,2,2,2),
        "same_stationary_invariants_local_edge": {"p": 2, "q": 1, "alpha": "1/2"},
        "same_stationary_invariants_right": right,
        "same_stationary_invariants_left": left,
        "same_stationary_invariants": {
            "stationary_distribution": ["1/3", "1/3", "1/3"],
            "edge_forward_flow": "2/3",
            "edge_backward_flow": "1/3",
            "edge_current": "1/3",
            "edge_traffic": "1",
            "edge_affinity": "log(2)",
            "inserted_unnormalized_mass": "2/s"
        },
        "reduced_Evans": "E(z,epsilon)=P(z)+epsilon*z/(1+epsilon*z)*A(z)",
        "root_derivative": "dz/depsilon|0=-z*A(z)/P'(z)",
        "motion_certificates": {
            "right_positive_imaginary_root": {
                "root": "(-9+i*sqrt(3))/2",
                "derivative": "5/2+i*sqrt(3)/2",
                "real_derivative": "5/2"
            },
            "left_root_minus_5": {"root": "-5", "derivative": "-5"},
            "left_root_minus_6": {"root": "-6", "derivative": "12"}
        }
    }, indent=2))
