#!/usr/bin/env python3
"""Audit the exact role-family result and its explicit-box claim firewall."""

from __future__ import annotations

import json
from fractions import Fraction
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main() -> None:
    box = json.loads((HERE / "OBS_role_layer_interval_box.json").read_text(encoding="utf-8"))
    cert = json.loads((HERE / "supporting/role_family/exact_member_certificate.json").read_text(encoding="utf-8"))
    assert cert["success_certified"] is True
    assert cert["Y_upper"] < 1
    assert Fraction(cert["visibility_lower"]) > 0
    assert Fraction(cert["leading_gap_lower"]) > 0
    assert box["dimension"] == 15
    assert box["explicit_rational_half_widths"] is None
    assert box["status"] == "RIGOROUS_OPEN_NEIGHBORHOOD_EXISTS_BUT_NO_EXPLICIT_BOX_CERTIFIED"
    print(json.dumps({
        "exact_member": "CERTIFIED",
        "full_dimensional_open_neighborhood_exists": True,
        "explicit_rational_box_certified": False,
        "claim_firewall": box["claim_firewall"],
        "status": "PASS"
    }, indent=2))


if __name__ == "__main__":
    main()
