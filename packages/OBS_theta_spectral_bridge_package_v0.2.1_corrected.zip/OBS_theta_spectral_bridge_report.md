# OBS theta spectral bridge — corrected audit version

Resolution: **NOT RESOLVED — MAJOR SPECTRAL BRIDGE ADVANCE**

Correction version: **v0.2.1**

This correction separates the exact 11-state matched contraction from the independently reoptimized 11-state frontier. It also restores the matched-subdivision relative-ordering statement to an open causal lemma rather than treating it as resolved.

## 1. Result in one paragraph

The certified 12-state theta witness contains a relaxation pair born at a
nondegenerate exceptional point of the exact stationary-law-preserving
circulation homotopy `Q(epsilon)=Q_rev+epsilon Q_circ`.  A separately
reoptimized, valid-leading 11-state frontier has the same qualitative
relaxation-pair collision, but it is **not** the exact contraction of state 12.
Exact path admittances and a canonical two-boundary Evans determinant identify
and label the target and competitor branches.  Exact matched subdivision of
the witness segment `11-12-10` changes the secular matrix by the rank-one
dynamic response `z R_alpha/(z+s)` and contracts to a distinct 11-state
pure-theta generator.  That exact contraction retains `Y<1` for the labeled
rotating mode but loses visibility and spectral leadership.  The separately
optimized 11-state frontier retains visibility and leadership but has
`Y=1.021418567...` and is nearly pinned to an almost-real competitor collision.
Together these results support a dynamic spectral-spacer mechanism, but the
general causal lemma determining when matched subdivision moves the relaxation
competitor left relative to the rotating target remains open.  The run is
therefore a major spectral-bridge advance, not a completed spectral-bridge
resolution.

## 2. Exact bridge theorem and class covered

Let a finite irreducible generator be represented in stationary-flux form

```
f_ij(epsilon) = (T_ij + epsilon J_ij)/2,
k_ij(epsilon) = f_ij(epsilon)/pi_i.
```

The stationary law `pi` and all undirected traffics `T_ij` are fixed.  Current
conservation makes `pi Q(epsilon)=0`, and reversal of `epsilon` is the
stationary adjoint, so the characteristic polynomial is even in `epsilon`.
If its exact polynomial `P(z,epsilon)` obeys

```
P = P_z = 0,       P_zz != 0,       P_epsilon != 0
```

at an isolated real double root `(z_c,epsilon_c)`, then

```
z_±(epsilon) = z_c + O(delta)
               ± sqrt(c delta + O(delta^2)),
c = -2 P_epsilon/P_zz,
delta = epsilon-epsilon_c.
```

For `c<0`, the cluster is two real relaxation roots below the exceptional
point and a conjugate pair above it.  The right real root has square-root,
not linear, motion.  The theorem applies to every finite generator satisfying
these hypotheses.  The Evans and admittance reduction specializes it to
two-terminal theta networks whose components have irreducible path blocks.

## 3. Certified 12-state application

After removing the stationary factor, an independent reconstruction gives an
exact rational polynomial of degree 11 in `z` and degree 5 in
`s=epsilon^2`.  Exact rational complex-root isolation proves:

| event | certified epsilon bracket | certified change |
|---|---:|---|
| target visibility | `(0.9909469373, 0.9909469374)` | `Im(z_rot)+Re(z_rot)` changes from negative to positive |
| target leadership | `(0.9993123774700, 0.9993123774701)` | target trails, then leads, every nonconjugate competitor |
| competitor EP | `(0.9995410541966, 0.9995410541968)` | nonzero real-root count drops from 3 to 1 |

The exact-polynomial point solution is

```
epsilon_EP = 0.9995410541967138660166...
z_EP       = -5810.9856011819979369...
c          = -7.90362867327048e6.
```

The leadership crossing is
`0.9993123774700247579...`; its separation from the exceptional point is
`2.28676726689e-4`.  Root boxes, rather than those point decimals, are the
ordering certificate.

At the exact witness center `epsilon=1`, the frozen certified metrics remain:

| quantity | value |
|---|---:|
| `lambda_R` | `5769.662333445447...` |
| `lambda_I` | `5818.682682437680...` |
| `sigma` | `5288.204794278893...` |
| `Y` | `0.9011753725957502...` |
| visibility margin | `49.0203489922333...` |
| complete-spectrum leading margin | `41.7270929465976...` |
| `tau` | `1.5429911371033105...` |
| `kappa` | `3.851006562281760...` |
| `eta_cur` | `0.1516602000794197...` |
| `eta` | `0.00885890591757549...` |
| `zeta` | `0.3462838936437633...` |

## 4. Canonical Evans and path data

For each path, with boundary/internal block decomposition of `zI-Q`, define

```
A_r(z) = H_r - C_r D_r(z)^(-1) E_r.
S(z)   = z I_2 + sum_r A_r(z).
```

Exact Schur elimination gives the normalized lowest-terms identity

```
det S(z) = chi(z)/d_I(z),
chi(z)=det(zI-Q),       d_I=product_r det D_r.
```

Both factors are monic and coprime.  At a simple path pole the admittance
residue has rank at most one.  Consequently the determinant has a simple,
not artificial double, pole and no full root is lost.  Complete pole maps
exclude the hypothesis that the relaxation competitor is a nearly cancelled
path pole.

Target and competitor labels are Riesz branches with invariant boundary
fingerprint `adj(S(z0))/E'(z0)`.  At an exceptional point the competitor is
an unordered two-root cluster; sorting roots by real part across that point
would be a branch-switching error.

## 5. What matched subdivision establishes — and the two distinct 11-state systems

The unique positive two-edge replacement that matches an edge's DC Schur
response is parameterized by `0<alpha<1` and `s>0`:

```
p1=p/alpha,       q1=(1-alpha)s,
p2=alpha s,       q2=q/(1-alpha).
```

It preserves unnormalized current, total affinity, segment entropy, and an
arbitrary inserted stationary mass.  Exact elimination gives

```
A_sub(z)-A_edge(z) = z/(z+s) R_alpha,
rank(R_alpha)=1.
```

Thus subdivision is an exact rank-one frequency-dependent spectral
intervention.  It is not dynamically transparent: for nonzero current its
resistance-like contribution has the strict exact defect
`J^2/(T T1 T2)>0`, and its first admittance moment cannot match at finite
`s`.

### 5.1 Exact matched contraction of state 12

Contracting the certified witness segment `11-12-10` gives exactly

```
k_11,10 = 765968/15531,
k_10,11 = 201090092/15531.
```

The resulting object is an 11-state, 12-edge, cycle-rank-2 pure theta graph.
It does **not** contain the additional edge `3-9`.  High-precision complete-
spectrum reconstruction gives the labeled rotating pair

```
z_rot = -6546.827434621505... + 6281.559316241735... i,
sigma = 5399.556842532401...,
Y_rot = 0.895888745520535....
```

However,

```
visibility = Im(z_rot)+Re(z_rot) = -265.268118379769...,
leading gap = -590.961379911739....
```

The leading nonstationary pair is instead approximately

```
-5955.866054709766... ± 412.815606561013... i.
```

Therefore the exact contraction preserves an OBS-violating **labeled** mode
but is not a valid counterexample because that mode is neither visible nor
spectral-leading.

### 5.2 Separately reoptimized 11-state frontier

The valid-leading 11-state frontier is a different generator.  It has 13
edges, cycle rank 3, and includes the additional edge `3-9`.  Its target and
nearest competitor are

```
z_target     = -3.962429163483561... + 3.972843033286332... i,
z_competitor = -3.962837959753018... + 0.020238907029338... i.
```

Its principal metrics are

```
Y = 1.021418567359246...,
visibility = 0.0104138698027705...,
leading gap = 0.0004087962694568....
```

This generator is visible and spectral-leading but does not violate OBS.  Its
own circulation homotopy has the reported exceptional point

```
epsilon_EP = 0.9998990357960635135...,
z_EP       = -3.96278219574220286...,
c          = -4.05715993008173,
```

and leadership crossing `0.9998989798486832992...`.  The tiny exceptional-
point spacer and pre-EP interval belong to this **reoptimized frontier**, not
to the exact matched contraction.

### 5.3 Correct causal conclusion and remaining lemma

Point continuation in the 12-state matched-subdivision parameter finds a
numerical valid window

```
15064.601910 < s < 17119.286131,
```

with the exact witness value `s=15531` inside.  Visibility holds on the wider
numerical interval

```
12776.051358 < s < 31422.935135,
```

and `Y<1` at all listed surfaces.  The subdivision identities and the
contraction endpoint are exact; these boundary values are high-precision
point continuation rather than interval certificates.

This one-parameter intervention is strong causal evidence that the inserted
state's dynamic admittance can open a valid spectral window.  What is **not**
yet proved is a general sign or ordering theorem of the form:

> under transparent path, residue, or phase conditions, matched subdivision
> moves the almost-real relaxation competitor left relative to the rotating
> target sufficiently to create or enlarge a positive leading-gap interval.

That statement is claim `MS6` in the theorem ledger and remains **OPEN**.  No
exceptional-point spacer comparison may identify the exact contraction with
the independently reoptimized 11-state frontier.

## 6. Utilization is secular data

For a pure-theta eigenroot `z`, the exact energy identities reduce utilization
to

```
zeta(z) = |Im z|/[2 Gamma (-Re z)].
```

It is invariant under eigenvector and Evans normalizations.  Therefore an
almost-real relaxation branch `z=-a+i delta` has exact utilization
`|delta|/(2 Gamma a)`.  If its current-weighted amplitude stays nondegenerate,
`kappa=Theta(delta^-2)`.  In the witness the target and relaxation-pair values
are `0.3462838936...` and `0.00355815009...`, a factor of `97.3213...`.

## 7. Transparent-family candidate and remaining gap

A constant-complexity 15-parameter role-layer family, with no long-path
per-edge arrays, was found.  Its exact-rational `L=5` member has

```
lambda = -5767.324368... + 5826.541652... i
sigma  = 5257.71395...
Y      = 0.893201865...
visibility = 59.2173...
leading gap = 43.5868...
tau=1.534172..., kappa=3.843049...,
eta_cur=0.1514955..., eta=0.008919...
```

The same parameters succeed numerically for `L=5,...,9`; `L=3,4` fail
visibility/leadership and `L=10,...,20` have `Y>1`.  This is the simplest
serious transparent-family candidate produced by the run, but it has no
interval-certified open box and no proof that all roots are controlled across
the finite length window.  Two completion gaps remain: rigorous family-box
certification and a causal root-ordering theorem linking the rank-one
subdivision response to relative target/competitor motion.

The symmetric identical-path class is rigorously obstructed: it has an
unavoidable real odd-sector root
`-(a+b)+2 sqrt(ab) cos(pi/L)` moving toward zero with length.

## 8. Gu source correspondence and novelty

The source-exact correspondence was established from Gu's Appendix A.  Only
`tau` literally matches an adjacent Gu slack.  Gu's other adjacent factors
are `kappa_Gu=CG/B^2` and `s_Gu=MD/G`; the exact relation is

```
kappa_Gu s_Gu = kappa (eta_cur/eta) = M C D/B^2.
```

The provisional one-to-one three-factor correspondence is therefore false
and is withdrawn.  The project regrouping uses the different phase inequality
`B^2<=DH`, exposes `eta_cur`, and proves `Y>eta_cur>=eta` plus explicit equality
conditions.  Novelty disposition: **PARTIALLY NOVEL — PRIOR COMPONENTS
FOUND**.  The hostile bookkeeping objection succeeds against literal-adjacent
rhetoric, but not against the narrower source-distinct refinement.

## 9. Constrained 11-state Pareto frontier

All 448 saved 11-state path artifacts were reconstructed with zero failures;
they represent 295 distinct rate matrices, 154 visible targets, and 64 visible
support signatures.  No saved valid violation was found.  On the final
13-edge, cycle-rank-3 support, 5,626 plane/random samples and 6,266 coordinate
samples also found no valid violation.  Another 85 one-edge topology
perturbations found none.

The frontier does **not** cross the valid-violation quadrant in these saved,
fixed-support local, and one-edge topology-perturbation samples.  This is an
empirical/local statement, not an exclusion of the topology or of all
11-state chains.  The observed barrier is an ill-conditioned almost-real
competitor-pair collision: its condition number rises above 1,800--2,600,
then a real root overtakes while `Y` remains about `1.02137`.

## 10. Certification ledger

| statement | status |
|---|---|
| path admittance, canonical Evans identity, gcd and pole-rank audit | exact algebra |
| matched-subdivision formula, obstruction, and exact contraction rates | exact algebra |
| exact-contraction target, competitor, `Y`, visibility, and leading-gap values | high-precision complete-spectrum reconstruction; not interval-certified |
| exceptional-point square-root theorem and utilization theorem | exact analysis |
| 12-state visibility, leadership, and EP root-count brackets | exact rational root isolation |
| witness metrics at the frozen center | inherited Arb/Acb certificate and independent high precision |
| reoptimized 11-state frontier EP center and crossing | 75--130 digit evaluation of its exact polynomial slices; distinct from the contraction |
| matched-subdivision valid window | high-precision point continuation |
| universal relative-ordering effect of matched subdivision (`MS6`) | **OPEN** |
| role-layer `L=5..9` window | point-arithmetic complete spectra |
| n=11 Pareto/topology frontier | empirical/local |
| Gu proof correspondence | source-exact reconstruction |
| slack novelty | targeted primary-source audit; partially novel |

## 11. Hostile-audit disposition

Two independent raw-definition reconstructions produced the decisive
12-state characteristic polynomial: the Evans/admittance route and direct
stationary-flux construction.  Exact rational slice isolation independently
verified the 12-state root topology and ordering.  Separate audits rejected
pole misidentification and branch sorting, sustained the objection that finite
DC matching is not dynamic transparency, corrected the literal Gu-slack
correspondence, and limited the n=11 and role-layer claims to their actual
numerical scopes.

The audit also found and repairs a material lineage error in the original
v0.2 report: the exact 11-state matched contraction and the independently
reoptimized 11-state frontier were conflated.  They have different supports,
rates, scales, and validity failures.  The corrected disposition is:

- the exact contraction is a cycle-rank-2 theta with a labeled `Y<1` mode that
  is invisible and nonleading;
- the reoptimized cycle-rank-3 frontier is visible and leading but has
  `Y>1` and a tiny exceptional-point spacer;
- their shared qualitative relaxation-collision behavior supports the
  spectral-spacer hypothesis but does not prove the open causal ordering
  lemma `MS6`.

Accordingly, the package is relabeled **NOT RESOLVED — MAJOR SPECTRAL BRIDGE
ADVANCE**.

## 12. Archive scope

This v0.2.1 correction preserves all underlying data and scripts from v0.2, revises only claim disposition and lineage language, and adds a correction record.

The archive is self-contained with respect to every new formula, exact
polynomial, root box, continuation table, exact family member, Gu audit, and
11-state frontier generated in this run.  Frozen predecessor packages are
referenced by the lineage manifest and are not overwritten.

