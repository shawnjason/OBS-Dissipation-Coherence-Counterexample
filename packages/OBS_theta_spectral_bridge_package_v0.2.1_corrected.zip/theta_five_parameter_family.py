#!/usr/bin/env python3
"""Five-parameter stationary-flux family on the exact Theta_(3,5,5) witness.

The three alpha parameters multiply every traffic on one path.  The beta
parameters independently scale the currents on paths 1 and 2; the third path
current is fixed by Kirchhoff conservation.  The exact stationary law is held
fixed.  This is a discovery/verification implementation using NumPy for the
spectrum; exact rational data are emitted separately by ``--dump-baseline``.
"""

from __future__ import annotations

import argparse
import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
DEFAULT_WITNESS = ROOT / "supporting/exact_inputs/n12_e13.json"
PATHS = [
    [1, 2, 3, 8],          # states 2-3-4-9: 3 edges
    [1, 4, 5, 6, 7, 8],    # states 2-5-6-7-8-9: 5 edges
    [1, 0, 10, 11, 9, 8],  # states 2-1-11-12-10-9: 5 edges
]


def solve_fraction(a: list[list[Fraction]], b: list[Fraction]) -> list[Fraction]:
    n = len(a)
    aug = [row[:] + [b[i]] for i, row in enumerate(a)]
    for col in range(n):
        pivot = next(i for i in range(col, n) if aug[i][col])
        aug[col], aug[pivot] = aug[pivot], aug[col]
        d = aug[col][col]
        aug[col] = [x / d for x in aug[col]]
        for i in range(n):
            if i != col and aug[i][col]:
                d = aug[i][col]
                aug[i] = [x - d * y for x, y in zip(aug[i], aug[col])]
    return [aug[i][-1] for i in range(n)]


def exact_stationary(k: list[list[Fraction]]) -> list[Fraction]:
    n = len(k)
    q = [[Fraction(0) for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            q[i][j] = k[i][j] if i != j else -sum(k[i][t] for t in range(n) if t != i)
    a = [[q[j][i] for j in range(n)] for i in range(n)]
    a[-1] = [Fraction(1) for _ in range(n)]
    b = [Fraction(0) for _ in range(n)]
    b[-1] = Fraction(1)
    p = solve_fraction(a, b)
    assert min(p) > 0 and sum(p) == 1
    return p


def load_baseline(path: Path = DEFAULT_WITNESS):
    d = json.loads(path.read_text(encoding="utf-8"))
    den = int(d.get("denominator", 1))
    nums = d["integer_rate_numerators"] if "integer_rate_numerators" in d else d["rates"]
    k = [[Fraction(int(x), den) for x in row] for row in nums]
    p = exact_stationary(k)
    path_data = []
    covered = set()
    for path_nodes in PATHS:
        records = []
        for i, j in zip(path_nodes[:-1], path_nodes[1:]):
            fij, fji = p[i] * k[i][j], p[j] * k[j][i]
            records.append({"i": i, "j": j, "T": fij + fji})
            covered.add(tuple(sorted((i, j))))
        js = [p[r["i"]] * k[r["i"]][r["j"]] - p[r["j"]] * k[r["j"]][r["i"]] for r in records]
        assert all(x == js[0] for x in js)
        path_data.append({"nodes": path_nodes, "J": js[0], "edges": records})
    support = {(i, j) for i in range(len(k)) for j in range(i + 1, len(k)) if k[i][j]}
    assert covered == support
    assert sum(x["J"] for x in path_data) == 0
    return k, p, path_data


def member(params, baseline=None):
    if baseline is None:
        baseline = load_baseline()
    _, p, path_data = baseline
    a1, a2, a3, b1, b2 = map(float, params)
    alphas = [a1, a2, a3]
    currents = [b1 * float(path_data[0]["J"]), b2 * float(path_data[1]["J"]), 0.0]
    currents[2] = -currents[0] - currents[1]
    n = len(p)
    k = np.zeros((n, n), dtype=float)
    for alpha, current, pd in zip(alphas, currents, path_data):
        for ed in pd["edges"]:
            i, j, traffic = ed["i"], ed["j"], alpha * float(ed["T"])
            if traffic <= abs(current):
                raise ValueError("nonpositive directed stationary flux")
            k[i, j] = (traffic + current) / (2.0 * float(p[i]))
            k[j, i] = (traffic - current) / (2.0 * float(p[j]))
    return k, np.array([float(x) for x in p]), currents


def diagnostics(params, baseline=None):
    if baseline is None:
        baseline = load_baseline()
    _, _, path_data = baseline
    k, p, currents = member(params, baseline)
    q = k.copy()
    np.fill_diagonal(q, -k.sum(axis=1))
    vals, vecs = np.linalg.eig(q)
    nz = [i for i, z in enumerate(vals) if abs(z) > 1e-7]
    upper = [i for i in nz if vals[i].imag > 1e-7]
    target_i = max(upper, key=lambda i: vals[i].real)
    z = vals[target_i]
    mate_i = min(nz, key=lambda i: abs(vals[i] - z.conjugate()))
    others = [i for i in nz if i not in (target_i, mate_i)]
    competitor_i = max(others, key=lambda i: vals[i].real)
    competitor = vals[competitor_i]
    v = vecs[:, target_i]
    v /= np.max(np.abs(v))

    sigma = dval = bval = cval = hval = 0.0
    path_rows = []
    for r, (alpha, current, pd) in enumerate(zip(params[:3], currents, path_data), 1):
        dr = br = cr = hr = sr = xr = 0.0
        for ed in pd["edges"]:
            i, j = ed["i"], ed["j"]
            fij, fji = p[i] * k[i, j], p[j] * k[j, i]
            traffic = fij + fji
            phase = float(np.imag(np.conjugate(v[i]) * v[j]))
            dr += traffic * abs(v[j] - v[i]) ** 2
            sr += phase
            # Prompt convention: C=sum_e J_e^2/T_e, whereas
            # H=sum_e J_e^2(|v_i|^2+|v_j|^2)/(2T_e).
            cr += current * current / traffic
            hr += current * current * (abs(v[i]) ** 2 + abs(v[j]) ** 2) / (2.0 * traffic)
            xr += math.log(fij / fji)
        br = current * sr
        sigmar = current * xr
        sigma += sigmar
        dval += dr
        bval += br
        cval += cr
        hval += hr
        path_rows.append({"path": r, "J": current, "X": xr, "sigma": sigmar, "S": sr, "B": br,
                          "D": dr, "C": cr, "H": hr})

    nv = float(np.sum(p * np.abs(v) ** 2))
    eta = nv / float(np.max(np.abs(v) ** 2))
    lr, li = -float(z.real), float(z.imag)
    y = sigma * lr / (li * li)
    tau = sigma / (2.0 * cval)
    kappa = dval * hval / (bval * bval)
    eta_cur = nv * cval / hval
    leading_gap = float(z.real - vals[competitor_i].real)
    return {
        "parameters": list(map(float, params)), "Y": y, "lambda_R": lr, "lambda_I": li,
        "visibility": li - lr, "leading_gap": leading_gap, "sigma": sigma,
        "competitor_real": float(competitor.real), "competitor_imag": float(abs(competitor.imag)),
        "Nv": nv, "D": dval, "B": bval, "C": cval, "H": hval, "eta": eta,
        "tau": tau, "kappa": kappa, "eta_cur": eta_cur, "rho_cur": eta_cur / eta,
        "factor_product": tau * kappa * eta_cur,
        "identity_relative_error": abs(y - tau * kappa * eta_cur) / y,
        "path_diagnostics": path_rows,
    }


def exact_dump(baseline):
    k, p, path_data = baseline
    return {
        "family": "five-parameter stationary-flux Theta_(3,5,5)",
        "parameters": ["alpha_1", "alpha_2", "alpha_3", "beta_1", "beta_2"],
        "center": [1, 1, 1, 1, 1],
        "stationary_distribution": [str(x) for x in p],
        "paths_1_based": [[x + 1 for x in pd["nodes"]] for pd in path_data],
        "path_currents": [str(pd["J"]) for pd in path_data],
        "path_traffics": [[str(ed["T"]) for ed in pd["edges"]] for pd in path_data],
        "construction": "T_e'=alpha_r T_e; J_1'=beta_1 J_1; J_2'=beta_2 J_2; J_3'=-J_1'-J_2'; f_ij'=(T_e'+J_r')/2; k_ij'=f_ij'/pi_i",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params", nargs=5, type=float, default=[1, 1, 1, 1, 1])
    ap.add_argument("--dump-baseline", type=Path)
    args = ap.parse_args()
    baseline = load_baseline()
    if args.dump_baseline:
        args.dump_baseline.write_text(json.dumps(exact_dump(baseline), indent=2), encoding="utf-8")
    print(json.dumps(diagnostics(args.params, baseline), indent=2))


if __name__ == "__main__":
    main()
