# OBS theta spectral bridge v0.2.1 correction

## Material correction

The original v0.2 report conflated two distinct 11-state generators:

1. **Exact matched contraction of state 12** — 11 states, 12 edges, cycle rank 2, no `3-9` chord. Its labeled rotating mode has `Y<1` but is invisible and nonleading.
2. **Separately reoptimized 11-state frontier** — 11 states, 13 edges, cycle rank 3, includes `3-9`. It is visible and leading but has `Y>1` and the reported tiny exceptional-point spacer.

The reported `epsilon_EP≈0.999899...`, `z_EP≈-3.962782...`, and tiny leadership spacer belong only to the reoptimized frontier. They do not describe the exact contraction.

## Resolution correction

The exact rank-one subdivision response and witness-specific continuation provide strong causal evidence, but the general relative-ordering lemma remains open. The package is therefore relabeled:

**NOT RESOLVED — MAJOR SPECTRAL BRIDGE ADVANCE**

Claim `MS6` in `OBS_theta_theorem_ledger.csv` states the remaining causal lemma.
