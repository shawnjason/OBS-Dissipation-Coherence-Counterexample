# Equality and sharpness audit

## Thermodynamic slack `τ`

For positive edge fluxes `x,y`,

```
(x-y) log(x/y) >= 2(x-y)^2/(x+y).
```

Writing `r=(x-y)/(x+y)` reduces the excess to
`2(x+y) r (artanh(r)-r)`. Equality holds exactly at `r=0`, hence `x=y` and `j_e=0`. Therefore `τ=1` requires zero current on every edge. A nonreal backward mode has `B=bN_v != 0`, so some current is nonzero and `τ>1` at every finite bidirectional nonreal chain. Equality is approachable only in a small-affinity limit.

## Gu's adjacent Cauchy--Schwarz slack `κ_Gu`

Gu defines implicitly

```
G = sum_e T_e [Im(conj(v_i)v_j)]^2,
κ_Gu = C G / B^2.
```

Equality in Gu (A6) holds exactly when there is a real constant `α` such that

```
Im(conj(v_i)v_j) = α j_e/T_e
```

on every edge, with the corresponding zero conditions when either vector in the weighted Cauchy--Schwarz pairing vanishes.

## Gu's final adjacent slack `s_Gu`

The exact identity

```
0.5(|a|^2+|b|^2)|a-b|^2 - Im(conj(a)b)^2
= 0.5[(|a|^2-Re(conj(a)b))^2
     +(|b|^2-Re(conj(a)b))^2]
```

shows that Gu's two-point inequality (A8) is an equality exactly when `a=b`. Gu (A9) then replaces endpoint amplitudes by the global maximum. Equality in the combined step `G <= M D` requires both the edgewise two-point equality wherever traffic contributes and equality in the maximum replacement. For a nonconstant irreducible nonreal eigenvector the combined step is strict.

## Project phase slack `κ`

Let

```
K = sum_e j_e^2 |v_i+v_j|^2/(4T_e).
```

The project route is `B^2 <= D K <= D H`. Equality in the first inequality requires equality in complex Cauchy--Schwarz and a purely imaginary proportionality constant. The second has the exact deficit

```
H-K = sum_e j_e^2 |v_j-v_i|^2/(4T_e).
```

Thus equality `K=H` requires `v_i=v_j` on every nonzero-current edge, which forces `B=0`. Consequently `κ=1` is impossible for a nonreal mode; `κ>1` is strict.

## Current-weighted amplitude slack

Since `H/C` is the `j_e^2/T_e`-weighted average of
`(|v_i|^2+|v_j|^2)/2`,

```
η_cur = η
```

if and only if both endpoints of every nonzero-current edge have maximal mode amplitude. This equality can occur for a nonreal mode: biased translation-invariant rings are examples.

## Simultaneous saturation and optimality

All three project factors cannot be exactly one for a finite nonreal mode because `τ=1` already forces `B=0`. Nevertheless, biased rings in the diffusive continuum limit have `η_cur=η=1` and `τκ -> 1`. Hence the universal coefficient in

```
Y >= η_cur
```

cannot be increased above one when only the stated current-weighted amplitude data are retained. The finite-chain inequality is strict, but its constant is sharp.
