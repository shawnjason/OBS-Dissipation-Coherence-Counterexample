#!/usr/bin/env python3
"""Track exact-witness spectral subspaces under Q(eps)=Q_rev+eps Q_circ.

The stationary law and all edge traffics are fixed; every path current is
multiplied by eps.  This makes the generator affine in eps and reversible at
eps=0.  Pair labels are continued from eps=1 by stationary-balanced invariant
subspace overlap rather than by sorting eigenvalue indices.
"""

from __future__ import annotations

import csv
import itertools
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from theta_five_parameter_family import load_baseline, member  # noqa: E402

HERE=Path(__file__).resolve().parent
PATHS=[[1,2,3,8],[1,4,5,6,7,8],[1,0,10,11,9,8]]


def eigensystem(eps,base):
    k,p,currents=member([1,1,1,eps,eps],base)
    q=k.copy();np.fill_diagonal(q,-k.sum(axis=1))
    vals,vecs=np.linalg.eig(q)
    # stationary-balanced coordinates preserve the pi inner product
    bvec=np.sqrt(p)[:,None]*vecs
    return k,p,currents,q,vals,bvec


def pair_basis(bvec,inds):
    q,_=np.linalg.qr(bvec[:,list(inds)])
    return q[:,:2]


def initial_pair(vals,target):
    i=min(range(len(vals)),key=lambda j:abs(vals[j]-target))
    j=min((j for j in range(len(vals)) if j!=i),key=lambda j:abs(vals[j]-vals[i].conjugate()))
    return tuple(sorted((i,j)))


def continue_pair(prev_basis,prev_center,vals,bvec,forbidden=()):
    nz=[i for i,z in enumerate(vals) if abs(z)>1e-7 and i not in forbidden]
    best=None
    scale=max(1.0,abs(prev_center))
    for inds in itertools.combinations(nz,2):
        qb=pair_basis(bvec,inds)
        overlap=float(np.linalg.svd(prev_basis.conj().T@qb,compute_uv=False).sum()/2)
        center=(vals[inds[0]]+vals[inds[1]])/2
        proximity=abs(center-prev_center)/scale
        score=overlap-0.02*proximity
        if best is None or score>best[0]:best=(score,inds,qb,center,overlap)
    return best[1],best[2],best[3],best[4]


def pair_summary(inds,vals,bvec,k,p,currents,q,base):
    zs=[vals[i] for i in inds]
    z=max(zs,key=lambda x:x.imag)
    # If the continued pair is real, report its slower/faster members and no Y.
    if abs(z.imag)<1e-7:
        slow=max(zs,key=lambda x:x.real);fast=min(zs,key=lambda x:x.real)
        return {"real_slow":float(slow.real),"real_fast":float(fast.real),"imag":0.0,
                "decay":float(-slow.real),"frequency":0.0,"Y":None,"visibility":None,
                "zeta":None,"kappa":None,"eta_cur":None}
    # Recover an eigenvector in original coordinates.
    i=max(inds,key=lambda j:vals[j].imag)
    v=bvec[:,i]/np.sqrt(p)
    v/=np.max(np.abs(v))
    nv=float(np.sum(p*np.abs(v)**2));D=B=C=H=sigma=0.0
    gamma=0.0
    for current,pd,nodes in zip(currents,base[2],PATHS):
        resistance=0.0
        for ed,(a,b) in zip(pd['edges'],zip(nodes[:-1],nodes[1:])):
            fij,fji=p[a]*k[a,b],p[b]*k[b,a];T=fij+fji
            resistance+=1/T
            D+=T*abs(v[b]-v[a])**2
            B+=current*float(np.imag(np.conj(v[a])*v[b]))
            C+=current*current/T
            H+=current*current*(abs(v[a])**2+abs(v[b])**2)/(2*T)
            sigma+=(fij-fji)*math.log(fij/fji)
        L=len(nodes)-1;g=math.cos(math.pi/(2*L))/(2*L*math.sin(math.pi/(2*L)))
        gamma=max(gamma,abs(current)*g*resistance)
    lr,li=-float(z.real),float(z.imag)
    return {"real_slow":float(z.real),"real_fast":float(z.real),"imag":li,"decay":lr,"frequency":li,
            "Y":sigma*lr/(li*li),"visibility":li-lr,"zeta":abs(B)/(gamma*D) if gamma else None,
            "kappa":D*H/(B*B),"eta_cur":nv*C/H,"Gamma":gamma,
            "eig_residual":float(np.linalg.norm(q@v-z*v)/np.linalg.norm(v))}


def main():
    base=load_baseline()
    grid=np.concatenate([np.linspace(1,.98,2001),np.linspace(.9795,.2,1560),np.linspace(.199,0,200)])
    k,p,currents,q,vals,bvec=eigensystem(float(grid[0]),base)
    tinds=initial_pair(vals,complex(-5769.662333445446,5818.682682437687))
    cinds=initial_pair(vals,complex(-5811.389426392041,60.220759297817))
    tb=pair_basis(bvec,tinds);cb=pair_basis(bvec,cinds)
    tc=sum(vals[i] for i in tinds)/2;cc=sum(vals[i] for i in cinds)/2
    rows=[]
    for step,eps in enumerate(grid):
        k,p,currents,q,vals,bvec=eigensystem(float(eps),base)
        if step:
            tinds,tb,tc,tov=continue_pair(tb,tc,vals,bvec)
            cinds,cb,cc,cov=continue_pair(cb,cc,vals,bvec,forbidden=tinds)
        else:tov=cov=1.0
        ts=pair_summary(tinds,vals,bvec,k,p,currents,q,base)
        cs=pair_summary(cinds,vals,bvec,k,p,currents,q,base)
        other=[vals[i].real for i in range(len(vals)) if i not in tinds and abs(vals[i])>1e-7]
        tlead=max(vals[i].real for i in tinds)-max(other)
        rows.append({"epsilon":float(eps),"target_overlap":tov,"competitor_overlap":cov,
                     **{"target_"+x:y for x,y in ts.items()},**{"competitor_"+x:y for x,y in cs.items()},
                     "target_global_gap":float(tlead),
                     "pair_real_order":float(max(vals[i].real for i in tinds)-max(vals[i].real for i in cinds))})
    with (HERE/'circulation_root_locus.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    # Locate sign/onset brackets without claiming interval certification.
    events={}
    for key in ['target_visibility','target_global_gap','pair_real_order']:
        pairs=[]
        for a,b in zip(rows,rows[1:]):
            if a[key] is not None and b[key] is not None and a[key]*b[key]<=0:pairs.append([a['epsilon'],b['epsilon']])
        events[key+'_zero_brackets']=pairs
    for prefix in ['target','competitor']:
        on=[]
        for a,b in zip(rows,rows[1:]):
            if (a[prefix+'_imag']>1e-7)!=(b[prefix+'_imag']>1e-7):on.append([a['epsilon'],b['epsilon']])
        events[prefix+'_complexification_brackets']=on
    summary={"classification":"double-precision invariant-subspace continuation; not interval certification",
             "homotopy":"fixed pi and T; all path currents scaled by epsilon","steps":len(rows),"events":events,
             "epsilon_1":rows[0],"epsilon_0":rows[-1]}
    (HERE/'circulation_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
