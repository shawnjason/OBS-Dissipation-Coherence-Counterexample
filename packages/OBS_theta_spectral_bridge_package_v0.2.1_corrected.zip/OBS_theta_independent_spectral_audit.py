"""Hostile regression tests for poles, normalization, and exact derivatives."""

import unittest

import sympy as sp

import build_evans_bridge as eb


class EvansBridgeTests(unittest.TestCase):
    def test_canonical_lowest_terms_and_no_lost_roots(self):
        for name in ("n12", "n11"):
            _, _, S, chi, dprod, _ = eb.system_evans(name)
            self.assertEqual(sp.gcd(chi, dprod).degree(), 0)
            self.assertEqual(sp.gcd(chi, chi.diff()).degree(), 0)
            self.assertEqual(sp.cancel(S.det() - chi.as_expr() / dprod.as_expr()), 0)
            self.assertEqual(chi.LC(), 1)
            self.assertEqual(dprod.LC(), 1)

    def test_every_component_pole_has_rank_one_admittance_residue(self):
        for name in ("n12", "n11"):
            _, _, _, _, _, components = eb.system_evans(name)
            for comp in components:
                d = comp["d"]
                self.assertEqual(sp.gcd(d, d.diff()).degree(), 0)
                # At every root of d, N=-C adj(D) E has rank <=1.  Exact
                # divisibility is stronger than a floating determinant test.
                rem = sp.rem(sp.Poly(sp.expand(comp["N"].det()), eb.z), d)
                self.assertEqual(rem.as_expr(), 0)

    def test_faddeev_parameter_derivative_against_symbolic_charpoly(self):
        for name in ("n12", "n11"):
            k = eb.load_rates(name)
            Q = eb.generator(k)
            direction = (eb.stationary_flux_directions(k) if name == "n12"
                         else eb.n11_scale_directions(k))[0][1]
            exact = eb.faddeev_derivative(Q, direction)
            t = sp.Symbol("t")
            direct = sp.Poly((Q + t * direction).charpoly(eb.z).as_expr(), eb.z)
            direct_dt = sp.Poly(sp.diff(direct.as_expr(), t).subs(t, 0), eb.z)
            self.assertEqual(exact, direct_dt)


if __name__ == "__main__":
    unittest.main()
