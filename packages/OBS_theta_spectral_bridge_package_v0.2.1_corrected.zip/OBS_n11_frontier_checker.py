#!/usr/bin/env python3
"""Portable audit of the emitted constrained n=11 frontier tables.

The original raw-artifact reconstruction program is retained under scripts/.
This archive entrypoint checks the emitted all-candidate table and the frozen
summary without requiring predecessor workspace paths.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ALL = HERE / "supporting/n11_all_candidates.csv"
SUMMARY = HERE / "supporting/n11_frontier_summary.json"


def number(row: dict[str, str], key: str) -> float:
    return float(row[key])


def main() -> None:
    with ALL.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    summary = json.loads(SUMMARY.read_text(encoding="utf-8"))

    visible = [r for r in rows if number(r, "g_vis") > 0]
    valid = [r for r in visible
             if number(r, "Y") < 1 and number(r, "g_lead") > 0]
    visible_topologies = {r["topology_id"] for r in visible}
    failures = HERE / "supporting/n11_reconstruction_failures.csv"
    failure_bytes = failures.read_bytes() if failures.exists() else b""

    checks = {
        "rows": len(rows),
        "expected_rows": summary["unique_saved_n11_reconstructed"],
        "visible_targets": len(visible),
        "expected_visible_targets": summary["saved_visible_targets"],
        "visible_topologies": len(visible_topologies),
        "expected_visible_topologies": summary["saved_topologies_with_visible_targets"],
        "valid_violations": len(valid),
        "reconstruction_failure_file_bytes": len(failure_bytes),
    }
    assert checks["rows"] == checks["expected_rows"] == 448
    assert checks["visible_targets"] == checks["expected_visible_targets"] == 154
    assert checks["visible_topologies"] == checks["expected_visible_topologies"] == 64
    assert checks["valid_violations"] == 0
    assert checks["reconstruction_failure_file_bytes"] == 0
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()
