# OBS theta spectral-bridge package v0.2.1 — corrected

Resolution: **NOT RESOLVED — MAJOR SPECTRAL BRIDGE ADVANCE**.

Correction v0.2.1: the exact 11-state matched contraction and the independently reoptimized 11-state frontier are distinct generators. The universal matched-subdivision relative-ordering lemma remains open (`MS6`).

This archive contains the exact Evans/admittance reduction, the
exceptional-point root-ordering theorem, exact rational root boxes for the
12-state circulation bridge, the matched subdivision/contraction theorem, a
transparent role-layer candidate, a source-exact Gu slack audit, and the
constrained 11-state Pareto reconstruction.

## One-command reproduction

Install Python 3.12 or later and the pinned dependencies:

```powershell
python -m pip install -r requirements.txt
```

Then, from the extracted archive directory, run:

```powershell
.\run_all_checks.ps1 -Full
```

Set `OBS_PYTHON` to an explicit Python executable if `python` is not on
`PATH`.  The full command verifies the SHA-256 manifest, replays role-layer
members, runs three exact hostile Evans tests, validates the n=11 checker, and
regenerates the six exact rational root-isolation slices.  The isolation stage
can take several minutes.  Omit `-Full` for the quick replay.

## Reading order

1. `OBS_theta_spectral_bridge_report.md` — claims, scope, and certification.
2. `OBS_theta_root_ordering_theorems.tex` — exceptional-point theorem and
   certified brackets.
3. `OBS_theta_evans_reduction.tex` and `OBS_theta_path_admittances.tex` — exact
   two-boundary reduction.
4. `OBS_theta_matched_subdivision.tex` — matched intervention and exact contraction; do not identify it with the reoptimized 11-state frontier.
5. `OBS_theta_utilization_theory.tex` — secular formula for utilization.
6. `OBS_theta_transparent_family.tex` — candidate and obstructions.
7. Gu and n=11 files — source correspondence and constrained frontier.

## Claim classes

- Exact algebra/theorem: Evans identity, pole rank, root derivatives,
  exceptional-point normal form, utilization law, matched-subdivision defect,
  contraction rates, symmetric identical-path obstruction.
- Exact computational certificate: rational characteristic/secular
  polynomials and twelve-state rational root boxes.
- High-precision numerical evidence: the 12-state EP data, the distinct reoptimized 11-state frontier EP/crossing, the exact-contraction spectrum, and the matched-subdivision window.
- Point-arithmetic candidate: role-layer `L=5,...,9` window.
- Empirical/local: reconstructed and perturbed 11-state Pareto frontier.
- Source-exact: Gu proof-step correspondence.

No frozen predecessor package was overwritten.  The lineage manifest records
the predecessor artifacts and certification inheritance.

## Directory map

- Required top-level files use the filenames specified by the assignment.
- `supporting/` contains exact polynomials, interval boxes, raw continuation
  tables, hostile-audit transcript, and extended reports.
- `supporting/exact_inputs/` contains the two rate matrices required by the
  standalone Evans tests.
- `scripts/` contains the research scripts in their original workspace form;
  the top-level checkers are the portable archive entrypoints.

