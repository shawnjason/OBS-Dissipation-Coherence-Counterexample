param([switch]$Full)

$ErrorActionPreference = 'Stop'
$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = if ($env:OBS_PYTHON) {
    $env:OBS_PYTHON
} else {
    (Get-Command python -ErrorAction Stop).Source
}
$oldPythonPath = $env:PYTHONPATH
$env:PYTHONPATH = if ($oldPythonPath) { "$packageDir;$oldPythonPath" } else { $packageDir }

try {
    Push-Location $packageDir

    if (Test-Path -LiteralPath 'SHA256SUMS.txt') {
        $bad = @()
        foreach ($line in Get-Content -LiteralPath 'SHA256SUMS.txt') {
            if (-not $line.Trim()) { continue }
            $parts = $line -split '\s+', 2
            $expected = $parts[0].ToUpperInvariant()
            $relative = $parts[1].Trim()
            if (-not (Test-Path -LiteralPath $relative)) {
                $bad += "missing: $relative"
                continue
            }
            $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $relative).Hash
            if ($actual -ne $expected) { $bad += "hash mismatch: $relative" }
        }
        if ($bad.Count) { throw ($bad -join [Environment]::NewLine) }
        Write-Host 'SHA-256 manifest: PASS'
    }

    foreach ($length in 5, 9, 10) {
        & $pythonExe -B 'OBS_theta_family_checker.py' --length $length *> $null
        if ($LASTEXITCODE) { throw "family checker failed at L=$length" }
    }
    Write-Host 'Role-layer family replay (L=5,9,10): PASS'

    & $pythonExe -B -m unittest discover -s . -p 'OBS_theta_independent_spectral_audit.py' -v
    if ($LASTEXITCODE) { throw 'Evans hostile audit failed' }

    & $pythonExe -B 'OBS_n11_frontier_checker.py'
    if ($LASTEXITCODE) { throw 'n11 emitted-frontier audit failed' }
    Write-Host 'n11 emitted-frontier audit: PASS'

    if ($Full) {
        & $pythonExe -B 'OBS_theta_interval_family_audit.py'
        if ($LASTEXITCODE) { throw 'exact rational slice isolation failed' }
        Write-Host 'Exact rational root isolation: PASS'
    }

    Write-Host 'All requested checks passed.'
} finally {
    Pop-Location
    $env:PYTHONPATH = $oldPythonPath
}
