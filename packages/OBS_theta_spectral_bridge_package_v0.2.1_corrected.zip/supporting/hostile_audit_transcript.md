# Hostile-audit transcript and dispositions

## Audit A: exceptional point versus numerical branch sorting

Objection: the almost-real competitor may be a mislabeled pole or a numerical
sorting artifact.  Response: one reconstruction emitted exact path
admittances and the canonical Evans function; a second reconstruction emitted
the full exact rational secular polynomial directly from stationary traffic
and current.  Exact pole gcds exclude cancellation.  Exact rational root
isolation proves the real-to-complex root-count change and proves target
ordering on opposite sides of the leadership bracket.  Disposition: objection
rejected for the twelve-state bridge.

## Audit B: disagreement in exceptional-point decimals

Objection: two early point solves differed in the sixteenth decimal.  Response:
the exact-polynomial simultaneous solve of `P=P_z=0` was retained, giving
`0.9995410541967138660166...`; the earlier continuation value was marked as a
lower-accuracy point diagnostic.  Both lie inside the later exact rational
root-count bracket.  Disposition: exact bracket controls; no unsupported
decimal is used as a certificate.

## Audit C: finite subdivision called transparent

Objection: matching the zero-frequency Schur complement does not match the
frequency response.  Response: exact symbolic elimination proves
`A_sub-A_edge=z R_alpha/(z+s)` and a positive resistance-like defect for
nonzero current.  Disposition: objection sustained and promoted to an
exclusion theorem.

## Audit D: Gu slack theorem as relabeling

Objection: the three factors merely rename the adjacent inequalities in Gu's
proof.  Response: source-exact reconstruction shows the adjacent Gu factors
are `kappa_Gu` and `s_Gu`, whereas the project uses the different phase bound
`B^2<=DH` and the current-weighted observable `eta_cur`; only the products
agree.  Disposition: the literal adjacent-slack claim is withdrawn.  The
alternative regrouping is source-distinct but classified only as partially
novel because the ingredients are elementary and exhaustive priority search
is impossible.

## Audit E: global n=11 exclusion from a local frontier

Objection: a local or saved-campaign Pareto frontier may be disconnected and
cannot exclude all eleven-state chains.  Response: the package reports zero
valid violations in 448 reconstructed saved paths, 5,626 local samples, and
85 topology perturbations, but labels the statement empirical/local.
Disposition: objection sustained; no global n=11 exclusion is claimed.

## Audit F: transparent role-layer success

Objection: a point-success and finite length scan do not prove an open family
region or a path-length theorem.  Response: the exact rational member and full
spectrum are retained as a serious candidate; its `L=5..9` window is labelled
point arithmetic, not interval certified.  Disposition: objection sustained.

