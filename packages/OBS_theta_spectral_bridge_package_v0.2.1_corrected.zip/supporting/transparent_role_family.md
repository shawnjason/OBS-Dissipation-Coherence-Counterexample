# Transparent role-layer family candidate

The inherited witness is not simple edge by edge, but it is strongly
compressed in stationary-flux coordinates.  This motivates the following
constant-complexity class on `Theta_(3,L,L)`.

## State masses

Choose endpoint masses `m_u,m_v` and total internal masses `M_1,M_2,M_3`,
with positive values summing to one.  Split the two reservoir-path internal
masses by one fraction `rho`; assign `M_2/(L-1)` and `M_3/(L-1)` uniformly to
the internal states of the two long paths.  This uses six independent mass
parameters after normalization, independent of `L`.

## Currents

Choose two path currents `J_1,J_2` and set `J_3=-J_1-J_2`.

## Traffics

* Reservoir path: three meaningful entrance/bulk/exit traffics
  `T_1in,T_1mid,T_1out`.
* Low-mass rotating path: one repeated bulk traffic `T_2` and one exit
  multiplier `e_2`.
* High-current return path: one repeated bulk traffic `T_3` and one entrance
  multiplier `e_3`.

Every traffic must exceed the magnitude of its path current.  Directed rates
are reconstructed losslessly from

\[
k_{ij}=\frac{T_r+J_r}{2\pi_i},\qquad
k_{ji}=\frac{T_r-J_r}{2\pi_j}.
\]

This is a finite role-layer family whose parameter count does not grow with
`L`.  It does not copy an optimizer constant per edge.  The certified witness
suggests it because:

* path 2's first four traffics have coefficient of variation `0.0161`;
* path 3's last four traffics have coefficient of variation `0.00776`;
* path 2 internal masses have coefficient of variation `0.0768`;
* path 3 internal masses have coefficient of variation `0.0505`.

The target mode is even more compressed after the boundary layer is removed:

* path 2's last four amplitude ratios have mean `0.73638` and coefficient of
  variation `0.01366`; its corresponding phase increments have mean `0.53947`
  and coefficient of variation `0.07255`;
* path 3's first four amplitude ratios have mean `1.33325` and coefficient of
  variation `0.00443`; all five phase increments have mean `-0.63244` and
  coefficient of variation `0.06167`.

Thus the two long-path target profiles are close to complex geometric modes
with one endpoint correction.  This supports repeated-cell or inverse-mode
coordinates much more strongly than raw edge-rate homogeneity.

The reservoir path remains deliberately three-layered; replacing its three
traffics by one repeated value would erase the observed endpoint-impedance
structure.  This class is a serious transparent candidate, not a proved
counterexample family.  A negative optimizer run within it remains evidence
only unless the normalized parameter domain is completely certified.

## Rational member and numerical length window

The finite-decimal center in `data/role_layer_exact_member.json` is an exact
rational generator by construction. Double-precision full-spectrum evaluation
at `L=5` gives

`Y=0.8932018649`, visibility `59.2173`, and leading gap `43.5868`.

Its factors are `tau=1.5341722`, `kappa=3.8430486`, and
`eta_cur=0.1514955`. The product reproduces `Y`.

Holding the same role parameters fixed and changing only the discrete repeated
cell count gives numerical success for `L=5,...,9`; `L=3,4` fail visibility
and leadership, while `L>=10` in the scan through 20 has `Y>1`. This is a
transparent finite-window conjecture, not a proved threshold theorem.
