# Programs H/I independent report

## Executive result

Program H establishes a source-exact correction to the project's provisional interpretation. Program I reconstructs every saved n11 artifact found in the active workspace and maps a sharp but still local localization--leadership conflict. Neither result is an n11 exclusion theorem.

## Program H: Gu proof and slack correspondence

The attached Gu source (`arXiv-2606.05498v1`, Appendix A, equations A1--A10) uses exactly the project's forward/backward generator conventions after the name translation `L_Gu=Q_project`. Gu's flux-affinity entropy production equals the prompt's directed rate-ratio entropy production globally by current conservation. Gu's Dirichlet form is `D/2`, and Gu's eigenvalue identities are exactly `aN_v=D/2` and `bN_v=B`.

The claimed one-to-one matching of all three project factors to Gu's adjacent proof losses is false. The exact source decomposition is

```
Y/eta = tau * kappa_Gu * s_Gu,
kappa_Gu = C G/B^2,
s_Gu = M D/G,
G = sum_e T_e Im(conj(v_i)v_j)^2.
```

The project decomposition is

```
Y/eta = tau * kappa * s_amp,
kappa = D H/B^2,
s_amp = M C/H = eta_cur/eta.
```

Only `tau` is literally the same adjacent ratio. The last two factors obey the exact product identity

```
kappa_Gu*s_Gu = kappa*s_amp = M C D/B^2.
```

The project split comes from a different phase identity and Cauchy--Schwarz inequality. That difference is mathematically useful: it exposes `eta_cur`, proves the strictly sharper intermediate bound `Y>eta_cur>=eta`, and separates phase inefficiency from current-weighted amplitude localization.

All equality conditions were reconstructed. At finite rates a nonreal mode has `tau>1` and `kappa>1`; `eta_cur=eta` holds exactly when both endpoints of every nonzero-current edge have maximal mode amplitude. Simultaneous exact saturation is impossible, but the universal coefficient in `Y>=eta_cur` is sharp in the biased-ring diffusive limit.

The hostile bookkeeping objection therefore has a split verdict: it defeats the rhetorical claim of literal adjacent-step identity, but not the source-distinct `B^2<=DH` refinement and `eta_cur` theorem.

Targeted novelty disposition: **`PARTIALLY NOVEL — PRIOR COMPONENTS FOUND`**. Gu's endpoint `eta` theorem and the entropy/Cauchy--Schwarz ingredients are prior. No equivalent current-weighted localization factor, sharper intermediate bound, exact project factorization, or equality theorem was found in the targeted primary-source audit.

## Program I: complete saved n11 reconstruction

The script found 448 path-level n11 artifacts with a rate representation: 297 in the sub12 campaign, 150 in the earlier small-witness lineage, and the exact-integer state-deletion probe in the synthesis lineage. These reduce to 295 distinct numerical rate matrices. Every artifact was independently reconstructed from its rate table or exact numerator/denominator representation; there were zero reconstruction failures.

For each selected nonreal mode the audit recomputed the complete spectrum, stationary distribution, entropy production, target and competitor, `Y`, visibility, leading gap, `tau`, `kappa`, `eta_cur`, `eta`, both Gu adjacent slacks, and all identity residuals. Across all rows the largest absolute factor residual was of order `10^-12`; energy and phase identity residuals were of order `10^-13` in the large-rate objects.

There were 154 visible selected targets across 64 support signatures. No saved artifact had all three of `Y<1`, positive visibility, and positive global leading gap. This is an exhaustive statement about the saved artifact files, not about all n11 chains.

The frozen bracket objects reproduce as follows:

| object | Y | relative leading gap | tau | kappa | eta_cur |
|---|---:|---:|---:|---:|---:|
| exact-integer delete-state-4 probe | 0.0923173 | -0.377536 | 2.03705 | 4.53330 | 0.00999695 |
| `e13_to_n11_merge_3_4` | 0.798257 | -0.259327 | 1.55320 | 3.74505 | 0.137233 |
| `FINAL_proj_best_t1e5` | 1.021419 | +0.000103168 | 1.40930 | 3.50099 | 0.207019 |

For the pure-theta merge object the theorem-defined capacity calculation gives `zeta≈0.36385`. The final support has cycle rank three because of the extra `3-9` chord; the pure-theta `Gamma,zeta` definition is therefore marked not applicable rather than extended ad hoc.

## Local constrained front

The final-support local experiment fixed the geometric mean of the directed rates, tracked the rotating branch by continuation from its saved root, and always computed the complete-spectrum competitor. It evaluated 5,626 plane/random samples and 6,266 normalized one-coordinate samples.

No local sample crossed the valid-violation quadrant. The sampled front reached `Y≈1.02057` with a positive but tiny gap, while points with `Y<=1` had negative leading gaps. This is consistent with a localization--leadership conflict, but it is not a complete optimization or global certificate.

The gradient audit locates the conflict mainly in `eta_cur`; decreasing `tau` or `kappa` is locally more compatible with increasing leadership. The almost-real competitor has condition number about `350` already at the final point. A first-order joint-improvement direction runs into a near-real competitor-pair collision around a normalized log-rate displacement of `9e-5`, after which a real relaxation root overtakes the rotating target. This supplies a concrete local mechanism for the observed cusp.

## Topology comparisons and limits

The saved-artifact Pareto set mixes disconnected topologies and cannot be treated as a continuation. On the final rates, deletion or relocation of the extra chord produced no valid violation among 85 direct interventions. These are rate-transplant comparisons, not optimized matched topology families.

The strongest honest Program-I statement is therefore local:

> On the saved final support and in the sampled normalized log-rate neighborhood, the route from the near-miss toward lower `Y` is cut by an ill-conditioned almost-real competitor-pair collision before `Y=1` is reached.

The precise missing step for a theorem is validated continuation or global constrained optimization over a rigorously bounded fixed-support family, including proof that every feasible route either reaches the same competitor collision or remains above `Y=1`.

## Files

- `OBS_Gu_slack_correspondence.tex`: equation-by-equation source reconstruction and theorem.
- `OBS_Gu_adjacent_slack_ratios.csv`: machine-readable correspondence.
- `OBS_Gu_slack_equality_conditions.md`: equality and sharpness conditions.
- `OBS_Gu_slack_novelty_audit.md`: primary-source novelty audit.
- `n11_frontier.py`: one-command reconstruction and analysis.
- `n11_all_candidates.csv`: all 448 reconstructed path-level artifacts.
- `OBS_n11_localization_leadership_frontier.csv`: saved-artifact empirical fronts.
- `OBS_n11_constrained_frontier.csv`: local constrained threshold results.
- `OBS_n11_gradient_conflict.csv`: directed log-rate gradients.
- `OBS_n11_near_real_collision_trace.csv`: branch-aware collision trace.
- `OBS_n11_topology_frontier_comparison.csv`: saved topology groups.
- `OBS_n11_topology_perturbations.csv`: chord deletion/relocation tests.
- `n11_frontier_summary.json`: machine-readable summary.
