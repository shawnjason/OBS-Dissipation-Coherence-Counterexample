# Exact theta Evans reduction and the relaxation-pair bridge

## Scope and main result

This branch constructs a canonical lowest-terms Evans function for the exact
12-state theta witness and the valid 11-state chorded frontier, labels the
rotating and relaxation branches without repeated eigenvalue sorting, and
derives exact parameter derivatives of both roots.

The central new spectral mechanism is:

> The almost-real competitor is a weakly complexified pair of real relaxation
> roots created at a nondegenerate exceptional point of the
> reversible-to-circulating homotopy.  Below that point the right member of the
> split real pair moves with square-root speed and overtakes the rotating
> target.  The twelfth-state witness places the target a finite distance to
> the right of the exceptional-point centerline; the contracted 11-state
> frontier reduces that spacer distance by roughly two orders of magnitude.

This is materially stronger than the statement `det S(z)=0`: it identifies
the singular root-ordering mechanism, explains why a linear root derivative
at the final witness misses the leadership loss, and supplies a quantitative
spectral-spacer diagnostic.

The exact exceptional-point polynomial and endpoint root counts are rigorous.
The displayed exceptional and leadership locations are high-precision point
computations, not interval enclosures.

## 1. Exact component admittance

Let the boundary vertices be `b=(u,v)` and let `I_r` be the internal vertices
of one path component.  For

\[
M(z)=zI-Q
=\begin{pmatrix}M_{bb}&M_{bI}\\M_{Ib}&D_r(z)\end{pmatrix},
\]

write `C_r=M_{bI_r}`, `E_r=M_{I_rb}`, and let `H_r` be the diagonal
matrix of rates leaving each boundary vertex into this component.  The exact
component admittance is

\[
\mathcal A_r(z)=H_r-C_rD_r(z)^{-1}E_r.                 \tag{1}
\]

If

\[
d_r(z)=\det D_r(z),
\]

then

\[
\mathcal A_r(z)
=\frac{H_rd_r(z)-C_r\operatorname{adj}D_r(z)E_r}{d_r(z)}. \tag{2}
\]

For a pure path this is exactly the transfer-matrix endpoint flux map, in the
sign convention of `zI-Q`.  It contains the diagonal inward admittances and
the two generally unequal endpoint transmissions.  The complete numerator
and denominator coefficient lists for every entry are in `evans_exact.json`.

For n12 the three components are the pure paths of lengths 3, 5, and 5.  For
n11, formula (1) remains valid with boundary `{2,9}`.  The edge `3-9` is
included in the first component's boundary coupling and state-3 diagonal; it
does not require a larger boundary system.

### Pole-residue theorem

Every internal path block is an irreducible birth-death Jacobi matrix after a
positive diagonal similarity.  Consequently its Dirichlet roots are real and
simple.  At a root `p` choose right and left nullvectors `r,l` of `D_r(p)`.
Since `D'_r(z)=I`,

\[
\operatorname*{Res}_{z=p}D_r(z)^{-1}
=\frac{r l^*}{l^*r},
\]

and hence

\[
\boxed{
\operatorname*{Res}_{z=p}\mathcal A_r(z)
=-\frac{C_rrl^*E_r}{l^*r}
}                                                        \tag{3}
\]

has rank at most one.  The regression test verifies the stronger exact
polynomial statement

\[
d_r(z)\mid
\det\bigl(H_rd_r-C_r\operatorname{adj}(D_r)E_r\bigr)
\]

for all six components.

This rank-one fact is the reason a two-by-two secular determinant has only a
simple pole at a simple path pole: the apparent double-pole coefficient is
the determinant of the residue and vanishes.  It is also the algebraic reason
that clearing a product of the path denominators once—not its square—is
sufficient.

`pole_residue_map.csv` records all ten n12 poles and all nine n11 poles,
their complete two-by-two residue matrices, and their distances to both
labeled roots.  No competitor is a near-cancelled pole.  In n12 the closest
pole to the relaxation root is the short-path pole `-7155.613341...`, still
about `1345.57` away.  In n11 the closest is `-4.813045...`, about `0.85045`
away, versus a competitor imaginary part of only `0.02024`.

## 2. Canonical lowest-terms Evans function

Summing components gives

\[
S(z)=zI_2+\sum_r\mathcal A_r(z).
\]

Let

\[
d_I(z)=\prod_rd_r(z),\qquad
\chi(z)=\det(zI-Q).
\]

Exact Schur elimination and exact gcd checks give, for both systems,

\[
\boxed{E(z):=\det S(z)=\frac{\chi(z)}{d_I(z)}}.         \tag{4}
\]

Both `chi` and `d_I` are monic and coprime.  This fixes the otherwise arbitrary
Evans normalization and gives `E(z)~z^2` at infinity.  The lowest-terms
numerator degrees are 12 and 11; denominator degrees are 10 and 9.

The pole audit is exact:

- `gcd(chi,d_I)=1`, so no full root is lost at a path pole;
- `gcd(chi,chi')=1`, so every full root is simple at the audited centers;
- every component pole is simple;
- the rank-one residue identity prevents artificial second-order poles.

Multiplying an Evans function by a nonzero analytic factor changes `E'(z)`.
All derivative values in this package therefore use the canonical
normalization (4).  Root derivatives use a ratio in which any such factor
would cancel.

## 3. Analytic root labels and boundary fingerprints

At either audited center, surround the target root and competitor root by
disjoint contours containing no other characteristic root and no path pole.
The Riesz projections define unique analytic branches

\[
z_{\rm rot}(\theta),\qquad z_{\rm rel}(\theta)
\]

for every sufficiently small parameter perturbation.  This definition does
not sort roots by real part, so it remains valid across a leadership surface.

The boundary fingerprint is the invariant residue

\[
\boxed{
\operatorname*{Res}_{z=z_0}S(z)^{-1}
=\frac{\operatorname{adj}S(z_0)}{E'(z_0)}
}.                                                       \tag{5}
\]

Its range is the boundary trace of the full eigenmode.  The complete complex
matrices for both labels and both systems are recorded in `evans_exact.json`.
They provide a continuation fingerprint independent of eigenvector scaling.

At an exceptional point the two competitor roots cease to be individually
analytic.  The correct label there is the unordered two-root Riesz cluster.
Treating either split real root as a globally analytic continuation through
that point is a branch-switching error.

## 4. Exact root derivatives and local ordering surfaces

For any affine generator direction `Q_theta`, exact Faddeev-LeVerrier
differentiation produces the full polynomial

\[
\chi_\theta(z)=\partial_\theta\det(zI-Q(\theta)).
\]

At a simple labeled root,

\[
\boxed{
\frac{dz}{d\theta}
=-\frac{\chi_\theta(z)}{\chi'(z)}
=-\frac{E_\theta(z)}{E_z(z)}
}.                                                       \tag{6}

The exact coefficient lists of every `chi_theta` are stored in the JSON, and
the tests compare the differentiated Faddeev recurrence with a direct
symbolic characteristic polynomial.

Put

\[
G(\theta)=\operatorname{Re}
\bigl(z_{\rm rot}(\theta)-z_{\rm rel}(\theta)\bigr).
\]

The first-order ordering surface is

\[
G(0)+\sum_jg_j\,\delta\theta_j=0,
\qquad
g_j=\operatorname{Re}(z_{{\rm rot},j}'-z_{{\rm rel},j}'). \tag{7}
\]

For the exact n12 five-parameter stationary-flux coordinates,

\[
G_0=41.72709294659458608\ldots
\]

and

\[
(g_{\alpha_1},g_{\alpha_2},g_{\alpha_3},g_{\beta_1},g_{\beta_2})
=(3739.615,-785.783,-1765.943,533.073,-1679.235).
\]

Thus increasing short-path traffic or the first current coordinate moves the
relaxation competitor left relative to the target.  Increasing either long
path's traffic or the second current coordinate worsens ordering locally.

For n11, using bidirectional component-rate scales and a separate chord scale,

\[
G_0=0.0004087962694486602113\ldots
\]

and

\[
(g_{\rm short},g_{\rm long},g_{\rm contracted},g_{\rm chord})
=(3.16421,-1.88709,-1.26837,-0.0083478).
\]

Only the short component improves the local ordering gap when increased.
Because `G_0` is tiny, a short-path decrease of about `1.29e-4`, a long-path
increase of about `2.17e-4`, or a contracted-path increase of about
`3.22e-4` reaches the linearized surface individually.  Full complex
derivatives and surfaces are in `root_derivatives.csv` and
`root_ordering_surfaces.csv`.

## 5. Reversible-plus-circulation exceptional-point theorem

With the exact stationary law fixed, write every stationary edge flux as

\[
f_{ij}=\frac{T_{ij}+J_{ij}}2
\]

and define

\[
k_{ij}(\epsilon)
=\frac{T_{ij}+\epsilon J_{ij}}{2\pi_i},
\qquad
Q(\epsilon)=Q_{\rm rev}+\epsilon Q_{\rm circ}.          \tag{8}
\]

In the stationary inner product, `Q_rev` is self-adjoint and `Q_circ` is
skew-adjoint.  At `epsilon=0` every eigenvalue is real.

### General square-root bridge

Let the exact real characteristic polynomial be `P(z,epsilon)`.  Suppose at
`(z_c,epsilon_c)`

\[
P=P_z=0,qquad P_{zz}\ne0,qquad P_\epsilon\ne0,
\]

and no other root lies in the local cluster.  Taylor expansion (equivalently
Weierstrass preparation) gives

\[
z_\pm(\epsilon)
=z_c+O(\epsilon-\epsilon_c)
\pm\sqrt{c(\epsilon-\epsilon_c)+O((\epsilon-\epsilon_c)^2)},
\]

where

\[
\boxed{c=-\frac{2P_\epsilon}{P_{zz}}}.                  \tag{9}
\]

If `c<0`, the roots form a complex pair above `epsilon_c` and split into two
real roots below it.  The right real root moves as

\[
z_+(\epsilon)
=z_c+\sqrt{(-c)(\epsilon_c-\epsilon)}
+O(\epsilon_c-\epsilon).                               \tag{10}
\]

That square-root motion dominates every ordinary first derivative close to
the exceptional point.

### Exact systems

The bivariate polynomials `P(z,epsilon)` are stored exactly.  Exact Sturm
counts at rational endpoints prove that one real pair becomes a conjugate
pair in each narrow interval:

- n12: real-root count drops from 4 at `0.9995410` to 2 at `0.9995411`;
- n11: real-root count drops from 3 at `0.9998990` to 1 at `0.9998991`.

The high-precision simultaneous solutions of `P=P_z=0` are:

| system | `epsilon_EP` | `z_EP` | `c` |
|---|---:|---:|---:|
| n12 | `0.9995410541967138660...` | `-5810.98560118199794...` | `-7.90362867327048e6` |
| n11 | `0.9998990357960635135...` | `-3.96278219574220286...` | `-4.05715993008173` |

For n12, (9) predicts imaginary part `60.22738` at `epsilon=1`; the actual
value is `60.22076`.  For n11 it predicts `0.02023927`; the actual value is
`0.02023891`.  This identifies the audited almost-real roots as newly
complexified relaxation pairs, not path poles.

Below the exceptional point, the split right real root overtakes the rotating
target.  Direct 75-digit bisection of the complete spectrum gives:

| system | ordering crossing | EP minus crossing |
|---|---:|---:|
| n12 | `0.9993123774700247579...` | `2.28676726689e-4` |
| n11 | `0.9998989798486832992...` | `5.59473802142e-8` |

The target's real-part distance to the EP centerline is `42.253277...` for
n12 but only `0.00047639456...` for n11.  The leading estimate

\[
\epsilon_{\rm order}
\approx\epsilon_c-rac{(\operatorname{Re}z_{\rm rot}(\epsilon_c)-z_c)^2}{-c}
                                                               \tag{11}
\]

gives `0.99931517` for n12 and `0.99989897985748` for n11.  The n11 estimate
is within about `9e-12` in epsilon.

This produces a concrete spectral-spacer quantity:

\[
h_{\rm EP}=\operatorname{Re}z_{\rm rot}(\epsilon_c)-z_c.
\]

Path contraction collapses `h_EP` and the safe pre-EP ordering interval.  It
does not merely move a Dirichlet pole.  That is the sharpest mechanism-level
explanation here of the 12/11 transition.

The ordinary derivative at `epsilon=1` would predict a circulation crossing
far outside this interval.  It is invalid for that purpose because the path
from the witness to leadership loss crosses the competitor EP first.  This is
the principal branch-switching hostile-audit result.

## 6. Boundary and purely spectral representation of utilization

Let `R_r(z)` map the two boundary values to all values on component `r`:

\[
v_r=R_r(z)b,
\qquad
R_r(z)=\begin{pmatrix}I\\-D_r(z)^{-1}E_r\end{pmatrix}
\]

with rows placed in the component's vertex order.  Let `L_{T,r}` be the
traffic Laplacian and let `K_r` be the Hermitian oriented-edge matrix satisfying

\[
v_r^*K_rv_r=\sum_{(i,j)\in P_r}\operatorname{Im}(\bar v_i v_j).
\]

Then

\[
D=b^*\left(\sum_rR_r^*L_{T,r}R_r\right)b,
\]

\[
B=b^*\left(\sum_rJ_rR_r^*K_rR_r\right)b.              \tag{12}
\]

At a simple root, `b` can be taken from the range of the boundary residue
(5).  Thus (12) is a normalization-independent two-boundary Green-function
representation of utilization; no separately normalized internal
eigenvector is required.

For an actual nonreal eigenmode the established exact energy identities make
the result even simpler:

\[
D=2(-\operatorname{Re}z)N_v,
\qquad
B=(\operatorname{Im}z)N_v.
\]

Therefore the theta utilization is exactly

\[
\boxed{
\zeta(z)=
\frac{|\operatorname{Im}z|}
{2\Gamma(-\operatorname{Re}z)}
}.                                                       \tag{13}

The root `z` is supplied by the canonical secular equation and `Gamma` is
network data.  Equation (13) is a complete secular-data representation and
is automatically invariant under eigenvector and Evans-function
normalization.

For n12,

\[
\Gamma=1.4561696969566816137\ldots,
\]

and (13) gives

\[
\zeta_{\rm rot}=0.3462838936437632554\ldots,
\qquad
\zeta_{\rm rel}=0.0035581500887875076\ldots.
\]

Their ratio is `97.3213285001602...`.

### Almost-real theorem

For any eigenbranch

\[
z_{\rm rel}=-a+i\varepsilon,qquad a>0,
\]

equation (13) gives the exact—not merely asymptotic—law

\[
\boxed{\zeta=\frac{|\varepsilon|}{2\Gamma a}}.          \tag{14}
\]

Hence utilization is linear in the small imaginary part whenever `a` and
`Gamma` stay bounded away from zero.  Also

\[
\kappa=\frac{2aH}{\varepsilon^2N_v}.
\]

If `H/N_v` has a positive finite limit, then

\[
\kappa=\Theta(\varepsilon^{-2}).                        \tag{15}
\]

This proves the requested utilization collapse and explains the competitor's
large phase Cauchy--Schwarz penalty.  A universal claim without the stated
nondegeneracy of `H/N_v` would be false; modes whose current-weighted amplitude
also vanishes can evade (15), though not the exact law (14).

The n11 support contains the additional chord and is not a pure three-path
theta for the established `Gamma` definition.  No n11 `zeta` is reported by
silently applying the pure-theta formula.

## 7. Reproduction and audit status

```powershell
$env:PYTHONPATH='C:\Users\shawn\Documents\Codex\2026-07-17\r\work\obs\vendor'
& 'C:\Users\shawn\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' `
  -B 'work/theta_bridge/evans/build_evans_bridge.py'
& 'C:\Users\shawn\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' `
  -B -m unittest discover -s 'work/theta_bridge/evans' -p 'test_*.py' -v
```

Classification:

- path admittance, canonical Evans identity, gcds, polynomial derivatives,
  pole rank, and rational-endpoint real-root counts: **exact**;
- full center spectra and root derivatives: **100-digit numerical evaluation
  of exact polynomials/matrices**;
- exceptional and ordering locations: **75–130 digit numerical solutions of
  exact polynomials/full spectra**, with no interval enclosure claimed;
- square-root exceptional-point theorem and utilization formulas: **exact
  analytic theorems**;
- application of nondegeneracy signs at the displayed EPs: **high-precision
  evidence**, supported but not interval-certified.
