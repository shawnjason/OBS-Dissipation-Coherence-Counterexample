# Exact matched two-edge subdivision theorem

Use the `zI-Q` convention.  An oriented edge `u -> v` has forward rate `p>0`,
backward rate `q>0`, and boundary contribution

\[
A_{\rm edge}=\begin{pmatrix}p&-p\\-q&q\end{pmatrix}.
\]

Insert a degree-two state `x` with rates

\[
u\to x:p_1,\quad x\to u:q_1,\quad
x\to v:p_2,\quad v\to x:q_2.
\]

Let `s=q_1+p_2` be the internal escape rate.  Eliminating `x` gives the exact
boundary response

\[
A_{\rm sub}(z)=\frac1{z+s}
\begin{pmatrix}
p_1(z+p_2)&-p_1p_2\\
-q_1q_2&q_2(z+q_1)
\end{pmatrix}.                                      \tag{1}
\]

## Theorem 1: all positive zero-frequency matches

Every positive two-edge subdivision satisfying
`A_sub(0)=A_edge`, and only such a subdivision, is parametrized by
`0<alpha<1`, `s>0` as

\[
p_1=\frac p\alpha,\qquad q_1=(1-\alpha)s,\qquad
p_2=\alpha s,\qquad q_2=\frac q{1-\alpha}.           \tag{2}
\]

For this parametrization the response difference is

\[
\boxed{A_{\rm sub}(z)-A_{\rm edge}
=\frac{z}{z+s}R_\alpha},                              \tag{3}
\]

\[
R_\alpha=
\begin{pmatrix}
p(1-\alpha)/\alpha&p\\
q& q\alpha/(1-\alpha)
\end{pmatrix}
=c_\alpha d_\alpha^{\mathsf T},                       \tag{4}
\]

where

\[
c_\alpha=\binom{p}{q\alpha/(1-\alpha)},\qquad
d_\alpha=\binom{(1-\alpha)/\alpha}{1}.
\]

Thus the exact dynamic defect is rank one.  It vanishes at zero, has first
moment `R_alpha/s`, has one pole at `-s`, and tends to `R_alpha` as
`|z| -> infinity`.

### Proof

At zero, (1) has effective forward and backward rates

\[
p_{\rm eff}=p_1p_2/s,\qquad q_{\rm eff}=q_1q_2/s.
\]

Writing `alpha=p_2/s` gives `q_1=(1-alpha)s`; matching `p,q` forces the
remaining two formulas in (2).  Substitution and subtraction give (3)--(4).

## Theorem 2: stationary quantities preserved and the mass knob

Fix positive endpoint stationary weights `pi_u,pi_v`.  With (2), define the
unnormalized inserted-state stationary weight

\[
m=\widetilde\pi_x
=\frac{\pi_up/\alpha+\pi_vq/(1-\alpha)}s.             \tag{5}
\]

Then the two subdivided edges carry the same stationary current

\[
J=\pi_up-\pi_vq                                      \tag{6}
\]

as the original edge.  The total rate affinity and path entropy are also
preserved:

\[
\log\frac{p_1p_2}{q_1q_2}=\log\frac pq,qquad
\sigma_{\rm segment}=J\log(p/q).                     \tag{7}
\]

Conversely any desired unnormalized inserted mass `m>0` is realized uniquely,
for fixed `alpha`, by

\[
s=\frac{\pi_up/\alpha+\pi_vq/(1-\alpha)}m.           \tag{8}
\]

The augmented invariant measure has total mass `1+m` if the original one was
normalized.  After normalization, all old masses and all stationary fluxes
are scaled by `1/(1+m)`.  Hence inserting positive mass cannot literally keep
every old normalized probability fixed; claims that it does are inconsistent
with normalization.

## Theorem 3: resistance and moment obstruction

Let the original stationary forward/backward fluxes be `f=pi_u p` and
`g=pi_v q`, with traffic `T=f+g` and current `J=f-g`.  In the unnormalized
external scale, the subdivided edge traffics are

\[
T_1=\frac{T+J(1-\alpha)}\alpha,\qquad
T_2=\frac{T-J\alpha}{1-\alpha}.                       \tag{9}
\]

They obey the exact identity

\[
\boxed{
\frac1{T_1}+\frac1{T_2}-\frac1T
=\frac{J^2}{T T_1T_2}.}                               \tag{10}
\]

Therefore:

* if `J != 0`, every finite positive zero-frequency-matched subdivision
  strictly increases stationary resistance;
* exact simultaneous preservation of zero-frequency response and resistance
  is possible only at equilibrium (`J=0`) or in a degenerate limit
  `alpha -> 0,1`;
* a finite subdivision never preserves the first admittance moment, since
  `A_sub'(0)=R_alpha/s` is nonzero.

The resistance is maximized at

\[
\alpha_* = \frac{\sqrt f}{\sqrt f+\sqrt g},\qquad
T_1=T_2=(\sqrt f+\sqrt g)^2,                           \tag{11}
\]

with

\[
R_{\rm sub,max}=\frac2{(\sqrt f+\sqrt g)^2},\qquad
\frac{R_{\rm sub,max}}{1/T}
=\frac{2(f+g)}{(\sqrt f+\sqrt g)^2}\in[1,2).          \tag{12}
\]

After normalizing the augmented stationary measure, the new resistance is
`(1+m)(1/T_1+1/T_2)`, strengthening rather than removing the obstruction.

## Theorem 4: exact root-response bridge

Let `S_edge(z)` be the full two-boundary Schur matrix of a theta network that
contains the original edge contribution.  Replacing that edge by (2) gives

\[
S_{\rm sub}(z)=S_{\rm edge}(z)+h_s(z)c_\alpha
d_\alpha^{\mathsf T},\qquad h_s(z)=\frac z{z+s}.       \tag{13}
\]

The determinant lemma yields the exact secular relation

\[
\boxed{
E_{\rm sub}(z)=E_{\rm edge}(z)
+h_s(z)d_\alpha^{\mathsf T}\operatorname{adj}(S_{\rm edge}(z))c_\alpha.} \tag{14}
\]

Let `z_0` be a simple root of `E_edge`, and let `x,y` be right and left
boundary null vectors of `S_edge(z_0)`.  Along the physical fast-state family
`epsilon=1/s -> 0+`, its continued root satisfies

\[
\boxed{
\frac{dz}{d\epsilon}(0)
=-z_0\frac{(y^{\mathsf T}c_\alpha)
(d_\alpha^{\mathsf T}x)}{y^{\mathsf T}S'_{\rm edge}(z_0)x}.}             \tag{15}
\]

Equation (15) is the precise target-versus-competitor response difference.
The sign of its real part is a mode-dependent nonselfadjoint susceptibility.
The displayed identity supplies no sign from positivity alone.  Therefore a
proof that matched subdivision always moves the relaxation root left, or
always favors the rotating root, requires an additional phase or residue
hypothesis.  This branch does not claim an explicit Markov counterexample to
universal monotonicity.

For target and competitor roots `z_rot,z_rel`, the first-order ordering change
is the real part of the difference between their two instances of (15).  This
is directly computable from boundary Schur data and supplies a falsifiable
local spacer criterion without reconstructing internal eigenvectors.

## Exact matched contraction of the certified twelfth state

On the certified path segment `11-12-10`, oriented `11 -> 12 -> 10`, the
integer rates are

\[
p_1=977,\quad q_1=14747,\quad p_2=784,\quad q_2=13636.
\]

Thus

\[
s=15531,\quad \alpha=784/15531,
\]

and its exact zero-frequency matched contraction `11-10` has

\[
\boxed{p=765968/15531,\qquad q=201090092/15531.}       \tag{16}
\]

This is the correct causal control for removing state 12.  Literal deletion,
lumping, or comparison to a separately optimized 11-state matrix changes
additional response quantities and cannot isolate subdivision.

Using the certified stationary endpoint weights, the effective contracted
fluxes are `f=0.9469201137` and `g=286.3076343561`.  Hence the
resistance-maximizing split is `alpha_*=0.05438209016...`, while the actual
split is `0.05047968579...`.  The actual resistance ratio is
`1.79384872565`, versus the exact allowed maximum `1.79430128627`; it realizes
`99.9430%` of the maximum *excess* resistance.  Equivalently, the actual edge
traffics, `322.8776` and `317.6967`, are nearly impedance-balanced.

The scalar response filter also distinguishes the two certified roots before
the mode-dependent boundary susceptibility is applied:

\[
h_s(z_{\rm rot})=-0.17394+0.69978i,\qquad
h_s(z_{\rm rel})=-0.59784+0.00990i.                    \tag{17}
\]

Thus the target sees an almost quadrature dynamic correction while the
competitor sees an almost real negative correction.  This is a response-level
distinction evaluated at certified root centers, not yet a proof of the signs
of their resulting root motions.
