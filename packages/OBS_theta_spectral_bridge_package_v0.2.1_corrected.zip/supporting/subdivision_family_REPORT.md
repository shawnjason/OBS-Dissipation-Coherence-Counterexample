# Spectral-bridge subdivision/family branch report

## Resolution

`NOT RESOLVED`.

The branch proves an exact matched-subdivision response theorem and two sharp
obstructions, but it does not yet certify the target-versus-competitor motion
of the witness or a successful transparent family.

## Strongest exact theorem

Every positive two-edge replacement matching an edge at zero frequency has a
two-parameter `alpha,s` form.  It preserves stationary current, total affinity,
segment entropy, and allows arbitrary inserted mass.  Its complete response
difference is

`A_sub(z)-A_edge = [z/(z+s)] c_alpha d_alpha^T`.

This yields an exact determinant update and simple-root motion formula using
only two-boundary left/right null vectors.  The certified `11-12-10` segment
contracts exactly to rates

`k_11,10=765968/15531`, `k_10,11=201090092/15531`.

Witness-specifically, this split realizes `99.9430%` of the maximum possible
excess resistance among all zero-response matches of that effective edge. Its
two edge traffics are nearly balanced. At the certified roots the scalar
dynamic filter `z/(z+s)` is almost quadrature for the rotating target but
almost real for the competitor. This isolates a concrete impedance and
frequency-filter role for state 12 without assuming the final root-motion
sign.

## Strongest proved obstruction

At nonzero current, a finite zero-matched subdivision strictly increases
stationary resistance:

`R_sub-R_edge=J^2/(T T1 T2)>0`.

It also cannot preserve the first admittance moment.  Hence zero response,
resistance, and an additional dynamic moment cannot all be held fixed by a
finite positive two-edge replacement.

For two identical homogeneous long paths, exchange symmetry creates an
unavoidable real Dirichlet sector.  Its slowest root

`-(a+b)+2 sqrt(ab) cos(pi/L)`

moves toward zero with length, giving a rigorous reason why naive symmetric
subdivision can damage leadership while increasing phase capacity.

## Transparent family extraction

The exact witness compresses sharply in transformed coordinates.  Away from
one endpoint layer, long-path traffic CVs are `0.0161` and `0.00776`;
stationary-mass CVs are `0.0768` and `0.0505`.  Target amplitudes follow
geometric ratios `0.73638` (CV `0.01366`) and `1.33325` (CV `0.00443`), with
nearly uniform phase increments.

This yields a constant-complexity role-layer `Theta_(3,L,L)` family with a
three-layer reservoir path, repeated long-path bulk cells, and one endpoint
correction on each long path.  It contains no per-edge arrays growing with
`L`. Its exact-rational finite-decimal `L=5` member has numerical
`Y=0.8932018649`, visibility `59.2173`, leading gap `43.5868`,
`tau=1.53417`, `kappa=3.84305`, and `eta_cur=0.151495`.

The fixed-parameter length scan is successful for `L=5,...,9`, fails
visibility/leadership for `L=3,4`, and has `Y>1` for `L=10,...,20`. This is a
numerical finite-window result, not yet a certified path-length theorem.

For the matched state-12 homotopy, double-precision continuation finds a
genuinely valid one-parameter window bounded by leadership crossings near
`s=15064.60191` and `s=17119.28613`. The lower boundary is a real relaxation
root; the upper boundary is the almost-real complex pair. Visibility holds on
the wider interval approximately `(12776.05136,31422.93513)`, and `Y<1` at
all four reported surfaces. The exact contraction is violating as a labeled
mode (`Y=0.89589`) but is neither visible nor leading.

The inverse-mode equations were also solved locally: at every noncollinear
phase turn, the complex eigenvalue equation uniquely fixes the two adjacent
real traffics.  Consecutive states must agree on their shared traffic, giving
explicit compatibility constraints that rule out hiding one free fitted
constant on every edge.

## Precise missing lemma

For the exact matched state-12 homotopy, establish a validated interval on

`Re z_rot(s)-Re z_rel(s)`

from the boundary susceptibility or secular determinant and simultaneously
control every other root.  Positivity alone cannot supply the sign.  This is
the remaining causal spectral-spacer lemma.

The symbolic identities and all numerical scripts were executed with the
project runtime. No negative search result is promoted to a theorem.
