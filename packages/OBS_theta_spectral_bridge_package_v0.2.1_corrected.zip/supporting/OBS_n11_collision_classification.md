# Eleven-state collision and frontier classification

## Classification

For the fixed support of `FINAL_proj_best_t1e5`, the observed boundary is best classified numerically as a **near-defective collision of the almost-real competitor pair, followed by a target/competitor exchange in leadership**. It is not a collision between the rotating target and the competitor.

At the saved point:

```
z_rot = -3.96242916348 + 3.97284303329 i
z_rel = -3.96283795975 + 0.02023890703 i
g_lead = 0.000408796269
```

The target and competitor are separated by about `3.95260` in the complex plane even though their real parts nearly agree. The target's Euclidean eigenvalue condition number is about `4.07`. The competitor's is about `350`, and its conjugate separation is only `0.04048`. This identifies the ill-conditioned object as the competitor pair itself.

## First-order conflict and the cusp

In normalized directed log-rate coordinates at the final point,

```
cos(-grad logY, grad g_lead)        = -0.32823
cos(-grad log eta_cur, grad g_lead) = -0.53452
cos(-grad log tau, grad g_lead)     = +0.20914
cos(-grad log kappa, grad g_lead)   = +0.47732
```

Thus localization improvement is the strongest first-order conflict with leadership, while improvements in `tau` and especially `kappa` are locally compatible with leadership. The identity

```
grad logY = grad log tau + grad log kappa + grad log eta_cur
```

closes to norm `4.2e-9` in the finite-difference audit.

Because the two main gradients are not exactly antiparallel, there is a formal first-order direction that initially improves both `Y` and `g_lead`. Along the explicit normalized sum of those two favorable directions, however, the almost-real competitor pair reaches its real-axis collision almost immediately. At trace parameter `t=9.0e-5`, its imaginary part is about `0.00384` and its condition number about `1845`; by `t=9.5e-5` NumPy resolves two real roots and a condition number about `2639`. The target still has `Y≈1.02137` there. The newly split real root moves to the right and makes the leading gap negative.

This is double-precision evidence, not an interval-certified exceptional point. The trace file records every root diagnostic used for the classification.

## Fixed-support Pareto evidence

The local fixed-support study combines 5,626 random/gradient-plane samples with 6,266 normalized one-coordinate log-rate samples. No sample entered

```
Y < 1, g_vis > 0, g_lead > 0.
```

The lowest sampled `Y` with positive leading gap was

```
Y = 1.02056982359
g_lead = 1.24658e-4
```

on the `log k_9_8` coordinate scan. The largest leading gap among coordinate-scan points with `Y<=1` was

```
Y = 0.99902606034
g_lead = -0.15684969.
```

Random/plane samples gave a closer but still negative point, `Y=0.99844419`, `g_lead=-0.0574403`.

These numbers describe only the sampled local family. They neither prove that its Pareto front is complete nor exclude a valid point elsewhere on the same support.

## Nearby topologies

Deleting the `3-9` chord from the final rate profile gives a pure theta support with `Y≈1.02392` and negative leading gap `-0.02313`. Eighty-four chord relocations/orientations plus that deletion were tested without retuning all rates. None was a valid violation. The best leading relocated profiles still had `Y>1.022`. Because these are unmatched rate transplants, they are topology diagnostics only, not topology comparisons under an optimized or certified family.

## Scope

The saved-artifact front pools disconnected supports and lineages; it is not a continuous Pareto curve. The fixed-support trace is local and numerical. No topology-wide n11 obstruction follows from either calculation.
