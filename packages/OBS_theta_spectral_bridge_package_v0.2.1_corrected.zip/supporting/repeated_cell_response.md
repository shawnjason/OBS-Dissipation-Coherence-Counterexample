# Constant-complexity repeated-cell path response

Consider an `L`-edge path with the same forward rate `b>0` and backward rate
`a>0` on every cell.  There are `m=L-1` internal states.  Put

\[
x(z)=\frac{z+a+b}{2\sqrt{ab}},\qquad
\theta_m(z)=(\sqrt{ab})^m U_m(x(z)),                  \tag{1}
\]

where `U_m` is the Chebyshev polynomial of the second kind and
`theta_0=1`, `theta_1=z+a+b`.  Equivalently,

\[
\theta_m=(z+a+b)\theta_{m-1}-ab\theta_{m-2}.          \tag{2}
\]

Eliminating the internal states gives

\[
A_L(z)=
\begin{pmatrix}
b-ab\theta_{m-1}/\theta_m&-b^L/\theta_m\\
-a^L/\theta_m&a-ab\theta_{m-1}/\theta_m
\end{pmatrix}.                                       \tag{3}
\]

Its path-response poles are exactly

\[
z_k=-(a+b)+2\sqrt{ab}\cos\frac{k\pi}{L},qquad
k=1,\ldots,L-1,                                      \tag{4}
\]

and are real, simple, and negative.  Equations (1)--(4) define a genuine
constant-complexity family: the parameter count is independent of `L`, and
length enters only through a Chebyshev degree or a cell-transfer-matrix power.

For `L=2`, requiring the two cells themselves to be identical while matching
a prescribed single edge with rates `p,q` has the unique solution

\[
b=p+\sqrt{pq},\qquad a=q+\sqrt{pq}.                   \tag{5}

This follows from `b^2/(a+b)=p`, `a^2/(a+b)=q`.

The real-pole statement does not prove full-generator spectral safety or
leadership: coupling several path responses at the theta boundaries can still
create complex roots.  Conversely, negative searches over repeated cells do
not exclude them.  Any obstruction for a complete theta class must analyze
the common two-boundary determinant, not only (4).

## Symmetric-path real-sector obstruction

Suppose two theta paths are identical, including all directed rates, and the
full generator is invariant under exchanging their corresponding internal
states while fixing the branch vertices.  The exchange-odd invariant subspace
has zero values at both branch vertices.  Its generator is exactly the
Dirichlet internal path block.  A birth--death block on a line is diagonally
symmetrizable, so every exchange-odd eigenvalue is real.

For identical homogeneous `L`-edge paths these unavoidable real eigenvalues
are precisely (4).  In particular the slowest odd root is

\[
z_{\rm odd,1}=-(a+b)+2\sqrt{ab}\cos(\pi/L).            \tag{6}
\]

Any globally leading rotating root must satisfy the necessary condition

\[
\operatorname{Re}z_{\rm rot}>z_{\rm odd,1}.            \tag{7}
\]

At fixed `a,b`, `z_odd,1` increases strictly with `L`.  Thus a symmetric
repeated-cell subdivision introduces a real competitor that becomes *harder*,
not easier, to beat as the path grows.  This is a rigorous obstruction to the
naive claim that identical longer paths automatically improve leadership.
It is not an exclusion of all symmetric theta counterexamples: the even
sector and the `L`-dependence of `z_rot` still require analysis.
