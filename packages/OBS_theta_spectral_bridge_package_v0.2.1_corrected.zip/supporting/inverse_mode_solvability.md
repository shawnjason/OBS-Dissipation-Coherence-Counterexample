# Exact inverse-mode traffic equations

This branch asks when a prescribed complex path profile can be realized by
positive stationary traffics instead of fitting rates first.

Orient a path `0,1,...,L` and prescribe stationary weights `pi_i>0`, constant
path current `J`, a nonreal target root `z`, and complex values `v_i`.  Put
`d_i=v_i-v_(i-1)`.  In stationary-flux coordinates, the backward eigenvalue
equation at an internal state `i` is exactly

\[
-(T_i-J)d_i+(T_{i+1}+J)d_{i+1}=2\pi_i z v_i,
\]

or

\[
-d_iT_i+d_{i+1}T_{i+1}=r_i,qquad
r_i=2\pi_i z v_i-J(d_i+d_{i+1}).                      \tag{1}
\]

Traffics are real unknowns.  If

\[
\omega_i=\operatorname{Im}(\bar d_i d_{i+1})\ne0,
\]

the complex equation (1) uniquely determines both adjacent traffics:

\[
T_i=-\frac{\operatorname{Im}(\bar r_i d_{i+1})}{\omega_i},
\qquad
T_{i+1}=\frac{\operatorname{Im}(\bar d_i r_i)}{\omega_i}.                \tag{2}
\]

Thus a prescribed profile is realizable on the path only if:

1. the value proposed for each shared traffic by state `i` agrees with the
   value proposed by state `i+1`;
2. every resulting traffic satisfies `T_i>|J|`;
3. the branch-vertex equations from all three paths hold simultaneously.

Condition 1 gives `L-2` explicit real compatibility equations.  It is the
precise obstruction hidden by a free per-edge inverse solve.  Treating every
`T_i` as an independent fitted constant evades rather than solves these
compatibilities.

If `omega_i=0`, equation (1) instead requires `r_i` to lie on the real span of
the collinear increments and leaves at least one traffic locally
underdetermined.  These degenerate straight-profile cases require separate
boundary and positivity analysis.

For uniform mass and a complex geometric profile `v_i=c rho^i`, compatibility
reduces to the familiar homogeneous-cell dispersion relation

\[
z=a(\rho^{-1}-1)+b(\rho-1),                            \tag{3}
\]

where `a=(T-J)/(2 pi)` and `b=(T+J)/(2 pi)`.  This explains why the observed
near-geometric amplitude and phase profiles are natural transformed
coordinates.  It does not by itself prove boundary matching or global
leadership.
