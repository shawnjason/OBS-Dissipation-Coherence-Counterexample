#!/usr/bin/env python3
"""Track target and competitor under the exact 11-12-10 matched homotopy.

At s=15531 this is the certified n=12 generator.  As s tends to infinity,
one pole/root escapes left and the remaining spectrum converges to the exact
zero-frequency-matched 11-state contraction.  NumPy is the only dependency.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


WORK = Path(__file__).resolve().parents[3]
SOURCE = WORK / "sub12/spectral_repair/checkpoints/n12_e13_delete45_delete68_integer.json"
S0 = 15531.0
ALPHA = 784.0 / 15531.0
P = 765968.0 / 15531.0       # 11 -> 10 after contraction
Q = 201090092.0 / 15531.0    # 10 -> 11 after contraction


def generator(k: np.ndarray) -> np.ndarray:
    q = k.copy()
    np.fill_diagonal(q, 0.0)
    q[np.diag_indices_from(q)] = -q.sum(axis=1)
    return q


def stationary(q: np.ndarray) -> np.ndarray:
    a = q.T.copy()
    a[-1] = 1.0
    rhs = np.zeros(len(q)); rhs[-1] = 1.0
    return np.linalg.solve(a, rhs)


def rates_at_s(base: np.ndarray, s: float) -> np.ndarray:
    k = base.copy()
    # zero the certified four rates, then impose the matched family
    for i, j in [(10, 11), (11, 10), (11, 9), (9, 11)]:
        k[i, j] = 0.0
    k[10, 11] = P / ALPHA
    k[11, 10] = (1.0 - ALPHA) * s
    k[11, 9] = ALPHA * s
    k[9, 11] = Q / (1.0 - ALPHA)
    return k


def contracted_rates(base: np.ndarray) -> np.ndarray:
    keep = [i for i in range(12) if i != 11]
    k = base[np.ix_(keep, keep)].copy()
    k[10, 9], k[9, 10] = P, Q
    return k


def entropy(k: np.ndarray, p: np.ndarray) -> float:
    ans = 0.0
    for i in range(len(k)):
        for j in range(i + 1, len(k)):
            if k[i, j] > 0 and k[j, i] > 0:
                current = p[i] * k[i, j] - p[j] * k[j, i]
                ans += current * np.log((p[i] * k[i, j]) / (p[j] * k[j, i]))
    return float(ans)


def nearest(vals: np.ndarray, previous: complex, forbidden: set[int] | None = None,
            require_positive_imag: bool = True) -> int:
    forbidden = forbidden or set()
    candidates = [i for i, z in enumerate(vals)
                  if i not in forbidden and abs(z) > 1e-7
                  and (z.imag > 1e-7 if require_positive_imag else True)]
    return min(candidates, key=lambda i: abs(vals[i] - previous))


def one_row(k: np.ndarray, target_guess: complex, competitor_guess: complex) -> tuple[dict, complex, complex]:
    q, pstat = generator(k), stationary(generator(k))
    vals = np.linalg.eigvals(q)
    it = nearest(vals, target_guess)
    target_mate = int(np.argmin(abs(vals - np.conj(vals[it]))))
    ic = nearest(vals, competitor_guess, {it, target_mate}, require_positive_imag=False)
    target, competitor = vals[it], vals[ic]
    excluded = {it}
    # Exclude only the target conjugate mate.  The competitor must remain in
    # the full-spectrum leadership comparison.
    excluded.add(target_mate)
    other_vals = [vals[i] for i in range(len(vals)) if i not in excluded and abs(vals[i]) > 1e-7]
    global_competitor = max(other_vals, key=lambda z: z.real)
    sigma = entropy(k, pstat)
    row = {
        "n": len(k),
        "target_real": target.real,
        "target_imag": target.imag,
        "competitor_real": competitor.real,
        "competitor_imag": competitor.imag,
        "ordering_gap": target.real - competitor.real,
        "global_competitor_real": global_competitor.real,
        "global_competitor_imag": abs(global_competitor.imag),
        "global_leading_gap": target.real - global_competitor.real,
        "visibility": target.imag + target.real,
        "sigma": sigma,
        "Y": sigma * (-target.real) / target.imag**2,
        "pmin": pstat.min(),
    }
    return row, target, competitor


def track(base: np.ndarray, s_values: list[float], target0: complex, competitor0: complex) -> list[dict]:
    rows, target, competitor = [], target0, competitor0
    for s in s_values:
        row, target, competitor = one_row(rates_at_s(base, s), target, competitor)
        row["s"] = s
        row["epsilon"] = 1.0 / s
        row["inserted_mass"] = stationary(generator(rates_at_s(base, s)))[11]
        rows.append(row)
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()
    payload = json.loads(SOURCE.read_text())
    base = np.asarray(payload["integer_rate_numerators"], float) / payload["denominator"]
    target0 = complex(-5769.662333445446, 5818.682682437687)
    competitor0 = complex(-5811.389426392041, 60.220759297817)

    upward = S0 * np.geomspace(1.0, 1e4, 161)
    downward = S0 * np.geomspace(1.0, 0.1, 81)
    rows_up = track(base, list(upward), target0, competitor0)
    rows_down = track(base, list(downward), target0, competitor0)
    rows = list(reversed(rows_down[1:])) + rows_up

    contraction, _, _ = one_row(contracted_rates(base), rows_up[-1]["target_real"] + 1j*rows_up[-1]["target_imag"],
                                  rows_up[-1]["competitor_real"] + 1j*rows_up[-1]["competitor_imag"])
    print(json.dumps({"exact_center": rows_up[0], "large_s": rows_up[-1], "exact_contraction": contraction}, indent=2))
    if args.write:
        out = Path(__file__).resolve().parents[1] / "data/matched_subdivision_root_locus.csv"
        with out.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=rows[0].keys())
            writer.writeheader(); writer.writerows(rows)
        print(out)


if __name__ == "__main__":
    main()
