#!/usr/bin/env python3
"""Symbolically verify every identity in matched_subdivision_theorem.md."""

import sympy as sp


p, q, alpha, s, z = sp.symbols("p q alpha s z", positive=True)
piu, piv = sp.symbols("pi_u pi_v", positive=True)

p1 = p / alpha
q1 = (1 - alpha) * s
p2 = alpha * s
q2 = q / (1 - alpha)

A_edge = sp.Matrix([[p, -p], [-q, q]])
A_sub = sp.Matrix([
    [p1 * (z + p2), -p1 * p2],
    [-q1 * q2, q2 * (z + q1)],
]) / (z + s)
R = sp.Matrix([
    [p * (1 - alpha) / alpha, p],
    [q, q * alpha / (1 - alpha)],
])

assert sp.simplify(A_sub.subs(z, 0) - A_edge) == sp.zeros(2)
assert sp.simplify(A_sub - A_edge - z * R / (z + s)) == sp.zeros(2)
assert sp.factor(R.det()) == 0
assert sp.simplify(sp.diff(A_sub, z).subs(z, 0) - R / s) == sp.zeros(2)

m = (piu * p / alpha + piv * q / (1 - alpha)) / s
J = piu * p - piv * q
assert sp.simplify(piu * p1 - m * q1 - J) == 0
assert sp.simplify(m * p2 - piv * q2 - J) == 0
assert sp.simplify(p1 * p2 / (q1 * q2) - p / q) == 0

f, g = sp.symbols("f g", positive=True)
T, current = f + g, f - g
T1 = (T + current * (1 - alpha)) / alpha
T2 = (T - current * alpha) / (1 - alpha)
assert sp.factor(1 / T1 + 1 / T2 - 1 / T - current**2 / (T * T1 * T2)) == 0

alpha_star = sp.sqrt(f) / (sp.sqrt(f) + sp.sqrt(g))
assert sp.simplify(T1.subs(alpha, alpha_star) - (sp.sqrt(f) + sp.sqrt(g))**2) == 0
assert sp.simplify(T2.subs(alpha, alpha_star) - (sp.sqrt(f) + sp.sqrt(g))**2) == 0

print("all matched-subdivision symbolic identities verified")
