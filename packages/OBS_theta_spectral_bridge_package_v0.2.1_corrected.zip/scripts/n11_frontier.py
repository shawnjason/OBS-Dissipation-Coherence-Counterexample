#!/usr/bin/env python3
"""Independent reconstruction and local Program-I diagnostics for saved n=11 chains.

Only NumPy and the Python standard library are required.  The script deliberately
distinguishes (a) an empirical front across saved, generally disconnected
topologies from (b) a local fixed-support front around FINAL_proj_best_t1e5.
Neither is promoted to a topology-wide exclusion theorem.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SCAN = ROOT / "work/sub12/hostile_audit_2/campaign_json_rescan.csv"
FINAL = ROOT / "work/sub12/near11/FINAL_proj_best_t1e5.json"
MERGE34 = ROOT / "work/sub12/direct10/e13_to_n11_merge_3_4.json"
EPS = 2.0e-6


def rates_from_obj(obj: dict) -> np.ndarray | None:
    if isinstance(obj.get("rates"), list):
        return np.asarray(obj["rates"], dtype=float)
    if isinstance(obj.get("integer_rate_numerators"), list):
        return np.asarray(obj["integer_rate_numerators"], dtype=float) / float(obj.get("denominator", 1))
    return None


def row_generator(rates: np.ndarray) -> np.ndarray:
    q = np.array(rates, dtype=float, copy=True)
    np.fill_diagonal(q, 0.0)
    q[np.diag_indices_from(q)] = -q.sum(axis=1)
    return q


def stationary(q: np.ndarray) -> np.ndarray:
    a = q.T.copy()
    b = np.zeros(q.shape[0])
    a[-1, :] = 1.0
    b[-1] = 1.0
    p = np.linalg.solve(a, b)
    p = np.real_if_close(p).astype(float)
    p /= p.sum()
    return p


def support_edges(rates: np.ndarray) -> list[tuple[int, int]]:
    return [
        (i, j)
        for i in range(len(rates))
        for j in range(i + 1, len(rates))
        if rates[i, j] > 0.0 or rates[j, i] > 0.0
    ]


def topology_data(rates: np.ndarray) -> tuple[str, str, int, int]:
    edges = support_edges(rates)
    sig = ";".join(f"{i+1}-{j+1}" for i, j in edges)
    tid = hashlib.sha256(sig.encode()).hexdigest()[:12]
    return tid, sig, len(edges), len(edges) - len(rates) + 1


def theta_paths(rates: np.ndarray) -> list[list[int]] | None:
    """Return three branch-to-branch paths only for a pure combinatorial theta."""
    n = len(rates)
    edges = support_edges(rates)
    if len(edges) != n + 1:
        return None
    nbr = {i: [] for i in range(n)}
    for i, j in edges:
        nbr[i].append(j)
        nbr[j].append(i)
    branch = [i for i in range(n) if len(nbr[i]) == 3]
    if len(branch) != 2 or any(len(nbr[i]) != (3 if i in branch else 2) for i in range(n)):
        return None
    u, v = branch
    paths = []
    used_first = set()
    for first in nbr[u]:
        if first in used_first:
            continue
        path = [u, first]
        prev, cur = u, first
        while cur != v:
            nxts = [x for x in nbr[cur] if x != prev]
            if len(nxts) != 1 or len(path) > n + 1:
                return None
            prev, cur = cur, nxts[0]
            path.append(cur)
        used_first.add(first)
        paths.append(path)
    return paths if len(paths) == 3 else None


def entropy_sigma(rates: np.ndarray, p: np.ndarray) -> float:
    s = 0.0
    for i, j in support_edges(rates):
        if rates[i, j] <= 0.0 or rates[j, i] <= 0.0:
            return float("nan")
        s += p[i] * rates[i, j] * math.log(rates[i, j] / rates[j, i])
        s += p[j] * rates[j, i] * math.log(rates[j, i] / rates[i, j])
    return s


def select_target(vals: np.ndarray, reported: dict | None, target_ref: complex | None) -> int | None:
    positive = [i for i, z in enumerate(vals) if z.imag > 1e-9 * max(1.0, abs(z))]
    if not positive:
        return None
    if target_ref is not None:
        return min(positive, key=lambda i: abs(vals[i] - target_ref) / (1.0 + abs(target_ref)))
    if reported:
        try:
            lr = float(reported["lambda_R"])
            li = float(reported["lambda_I"])
            if lr > 0.0 and li > 0.0:
                ref = complex(-lr, li)
                return min(positive, key=lambda i: abs(vals[i] - ref) / (1.0 + abs(ref)))
        except (KeyError, TypeError, ValueError):
            pass
    return max(positive, key=lambda i: vals[i].imag / max(-vals[i].real, 1e-300))


def eig_condition(q: np.ndarray, z: complex, right: np.ndarray) -> float:
    lvals, lvecs = np.linalg.eig(q.T.conj())
    j = int(np.argmin(abs(lvals - np.conj(z))))
    left = lvecs[:, j]
    den = abs(np.vdot(left, right))
    return float(np.linalg.norm(left) * np.linalg.norm(right) / den) if den else float("inf")


def calculate(rates: np.ndarray, reported: dict | None = None, target_ref: complex | None = None) -> dict | None:
    rates = np.asarray(rates, dtype=float)
    q = row_generator(rates)
    try:
        p = stationary(q)
    except np.linalg.LinAlgError:
        return None
    if np.min(p) <= 0.0:
        return None
    vals, vecs = np.linalg.eig(q)
    ti = select_target(vals, reported, target_ref)
    if ti is None:
        return None
    z = vals[ti]
    v = vecs[:, ti]
    zero_i = int(np.argmin(abs(vals)))
    conj_i = int(np.argmin(abs(vals - np.conj(z))))
    excluded = {ti, conj_i, zero_i}
    competitors = [i for i in range(len(vals)) if i not in excluded]
    ci = max(competitors, key=lambda i: vals[i].real)
    zc = vals[ci]

    a, b = -float(z.real), float(z.imag)
    sigma = entropy_sigma(rates, p)
    nv = float(np.dot(p, abs(v) ** 2))
    m = float(np.max(abs(v) ** 2))
    d = bb = c = h = g = 0.0
    for i, j in support_edges(rates):
        fij = p[i] * rates[i, j]
        fji = p[j] * rates[j, i]
        t = fij + fji
        cur = fij - fji
        dv = v[j] - v[i]
        zz = float(np.imag(np.conj(v[i]) * v[j]))
        d += t * abs(dv) ** 2
        bb += cur * zz
        c += cur * cur / t
        h += (cur * cur / (2.0 * t)) * (abs(v[i]) ** 2 + abs(v[j]) ** 2)
        g += t * zz * zz
    y = sigma * a / (b * b)
    tau = sigma / (2.0 * c)
    kappa = d * h / (bb * bb)
    eta_cur = nv * c / h
    eta = nv / m
    kappa_gu = c * g / (bb * bb)
    s_gu = m * d / g
    s_amp = eta_cur / eta

    zeta = float("nan")
    gamma = float("nan")
    paths = theta_paths(rates)
    if paths:
        caps = []
        for path in paths:
            resistance = 0.0
            currents = []
            for i, j in zip(path[:-1], path[1:]):
                t = p[i] * rates[i, j] + p[j] * rates[j, i]
                cur = p[i] * rates[i, j] - p[j] * rates[j, i]
                resistance += 1.0 / t
                currents.append(cur)
            length = len(path) - 1
            gl = math.cos(math.pi / (2.0 * length)) / math.sin(math.pi / (2.0 * length)) / (2.0 * length)
            caps.append(abs(float(np.mean(currents))) * gl * resistance)
        gamma = max(caps)
        zeta = abs(bb) / (gamma * d) if gamma > 0.0 else float("nan")

    tid, tsig, edge_count, cycle_rank = topology_data(rates)
    return {
        "target_real": float(z.real), "target_imag": float(z.imag),
        "competitor_real": float(zc.real), "competitor_imag": float(zc.imag),
        "lambda_R": a, "lambda_I": b, "sigma": sigma, "Y": y,
        "g_vis": b - a, "g_lead": float(z.real - zc.real),
        "rv": (b - a) / a, "rg": float((z.real - zc.real) / a),
        "Nv": nv, "D": d, "B": bb, "C": c, "H": h, "G_Gu": g,
        "tau": tau, "kappa": kappa, "eta_cur": eta_cur, "eta": eta,
        "s_amp": s_amp, "kappa_Gu": kappa_gu, "s_Gu": s_gu,
        "factor_product": tau * kappa * eta_cur,
        "gu_slack_product": tau * kappa_gu * s_gu,
        "factor_residual": y - tau * kappa * eta_cur,
        "gu_ratio_residual": y / eta - tau * kappa_gu * s_gu,
        "energy_residual": a * nv - d / 2.0,
        "phase_residual": b * nv - bb,
        "Gamma_theta": gamma, "zeta_theta": zeta,
        "topology_id": tid, "topology_signature": tsig,
        "edge_count": edge_count, "cycle_rank": cycle_rank,
        "stationary_min": float(np.min(p)),
        "target_condition": eig_condition(q, z, v),
        "competitor_condition": eig_condition(q, zc, vecs[:, ci]),
        "competitor_conjugate_separation": 2.0 * abs(float(zc.imag)),
        "target_index": int(ti), "competitor_index": int(ci),
        "target_ref": z, "competitor_ref": zc,
    }


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = fields or list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def finite_gradients(rates: np.ndarray, base: dict) -> tuple[list[dict], dict[str, np.ndarray]]:
    edges = support_edges(rates)
    coords = [(i, j) for i, j in edges for i, j in ((i, j), (j, i))]
    logs = np.array([math.log(rates[i, j]) for i, j in coords])
    keys = ["log_tau", "log_kappa", "log_eta_cur", "log_Y", "g_lead", "g_vis", "eta_cur"]
    grads = {k: np.zeros(len(coords)) for k in keys}
    rows = []
    for k, (i, j) in enumerate(coords):
        values = []
        for sign in (-1.0, 1.0):
            x = logs.copy()
            x[k] += sign * EPS
            x -= x.mean() - logs.mean()
            rp = rates.copy()
            for val, (u, v) in zip(np.exp(x), coords):
                rp[u, v] = val
            values.append(calculate(rp, target_ref=base["target_ref"]))
        lo, hi = values
        data = {
            "coordinate": f"log_k_{i+1}_{j+1}",
            "from_state": i + 1,
            "to_state": j + 1,
        }
        for name, raw in (("log_tau", "tau"), ("log_kappa", "kappa"),
                          ("log_eta_cur", "eta_cur"), ("log_Y", "Y")):
            val = (math.log(hi[raw]) - math.log(lo[raw])) / (2.0 * EPS)
            grads[name][k] = val
            data[f"d_{name}"] = val
        for name in ("g_lead", "g_vis", "eta_cur"):
            val = (hi[name] - lo[name]) / (2.0 * EPS)
            grads[name][k] = val
            data[f"d_{name}"] = val
        rows.append(data)
    return rows, grads


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    den = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / den) if den else float("nan")


def nondominated(rows: list[dict], x: str, y: str) -> list[dict]:
    # Minimize x, maximize y.
    out = []
    for r in rows:
        if not (math.isfinite(r[x]) and math.isfinite(r[y])):
            continue
        dominated = any(
            q[x] <= r[x] and q[y] >= r[y] and (q[x] < r[x] or q[y] > r[y])
            for q in rows if math.isfinite(q[x]) and math.isfinite(q[y])
        )
        if not dominated:
            out.append(r)
    return sorted(out, key=lambda r: (r[y], -r[x]), reverse=True)


def local_samples(rates: np.ndarray, base: dict, grads: dict[str, np.ndarray]) -> tuple[list[dict], list[tuple[np.ndarray, dict]]]:
    edges = support_edges(rates)
    coords = [(i, j) for i, j in edges for i, j in ((i, j), (j, i))]
    x0 = np.array([math.log(rates[i, j]) for i, j in coords])
    gy = grads["log_Y"]
    gg = grads["g_lead"]
    e1 = -gy / np.linalg.norm(gy)
    tmp = gg - np.dot(gg, e1) * e1
    e2 = tmp / np.linalg.norm(tmp)
    rng = np.random.default_rng(20260718)
    vectors = [np.zeros_like(x0)]
    for a in np.linspace(-0.45, 0.45, 25):
        for b in np.linspace(-0.45, 0.45, 25):
            vectors.append(a * e1 + b * e2)
    for _ in range(5000):
        d = rng.normal(size=len(x0))
        d -= d.mean()
        d /= np.linalg.norm(d)
        vectors.append(rng.uniform(0.0, 0.75) * d)
    rows = []
    kept = []
    for sid, delta in enumerate(vectors):
        x = x0 + delta
        x -= x.mean() - x0.mean()
        rp = rates.copy()
        for val, (i, j) in zip(np.exp(x), coords):
            rp[i, j] = val
        m = calculate(rp, target_ref=base["target_ref"])
        if m is None:
            continue
        row = {k: v for k, v in m.items() if not isinstance(v, complex)}
        row.update({"sample_id": sid, "log_radius": float(np.linalg.norm(delta)), "source": "local_final_support"})
        rows.append(row)
        kept.append((rp, m))
    return rows, kept


def joint_direction_trace(rates: np.ndarray, base: dict, grads: dict[str, np.ndarray]) -> list[dict]:
    """Trace the first-order joint Y/leadership direction through the near-real cusp."""
    edges = support_edges(rates)
    coords = [(i, j) for i, j in edges for i, j in ((i, j), (j, i))]
    x0 = np.array([math.log(rates[i, j]) for i, j in coords])
    d = -grads["log_Y"] / np.linalg.norm(grads["log_Y"])
    d += grads["g_lead"] / np.linalg.norm(grads["g_lead"])
    d -= d.mean()
    d /= np.linalg.norm(d)
    ts = np.unique(np.concatenate((
        np.linspace(-2e-4, 2e-4, 81),
        np.linspace(2.5e-4, 3e-3, 12),
        np.array([0.01, 0.03, 0.1]),
    )))
    rows = []
    for t in ts:
        x = x0 + t * d
        x -= x.mean() - x0.mean()
        rp = rates.copy()
        for val, (i, j) in zip(np.exp(x), coords):
            rp[i, j] = val
        m = calculate(rp, target_ref=base["target_ref"])
        row = {k: v for k, v in m.items() if not isinstance(v, complex)}
        row["t"] = float(t)
        rows.append(row)
    return rows


def coordinate_scans(rates: np.ndarray, base: dict) -> tuple[list[dict], list[tuple[np.ndarray, dict]]]:
    """One-coordinate normalized log-rate scans on the fixed final support."""
    edges = support_edges(rates)
    coords = [(i, j) for i, j in edges for i, j in ((i, j), (j, i))]
    x0 = np.array([math.log(rates[i, j]) for i, j in coords])
    rows, pairs = [], []
    for k, (u, v) in enumerate(coords):
        for t in np.linspace(-0.6, 0.6, 241):
            x = x0.copy()
            x[k] += t
            x -= x.mean() - x0.mean()
            rp = rates.copy()
            for val, (i, j) in zip(np.exp(x), coords):
                rp[i, j] = val
            m = calculate(rp, target_ref=base["target_ref"])
            row = {kk: vv for kk, vv in m.items() if not isinstance(vv, complex)}
            row.update({"coordinate": f"log_k_{u+1}_{v+1}", "t": float(t)})
            rows.append(row)
            pairs.append((rp, m))
    return rows, pairs


def topology_perturbations(rates: np.ndarray, base: dict) -> list[dict]:
    # Prompt identifies the extra final-support chord as 3--9 (one-based).
    chord = (2, 8)
    fwd, rev = rates[chord], rates[chord[::-1]]
    stripped = rates.copy()
    stripped[chord] = stripped[chord[::-1]] = 0.0
    variants = [("delete_chord_3_9_pure_theta", stripped)]
    for i in range(len(rates)):
        for j in range(i + 1, len(rates)):
            if (i, j) == chord or stripped[i, j] > 0.0 or stripped[j, i] > 0.0:
                continue
            for flip in (False, True):
                r = stripped.copy()
                r[i, j], r[j, i] = (rev, fwd) if flip else (fwd, rev)
                variants.append((f"relocate_chord_to_{i+1}_{j+1}_{'flip' if flip else 'same'}", r))
    rows = []
    for name, r in variants:
        m = calculate(r, target_ref=base["target_ref"])
        if m:
            row = {k: v for k, v in m.items() if not isinstance(v, complex)}
            row["intervention"] = name
            rows.append(row)
    return rows


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    with SCAN.open(newline="", encoding="utf-8-sig") as f:
        scan_rows = [r for r in csv.DictReader(f) if r.get("n") == "11"]
    candidate_paths = []
    for path in (ROOT / "work").rglob("*.json"):
        if "theta_bridge" in path.parts:
            continue
        try:
            probe = json.loads(path.read_text(encoding="utf-8"))
            if probe.get("n") == 11 and rates_from_obj(probe) is not None:
                candidate_paths.append(path)
        except Exception:
            continue
    seen = set()
    all_rows = []
    failures = []
    for path in sorted(candidate_paths):
        rel = path.relative_to(ROOT).as_posix()
        if rel in seen:
            continue
        seen.add(rel)
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
            rates = rates_from_obj(obj)
            m = calculate(rates, reported=obj.get("metrics"))
            if m is None:
                raise ValueError("no reconstructible positive-stationary nonreal target")
            row = {k: v for k, v in m.items() if not isinstance(v, complex)}
            row.update({
                "file": rel,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "reported_Y": obj.get("metrics", {}).get("Y", ""),
                "reported_gap": obj.get("metrics", {}).get("gap", ""),
                "selection": "matched_reported_lambda_pair" if obj.get("metrics", {}).get("lambda_I") else "max_coherence_pair",
                "lineage": "sub12" if rel.startswith("work/sub12/") else ("small_witness" if rel.startswith("work/small_witness/") else "theta_synthesis_derived"),
            })
            all_rows.append(row)
        except Exception as exc:  # retain a machine-readable failure ledger
            failures.append({"file": rel, "error": repr(exc)})
    write_csv(OUT / "n11_all_candidates.csv", all_rows)
    write_csv(OUT / "n11_reconstruction_failures.csv", failures)

    visible = [r for r in all_rows if r["g_vis"] > 0.0]
    frontier_rows = []
    for label, x in (("Y_vs_relative_leading_gap", "Y"), ("eta_cur_vs_relative_leading_gap", "eta_cur")):
        for r in nondominated(visible, x, "rg"):
            q = dict(r)
            q["frontier"] = label
            frontier_rows.append(q)
    write_csv(OUT / "OBS_n11_localization_leadership_frontier.csv", frontier_rows)

    by_top = {}
    for r in visible:
        by_top.setdefault(r["topology_id"], []).append(r)
    top_rows = []
    for tid, rr in by_top.items():
        leading = [r for r in rr if r["g_lead"] > 0.0]
        violating = [r for r in rr if r["Y"] < 1.0]
        both = [r for r in leading if r["Y"] < 1.0]
        best_lead = min(leading, key=lambda r: r["Y"]) if leading else None
        best_viol = max(violating, key=lambda r: r["rg"]) if violating else None
        top_rows.append({
            "topology_id": tid, "topology_signature": rr[0]["topology_signature"],
            "edge_count": rr[0]["edge_count"], "cycle_rank": rr[0]["cycle_rank"],
            "saved_visible_count": len(rr), "saved_leading_count": len(leading),
            "saved_violating_count": len(violating), "saved_valid_violation_count": len(both),
            "best_leading_Y": best_lead["Y"] if best_lead else "",
            "best_leading_file": best_lead["file"] if best_lead else "",
            "best_violating_rg": best_viol["rg"] if best_viol else "",
            "best_violating_Y": best_viol["Y"] if best_viol else "",
            "best_violating_file": best_viol["file"] if best_viol else "",
        })
    write_csv(OUT / "OBS_n11_topology_frontier_comparison.csv", sorted(top_rows, key=lambda r: r["saved_visible_count"], reverse=True))

    final_obj = json.loads(FINAL.read_text(encoding="utf-8"))
    final_rates = np.asarray(final_obj["rates"], dtype=float)
    final_base = calculate(final_rates, reported=final_obj["metrics"])
    grad_rows, grads = finite_gradients(final_rates, final_base)
    write_csv(OUT / "OBS_n11_gradient_conflict.csv", grad_rows)
    grad_summary = {
        "cosine_improve_Y_vs_improve_leadership": cosine(-grads["log_Y"], grads["g_lead"]),
        "cosine_improve_eta_cur_vs_improve_leadership": cosine(-grads["log_eta_cur"], grads["g_lead"]),
        "cosine_improve_tau_vs_improve_leadership": cosine(-grads["log_tau"], grads["g_lead"]),
        "cosine_improve_kappa_vs_improve_leadership": cosine(-grads["log_kappa"], grads["g_lead"]),
        "factor_gradient_closure_norm": float(np.linalg.norm(grads["log_Y"] - grads["log_tau"] - grads["log_kappa"] - grads["log_eta_cur"])),
    }
    collision_trace = joint_direction_trace(final_rates, final_base, grads)
    write_csv(OUT / "OBS_n11_near_real_collision_trace.csv", collision_trace)

    samples, sample_pairs = local_samples(final_rates, final_base, grads)
    axis_rows, axis_pairs = coordinate_scans(final_rates, final_base)
    axis_front = nondominated([r for r in axis_rows if r["g_vis"] > 0.0], "Y", "g_lead")
    write_csv(OUT / "OBS_n11_coordinate_scan_frontier.csv", axis_front)
    combined_samples = samples + [{**r, "source": "coordinate_scan", "sample_id": r["coordinate"] + ":" + str(r["t"]), "log_radius": abs(r["t"])} for r in axis_rows]
    local_front = nondominated([r for r in combined_samples if r["g_vis"] > 0.0], "Y", "g_lead")
    write_csv(OUT / "OBS_n11_local_fixed_support_pareto.csv", local_front)
    constrained = []
    vis_samples = [r for r in combined_samples if r["g_vis"] > 0.0]
    for gamma in (-0.02, -0.01, -0.005, -0.001, 0.0, 1e-4, 5e-4, 1e-3, 5e-3, 1e-2):
        feasible = [r for r in vis_samples if r["g_lead"] >= gamma]
        if feasible:
            best = min(feasible, key=lambda r: r["eta_cur"])
            constrained.append({"problem": "min_eta_cur_given_gap", "threshold": gamma, **best})
    for y0 in (0.95, 0.98, 0.99, 1.0, 1.005, 1.01, 1.015, 1.02, 1.025, 1.05):
        feasible = [r for r in vis_samples if r["Y"] <= y0]
        if feasible:
            best = max(feasible, key=lambda r: r["g_lead"])
            constrained.append({"problem": "max_gap_given_Y", "threshold": y0, **best})
    write_csv(OUT / "OBS_n11_constrained_frontier.csv", constrained)

    successes = [(r, m) for r, m in sample_pairs + axis_pairs if m["Y"] < 1.0 and m["g_vis"] > 0.0 and m["g_lead"] > 0.0]
    local_success = None
    if successes:
        rp, mm = max(successes, key=lambda x: x[1]["g_lead"])
        local_success = {k: v for k, v in mm.items() if not isinstance(v, complex)}
        local_success["rates"] = rp.tolist()
        (OUT / "n11_local_success_candidate.json").write_text(
            json.dumps(local_success, indent=2, allow_nan=True, default=lambda o: o.item() if isinstance(o, np.generic) else str(o)),
            encoding="utf-8",
        )

    perturb = topology_perturbations(final_rates, final_base)
    write_csv(OUT / "OBS_n11_topology_perturbations.csv", perturb)

    merge_obj = json.loads(MERGE34.read_text(encoding="utf-8"))
    merge = calculate(np.asarray(merge_obj["rates"], dtype=float), reported=merge_obj["metrics"])
    summary = {
        "saved_n11_rows_in_sub12_campaign": len(scan_rows),
        "saved_n11_paths_discovered": len(candidate_paths),
        "unique_saved_n11_reconstructed": len(all_rows),
        "unique_rate_matrices": len({
            hashlib.sha256(rates_from_obj(json.loads((ROOT / r["file"]).read_text(encoding="utf-8"))).astype(np.float64).tobytes()).hexdigest()
            for r in all_rows
        }),
        "reconstruction_failures": len(failures),
        "saved_visible_targets": len(visible),
        "saved_valid_violations": sum(r["Y"] < 1.0 and r["g_vis"] > 0.0 and r["g_lead"] > 0.0 for r in all_rows),
        "saved_topologies_with_visible_targets": len(by_top),
        "final": {k: v for k, v in final_base.items() if not isinstance(v, complex)},
        "merge_3_4": {k: v for k, v in merge.items() if not isinstance(v, complex)},
        "gradient_summary": grad_summary,
        "joint_direction_min_competitor_imag": min(abs(r["competitor_imag"]) for r in collision_trace),
        "joint_direction_max_competitor_condition": max(r["competitor_condition"] for r in collision_trace),
        "local_samples": len(samples),
        "coordinate_scan_samples": len(axis_rows),
        "local_valid_violations": len(successes),
        "local_success": local_success,
        "topology_perturbations": len(perturb),
        "topology_perturbation_valid_violations": sum(r["Y"] < 1.0 and r["g_vis"] > 0.0 and r["g_lead"] > 0.0 for r in perturb),
        "scope_warning": "All frontier and topology conclusions are empirical/local; none excludes the topology or all n=11 chains.",
    }
    (OUT / "n11_frontier_summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=True, default=lambda o: o.item() if isinstance(o, np.generic) else str(o)),
        encoding="utf-8",
    )
    print(json.dumps({k: summary[k] for k in (
        "unique_saved_n11_reconstructed", "reconstruction_failures", "saved_visible_targets",
        "saved_valid_violations", "local_valid_violations", "topology_perturbation_valid_violations")},
        indent=2, default=lambda o: o.item() if isinstance(o, np.generic) else str(o)))


if __name__ == "__main__":
    main()
