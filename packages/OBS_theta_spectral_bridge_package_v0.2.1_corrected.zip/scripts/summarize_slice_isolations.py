"""Create a compact decimal and inequality summary of certified root boxes."""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp


ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "work/theta_bridge/circulation/circulation_slice_isolations.json"
OUT = ROOT / "work/theta_bridge/circulation/circulation_slice_summary.json"


def f(value: sp.Expr) -> float:
    return float(sp.N(value, 18))


def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    summary = {}
    for label, record in data["slices"].items():
        roots = []
        for item in record["real_intervals"]:
            lo, hi = (sp.Rational(x) for x in item["interval"])
            roots.append({
                "kind": "real",
                "re_lo": f(lo), "re_hi": f(hi),
                "im_lo": 0.0, "im_hi": 0.0,
            })
        for item in record["complex_rectangles"]:
            corners = [sp.sympify(x, locals={"I": sp.I}) for x in item["rectangle_corners"]]
            re_values = [sp.re(x) for x in corners]
            im_values = [sp.im(x) for x in corners]
            roots.append({
                "kind": "complex",
                "re_lo": f(min(re_values)), "re_hi": f(max(re_values)),
                "im_lo": f(min(im_values)), "im_hi": f(max(im_values)),
            })
        roots.sort(key=lambda x: (x["re_hi"], x["im_hi"]), reverse=True)
        # Target is the positive-imaginary root nearest the diagonal at about
        # 5.8e3.  This explicit range avoids silently relabeling another pair.
        targets = [x for x in roots
                   if 5500 < x["im_lo"] and x["im_hi"] < 6500
                   and -7000 < x["re_lo"] and x["re_hi"] < -5000]
        if len(targets) != 1:
            raise RuntimeError(f"{label}: target range selected {len(targets)} roots")
        target = targets[0]
        others = [x for x in roots if x is not target and x["im_hi"] >= 0]
        nearest_competitor = max(others, key=lambda x: x["re_hi"])
        summary[label] = {
            "epsilon": record["epsilon"],
            "root_count": len(roots),
            "roots_by_real_part_descending": roots,
            "target_positive_imag": target,
            "nearest_nonconjugate_competitor": nearest_competitor,
            "certified_target_leads": target["re_lo"] > nearest_competitor["re_hi"],
            "certified_target_trails": target["re_hi"] < nearest_competitor["re_lo"],
            "certified_visible": target["im_lo"] > -target["re_lo"],
            "certified_not_visible": target["im_hi"] < -target["re_hi"],
        }
    OUT.write_text(json.dumps({
        "source": str(SOURCE.relative_to(ROOT)),
        "warning": "Decimals summarize exact rational boxes in the source file.",
        "slices": summary,
    }, indent=2), encoding="utf-8")
    for label, item in summary.items():
        print(label, {
            "leads": item["certified_target_leads"],
            "trails": item["certified_target_trails"],
            "visible": item["certified_visible"],
            "not_visible": item["certified_not_visible"],
            "target": item["target_positive_imag"],
            "competitor": item["nearest_nonconjugate_competitor"],
        })


if __name__ == "__main__":
    main()
