"""Build the exact characteristic polynomial for the circulation homotopy.

The input stationary law, path traffics, and currents are exact rationals.  The
homotopy holds every traffic fixed and multiplies each path current by eps.
Because Q(-eps) is the pi-adjoint of Q(eps), the characteristic polynomial is
an even polynomial in eps; the emitted representation therefore uses s=eps^2.
"""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp


ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "work/theta_synthesis/family/family_exact_baseline.json"
OUT_JSON = ROOT / "work/theta_bridge/circulation/circulation_charpoly_exact.json"
OUT_TXT = ROOT / "work/theta_bridge/circulation/circulation_charpoly_exact.txt"


def rat(value: str) -> sp.Rational:
    return sp.Rational(value)


def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    pi = [rat(x) for x in data["stationary_distribution"]]
    paths = [[v - 1 for v in path] for path in data["paths_1_based"]]
    currents = [rat(x) for x in data["path_currents"]]
    traffics = [[rat(x) for x in path] for path in data["path_traffics"]]
    n = len(pi)
    eps, z, s = sp.symbols("eps z s")

    # Q uses the row-generator convention.  Its transpose has the same
    # characteristic polynomial, so the convention does not affect P.
    q = sp.zeros(n)
    for path, current, path_traffic in zip(paths, currents, traffics):
        for (u, v), traffic in zip(zip(path[:-1], path[1:]), path_traffic):
            f_uv = (traffic + eps * current) / 2
            f_vu = (traffic - eps * current) / 2
            q[u, v] = f_uv / pi[u]
            q[v, u] = f_vu / pi[v]
    for u in range(n):
        q[u, u] = -sum(q[u, v] for v in range(n) if v != u)

    p_eps = sp.Poly(q.charpoly(z).as_expr(), z, eps, domain=sp.QQ)
    odd_terms = [(monom, coeff) for monom, coeff in p_eps.terms() if monom[1] % 2]
    if odd_terms:
        raise RuntimeError(f"expected an even polynomial in eps, found {len(odd_terms)} odd terms")

    expr_s = sum(coeff * z ** monom[0] * s ** (monom[1] // 2)
                 for monom, coeff in p_eps.terms())
    p = sp.Poly(expr_s, z, s, domain=sp.QQ)
    # Remove the known stationary factor z and keep the nonzero secular factor.
    secular = sp.Poly(sp.cancel(p.as_expr() / z), z, s, domain=sp.QQ)

    # Regard the polynomial as univariate in z so that the extracted
    # coefficients retain their full s-dependence.  coeff_monomial on the
    # original bivariate Poly would otherwise select only the s^0 term.
    secular_in_z = sp.Poly(secular.as_expr(), z, domain=sp.QQ.frac_field(s))
    records = []
    for z_power in range(secular.degree(z), -1, -1):
        coeff = sp.Poly(secular_in_z.coeff_monomial(z ** z_power), s, domain=sp.QQ)
        records.append({
            "z_power": z_power,
            "coefficient_in_s": str(coeff.as_expr()),
        })

    payload = {
        "source": str(SOURCE.relative_to(ROOT)),
        "definition": "P_nonzero(z,s)=det(z I-Q(eps))/z with s=eps^2",
        "row_generator": True,
        "n_states": n,
        "degree_z": secular.degree(z),
        "degree_s": secular.degree(s),
        "even_in_eps_verified": True,
        "stationary_factor_z_verified": sp.rem(p, sp.Poly(z, z, s)) == 0,
        "coefficients": records,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "Exact nonzero secular polynomial for Q(eps), s=eps^2\n"
        f"degree_z={secular.degree(z)}, degree_s={secular.degree(s)}\n\n"
        + str(secular.as_expr()) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "degree_z": secular.degree(z),
        "degree_s": secular.degree(s),
        "terms": len(secular.terms()),
        "json": str(OUT_JSON),
    }))


if __name__ == "__main__":
    main()
