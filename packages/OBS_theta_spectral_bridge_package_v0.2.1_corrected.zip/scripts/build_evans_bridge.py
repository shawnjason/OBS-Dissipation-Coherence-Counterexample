"""Exact Evans/admittance audit for the OBS n12 and valid n11 systems.

Outputs use the row/backward generator Q and M(z)=zI-Q.  The canonical Evans
function is det(S)=chi(z)/d_I(z), with both polynomials monic and coprime.
"""

from __future__ import annotations

import csv
import hashlib
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

import mpmath as mp
import sympy as sp


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
N12 = ROOT / "work/sub12/spectral_repair/checkpoints/n12_e13_delete45_delete68_integer.json"
N11 = ROOT / "work/sub12/near11/FINAL_proj_best_t1e5.json"
z = sp.Symbol("z")
eps = sp.Symbol("epsilon")

SYSTEMS = {
    "n12": {
        "source": N12,
        "boundary": [1, 8],
        "components": [
            ("short_P1", [2, 3], [1, 2, 3, 8]),
            ("long_P2", [4, 5, 6, 7], [1, 4, 5, 6, 7, 8]),
            ("spacer_P3", [0, 10, 11, 9], [1, 0, 10, 11, 9, 8]),
        ],
    },
    "n11": {
        "source": N11,
        "boundary": [1, 8],
        "components": [
            ("short_plus_chord", [2, 3], [1, 2, 3, 8]),
            ("long_P2", [4, 5, 6, 7], [1, 4, 5, 6, 7, 8]),
            ("contracted_P3", [0, 10, 9], [1, 0, 10, 9, 8]),
        ],
    },
}


def load_rates(name: str) -> list[list[F]]:
    path = SYSTEMS[name]["source"]
    raw = json.loads(path.read_text(encoding="utf-8"), parse_float=str, parse_int=str)
    if "integer_rate_numerators" in raw:
        den = F(raw.get("denominator", "1"))
        return [[F(x) / den for x in row] for row in raw["integer_rate_numerators"]]
    return [[F(x) for x in row] for row in raw["rates"]]


def sr(x: F | int) -> sp.Rational:
    x = F(x)
    return sp.Rational(x.numerator, x.denominator)


def generator(k: list[list[F]]) -> sp.Matrix:
    n = len(k)
    Q = sp.zeros(n)
    for i in range(n):
        for j in range(n):
            if i != j:
                Q[i, j] = sr(k[i][j])
        Q[i, i] = -sum(Q[i, j] for j in range(n) if j != i)
    return Q


def stationary(k: list[list[F]]) -> list[F]:
    Q = generator(k)
    n = Q.rows
    A = Q.T
    A[n - 1, :] = sp.ones(1, n)
    rhs = sp.zeros(n, 1)
    rhs[n - 1] = 1
    sol = A.inv() * rhs
    return [F(int(sp.numer(x)), int(sp.denom(x))) for x in sol]


def poly_record(p: sp.Poly) -> dict[str, object]:
    return {"degree": p.degree(), "coefficients_descending": [str(x) for x in p.all_coeffs()]}


def rat_record(x: sp.Expr) -> dict[str, object]:
    a, b = sp.fraction(sp.cancel(x))
    return {"numerator": poly_record(sp.Poly(a, z)), "denominator": poly_record(sp.Poly(b, z))}


def component_admittance(Q: sp.Matrix, boundary: list[int], internal: list[int]):
    M = z * sp.eye(Q.rows) - Q
    D = M.extract(internal, internal)
    C = M.extract(boundary, internal)
    E = M.extract(internal, boundary)
    # Boundary diagonal contribution from edges entering this internal component.
    H = sp.zeros(2)
    for a, bnode in enumerate(boundary):
        H[a, a] = sum(Q[bnode, j] for j in internal)
    d = sp.Poly(sp.expand(D.det()), z)
    numer = (H * d.as_expr() - C * D.adjugate() * E).applyfunc(sp.expand)
    A = (H - C * D.inv() * E).applyfunc(sp.cancel)
    return A, numer, d, D


def system_evans(name: str):
    k = load_rates(name)
    Q = generator(k)
    boundary = SYSTEMS[name]["boundary"]
    components = []
    S = z * sp.eye(2)
    for cname, internal, path in SYSTEMS[name]["components"]:
        A, N, d, D = component_admittance(Q, boundary, internal)
        S += A
        components.append({"name": cname, "internal": internal, "path": path, "A": A, "N": N, "d": d, "D": D})
    S = S.applyfunc(sp.cancel)
    M = z * sp.eye(Q.rows) - Q
    chi = sp.Poly(M.det(method="domain-ge"), z)
    dprod = sp.Poly(sp.prod(c["d"].as_expr() for c in components), z)
    assert sp.gcd(chi, dprod).degree() == 0
    assert sp.gcd(chi, chi.diff()).degree() == 0
    assert sp.cancel(S.det() - chi.as_expr() / dprod.as_expr()) == 0
    return k, Q, S, chi, dprod, components


def mpval(expr: sp.Expr, zz: mp.mpc, digits: int = 100) -> mp.mpc:
    s = sp.N(expr.subs(z, sp.Float(mp.nstr(mp.re(zz), digits), digits)
                            + sp.I * sp.Float(mp.nstr(mp.im(zz), digits), digits)), digits)
    return mp.mpc(mp.mpf(str(sp.re(s))), mp.mpf(str(sp.im(s))))


def eigs(Q: sp.Matrix, dps: int = 100):
    mp.mp.dps = dps
    A = mp.matrix([[mp.mpf(str(Q[i, j])) for j in range(Q.cols)] for i in range(Q.rows)])
    vals = [mp.mpc(x) for x in mp.eig(A, left=False, right=False)]
    vals.sort(key=lambda w: (float(mp.re(w)), float(mp.im(w))))
    return vals


def select_roots(name: str, vals: list[mp.mpc]):
    if name == "n12":
        rt, rc = mp.mpc(-5769.66, 5818.68), mp.mpc(-5811.39, 60.22)
    else:
        rt, rc = mp.mpc(-3.96243, 3.97284), mp.mpc(-3.96284, .02024)
    return min(vals, key=lambda x: abs(x - rt)), min(vals, key=lambda x: abs(x - rc))


def boundary_residue(S: sp.Matrix, chi: sp.Poly, dprod: sp.Poly, root: mp.mpc):
    sm = [[mpval(S[i, j], root) for j in range(2)] for i in range(2)]
    ep = mpval(chi.diff().as_expr(), root) / mpval(dprod.as_expr(), root)
    adj = [[sm[1][1], -sm[0][1]], [-sm[1][0], sm[0][0]]]
    R = [[adj[i][j] / ep for j in range(2)] for i in range(2)]
    return ep, R


def faddeev_derivative(Q: sp.Matrix, dQ: sp.Matrix) -> sp.Poly:
    """Exact derivative of det(zI-Q(t)) for Q(t)=Q+t dQ at t=0."""
    n = Q.rows
    B, dB = sp.eye(n), sp.zeros(n)
    deriv = [sp.Integer(0)]
    for order in range(1, n + 1):
        C = Q * B
        dC = dQ * B + Q * dB
        c = -sp.trace(C) / order
        dc = -sp.trace(dC) / order
        deriv.append(sp.cancel(dc))
        B = C + c * sp.eye(n)
        dB = dC + dc * sp.eye(n)
    return sp.Poly(sum(deriv[i] * z ** (n - i) for i in range(n + 1)), z)


def stationary_flux_directions(k: list[list[F]]):
    """Five exact alpha/beta tangent matrices for the n12 family."""
    pi = stationary(k)
    paths = [c[2] for c in SYSTEMS["n12"]["components"]]
    pdata = []
    for path in paths:
        edges, currents = [], []
        for i, j in zip(path[:-1], path[1:]):
            fij, fji = pi[i] * k[i][j], pi[j] * k[j][i]
            edges.append((i, j, fij + fji))
            currents.append(fij - fji)
        assert len(set(currents)) == 1
        pdata.append((edges, currents[0]))
    mats = []
    for r in range(3):
        dk = [[F(0) for _ in k] for _ in k]
        for i, j, T in pdata[r][0]:
            dk[i][j] = T / (2 * pi[i])
            dk[j][i] = T / (2 * pi[j])
        mats.append((f"alpha_{r+1}_traffic", generator(dk)))
    for bidx in range(2):
        dk = [[F(0) for _ in k] for _ in k]
        baseJ = pdata[bidx][1]
        affected = [(bidx, baseJ), (2, -baseJ)]
        for r, dJ in affected:
            for i, j, _ in pdata[r][0]:
                dk[i][j] += dJ / (2 * pi[i])
                dk[j][i] -= dJ / (2 * pi[j])
        mats.append((f"beta_{bidx+1}_current", generator(dk)))
    mats.append(("epsilon_all_currents", mats[3][1] + mats[4][1]))
    return mats


def n11_scale_directions(k: list[list[F]]):
    groups = [
        ("scale_short_path", [(1, 2), (2, 3), (3, 8)]),
        ("scale_long_path", [(1, 4), (4, 5), (5, 6), (6, 7), (7, 8)]),
        ("scale_contracted_path", [(1, 0), (0, 10), (10, 9), (9, 8)]),
        ("scale_chord_3_9", [(2, 8)]),
    ]
    out = []
    for name, edges in groups:
        dk = [[F(0) for _ in k] for _ in k]
        for i, j in edges:
            dk[i][j], dk[j][i] = k[i][j], k[j][i]
        out.append((name, generator(dk)))
    pi = stationary(k)
    dc = [[F(0) for _ in k] for _ in k]
    for i in range(len(k)):
        for j in range(len(k)):
            if i != j and k[i][j]:
                J = pi[i] * k[i][j] - pi[j] * k[j][i]
                dc[i][j] = J / (2 * pi[i])
    out.append(("epsilon_all_currents", generator(dc)))
    return out


def root_derivatives(name: str, Q: sp.Matrix, chi: sp.Poly, rot: mp.mpc, rel: mp.mpc, k):
    dirs = stationary_flux_directions(k) if name == "n12" else n11_scale_directions(k)
    rows, exact = [], {}
    for pname, dQ in dirs:
        pt = faddeev_derivative(Q, dQ)
        exact[pname] = poly_record(pt)
        dr = -mpval(pt.as_expr(), rot) / mpval(chi.diff().as_expr(), rot)
        dc = -mpval(pt.as_expr(), rel) / mpval(chi.diff().as_expr(), rel)
        rows.append({
            "system": name, "parameter": pname,
            "dz_rot_real": mp.nstr(mp.re(dr), 45), "dz_rot_imag": mp.nstr(mp.im(dr), 45),
            "dz_rel_real": mp.nstr(mp.re(dc), 45), "dz_rel_imag": mp.nstr(mp.im(dc), 45),
            "d_order_gap": mp.nstr(mp.re(dr - dc), 45),
            "single_direction_linear_crossing_delta": mp.nstr(-mp.re(rot - rel) / mp.re(dr - dc), 35)
                if abs(mp.re(dr - dc)) > mp.mpf("1e-70") else "",
        })
    return rows, exact


def circulation_polynomial(k: list[list[F]]):
    pi = stationary(k)
    n = len(k)
    qeps = sp.zeros(n)
    for i in range(n):
        for j in range(n):
            if i != j and k[i][j]:
                fij, fji = pi[i] * k[i][j], pi[j] * k[j][i]
                T, J = fij + fji, fij - fji
                qeps[i, j] = sr(T / (2 * pi[i])) + eps * sr(J / (2 * pi[i]))
        qeps[i, i] = -sum(qeps[i, j] for j in range(n) if j != i)
    p = sp.Poly(qeps.charpoly(z).as_expr(), z, eps)
    return qeps, p


def exceptional_point(p: sp.Poly, z0: str, e0: str):
    mp.mp.dps = 90
    expr = p.as_expr()
    pz, pe, pzz = sp.diff(expr, z), sp.diff(expr, eps), sp.diff(expr, z, 2)
    f = sp.lambdify((z, eps), expr, "mpmath")
    fz = sp.lambdify((z, eps), pz, "mpmath")
    zz, ee = mp.findroot((f, fz), (mp.mpf(z0), mp.mpf(e0)), tol=mp.mpf("1e-75"), maxsteps=100)
    fe = sp.lambdify((z, eps), pe, "mpmath")(zz, ee)
    fzz = sp.lambdify((z, eps), pzz, "mpmath")(zz, ee)
    c = -2 * fe / fzz
    return {
        "z_EP": mp.nstr(zz, 70), "epsilon_EP": mp.nstr(ee, 70),
        "P_epsilon": mp.nstr(fe, 35), "P_zz": mp.nstr(fzz, 35),
        "square_root_coefficient_c=-2Pepsilon/Pzz": mp.nstr(c, 50),
        "complex_for_epsilon_above": bool(c < 0),
        "predicted_imag_at_epsilon_1_leading_order": mp.nstr(mp.sqrt(-c * (1 - ee)), 40),
    }


def exact_real_root_count_bracket(name: str, p: sp.Poly):
    endpoints = ([sp.Rational(999541, 1000000), sp.Rational(9995411, 10000000)]
                 if name == "n12" else
                 [sp.Rational(999899, 1000000), sp.Rational(9998991, 10000000)])
    rows = []
    for e in endpoints:
        q = sp.Poly(p.as_expr().subs(eps, e), z)
        rows.append({"epsilon": str(e), "exact_distinct_real_root_count": int(q.count_roots(-sp.oo, sp.oo)),
                     "square_free_at_endpoint": sp.gcd(q, q.diff()).degree() == 0})
    assert rows[0]["exact_distinct_real_root_count"] - rows[1]["exact_distinct_real_root_count"] == 2
    return {"endpoints": rows,
            "proved_conclusion": "At least one real-pair to conjugate-pair collision occurs inside the rational epsilon interval."}


def leadership_event(name: str, qeps: sp.Matrix, epdata: dict[str, object]):
    """High-precision bisection of target-real-part versus split real branch."""
    mp.mp.dps = 75
    ec = mp.mpf(epdata["epsilon_EP"])
    zep = mp.mpf(epdata["z_EP"])

    def objects(e):
        Qe = qeps.subs(eps, sp.Float(mp.nstr(e, 75), 80))
        vals = eigs(Qe, 75)
        if name == "n12":
            rot = min(vals, key=lambda x: abs(x - mp.mpc(-5769, 5815)))
        else:
            rot = min(vals, key=lambda x: abs(x - mp.mpc(-3.962, 3.97)))
        real = [x for x in vals if abs(mp.im(x)) < mp.mpf("1e-55") and abs(x) > mp.mpf("1e-40")]
        right = max(real, key=lambda x: mp.re(x))
        return rot, right, mp.re(rot) - mp.re(right)

    lo = mp.mpf("0.9990") if name == "n12" else mp.mpf("0.9995")
    hi = ec - mp.mpf("1e-16")
    assert objects(lo)[2] < 0 and objects(hi)[2] > 0
    for _ in range(90):
        mid = (lo + hi) / 2
        if objects(mid)[2] > 0:
            hi = mid
        else:
            lo = mid
    ee = (lo + hi) / 2
    rot, right, gap = objects(ee)
    # Leading square-root estimate: target-to-EP separation squared divided by
    # the exceptional coefficient.  The centerline drift is higher order here.
    Qc = qeps.subs(eps, sp.Float(mp.nstr(ec, 75), 80))
    valsc = eigs(Qc, 75)
    target_c = min(valsc, key=lambda x: abs(x - (mp.mpc(-5769, 5815) if name == "n12" else mp.mpc(-3.962, 3.97))))
    A = -mp.mpf(epdata["square_root_coefficient_c=-2Pepsilon/Pzz"])
    h = mp.re(target_c) - zep
    estimate = ec - h * h / A
    return {
        "epsilon_ordering_crossing": mp.nstr(ee, 60),
        "target_at_crossing": [mp.nstr(mp.re(rot), 45), mp.nstr(mp.im(rot), 45)],
        "split_real_competitor_at_crossing": mp.nstr(mp.re(right), 45),
        "exceptional_minus_ordering_epsilon": mp.nstr(ec - ee, 40),
        "target_minus_EP_centerline_at_EP": mp.nstr(h, 40),
        "leading_square_root_crossing_estimate": mp.nstr(estimate, 45),
    }


def circulation_locus(name: str, qeps: sp.Matrix):
    rows = []
    for e in [sp.Rational(i, 1000) for i in range(0, 1001, 25)] + [sp.Rational(9995, 10000), sp.Rational(9999, 10000), sp.Rational(1)]:
        Qe = qeps.subs(eps, e)
        vals = eigs(Qe, 60)
        rot, rel = select_roots(name, vals) if e == 1 else (None, None)
        # Report the two rightmost upper-half pairs; branch labels at intermediate
        # points are intentionally not assigned by per-step sorting.
        upp = sorted([x for x in vals if mp.im(x) > mp.mpf("1e-30")], key=lambda x: mp.re(x), reverse=True)
        rows.append({
            "system": name, "epsilon": str(e),
            "rightmost_upper_1": "" if not upp else f"{mp.nstr(mp.re(upp[0]),25)}+{mp.nstr(mp.im(upp[0]),25)}i",
            "rightmost_upper_2": "" if len(upp) < 2 else f"{mp.nstr(mp.re(upp[1]),25)}+{mp.nstr(mp.im(upp[1]),25)}i",
        })
    return rows


def gamma_zeta_n12(k: list[list[F]], rot: mp.mpc, rel: mp.mpc):
    mp.mp.dps = 80
    pi = stationary(k)
    recs = []
    for _, _, path in SYSTEMS["n12"]["components"]:
        Ts, Js = [], []
        for i, j in zip(path[:-1], path[1:]):
            fij = mp.mpf(pi[i].numerator) / pi[i].denominator * (mp.mpf(k[i][j].numerator) / k[i][j].denominator)
            fji = mp.mpf(pi[j].numerator) / pi[j].denominator * (mp.mpf(k[j][i].numerator) / k[j][i].denominator)
            Ts.append(fij + fji); Js.append(fij - fji)
        L = len(path) - 1
        gL = mp.cot(mp.pi / (2 * L)) / (2 * L)
        R = sum(1 / t for t in Ts)
        cap = abs(Js[0]) * gL * R
        recs.append({"path": [i + 1 for i in path], "L": L, "J": mp.nstr(Js[0], 35),
                     "R": mp.nstr(R, 35), "gL": mp.nstr(gL, 35), "capacity": mp.nstr(cap, 35)})
    Gamma = max(mp.mpf(r["capacity"]) for r in recs)
    def zet(w): return abs(mp.im(w)) / (2 * (-mp.re(w)) * Gamma)
    return {"path_capacities": recs, "Gamma": mp.nstr(Gamma, 40),
            "zeta_rot_exact_spectral_identity": mp.nstr(zet(rot), 40),
            "zeta_rel_exact_spectral_identity": mp.nstr(zet(rel), 40),
            "ratio_rot_to_rel": mp.nstr(zet(rot) / zet(rel), 40)}


def main():
    exact_out = {"schema": "obs-theta-canonical-evans-v1", "systems": {}}
    pole_rows, deriv_rows, surface_rows, locus_rows = [], [], [], []
    for name in ("n12", "n11"):
        k, Q, S, chi, dprod, comps = system_evans(name)
        vals = eigs(Q)
        rot, rel = select_roots(name, vals)
        ep_rot, br_rot = boundary_residue(S, chi, dprod, rot)
        ep_rel, br_rel = boundary_residue(S, chi, dprod, rel)
        drows, dpolys = root_derivatives(name, Q, chi, rot, rel, k)
        deriv_rows.extend(drows)
        gap0 = mp.re(rot - rel)
        surface_basis = ([r for r in drows if r["parameter"] != "epsilon_all_currents"]
                         if name == "n12" else drows)
        surface_rows.append({"system": name, "gap_at_center": mp.nstr(gap0, 50),
                             "linear_surface": mp.nstr(gap0, 20) + " + " + " + ".join(
                                 f"({r['d_order_gap']})*d_{r['parameter']}" for r in surface_basis) + " = 0"})

        comp_out = []
        for comp in comps:
            roots = [mp.mpc(str(r)) for r in sp.nroots(comp["d"], n=75, maxsteps=200)]
            roots.sort(key=lambda x: mp.re(x))
            dp = comp["d"].diff().as_expr()
            for q, pole in enumerate(roots):
                residues = [[mpval(comp["N"][i, j], pole) / mpval(dp, pole) for j in range(2)] for i in range(2)]
                pole_rows.append({
                    "system": name, "component": comp["name"], "pole_index": q,
                    "pole_real": mp.nstr(mp.re(pole), 50),
                    "distance_to_rot": mp.nstr(abs(pole - rot), 40),
                    "distance_to_rel": mp.nstr(abs(pole - rel), 40),
                    "res11": mp.nstr(residues[0][0], 35), "res12": mp.nstr(residues[0][1], 35),
                    "res21": mp.nstr(residues[1][0], 35), "res22": mp.nstr(residues[1][1], 35),
                    "residue_det": mp.nstr(residues[0][0]*residues[1][1]-residues[0][1]*residues[1][0], 20),
                })
            comp_out.append({
                "name": comp["name"], "internal_1based": [i + 1 for i in comp["internal"]],
                "nominal_path_1based": [i + 1 for i in comp["path"]],
                "dirichlet_polynomial": poly_record(comp["d"]),
                "admittance_entries": [[rat_record(comp["A"][i, j]) for j in range(2)] for i in range(2)],
            })

        qeps, bp = circulation_polynomial(k)
        ep_guess = ("-5811", ".99955") if name == "n12" else ("-3.963", ".9999")
        epdata = exceptional_point(bp, *ep_guess)
        epbracket = exact_real_root_count_bracket(name, bp)
        ordering_event = leadership_event(name, qeps, epdata)
        locus_rows.extend(circulation_locus(name, qeps))
        exact_out["systems"][name] = {
            "source": str(SYSTEMS[name]["source"].relative_to(ROOT)).replace("\\", "/"),
            "source_sha256": hashlib.sha256(SYSTEMS[name]["source"].read_bytes()).hexdigest().upper(),
            "boundary_1based": [i + 1 for i in SYSTEMS[name]["boundary"]],
            "canonical_evans": {"definition": "det S(z)=chi(z)/d_I(z), chi and d_I monic and coprime",
                                 "chi": poly_record(chi), "d_I": poly_record(dprod),
                                 "gcd": str(sp.gcd(chi, dprod).as_expr()),
                                 "lowest_terms_numerator_degree": chi.degree(),
                                 "lowest_terms_denominator_degree": dprod.degree()},
            "components": comp_out,
            "root_labels": {
                "definition": "unique analytic continuation from the displayed simple center root inside a disjoint Riesz contour; boundary-resolvent residue is the fingerprint",
                "rot": [mp.nstr(mp.re(rot), 70), mp.nstr(mp.im(rot), 70)],
                "rel": [mp.nstr(mp.re(rel), 70), mp.nstr(mp.im(rel), 70)],
                "ordering_gap_Re_rot_minus_Re_rel": mp.nstr(gap0, 60),
                "canonical_Eprime_rot": [mp.nstr(mp.re(ep_rot), 50), mp.nstr(mp.im(ep_rot), 50)],
                "canonical_Eprime_rel": [mp.nstr(mp.re(ep_rel), 50), mp.nstr(mp.im(ep_rel), 50)],
                "boundary_resolvent_residue_rot": [[[mp.nstr(mp.re(x), 40), mp.nstr(mp.im(x), 40)] for x in row] for row in br_rot],
                "boundary_resolvent_residue_rel": [[[mp.nstr(mp.re(x), 40), mp.nstr(mp.im(x), 40)] for x in row] for row in br_rel],
            },
            "exact_parameter_charpoly_derivatives": dpolys,
            "circulation_charpoly_coefficients_in_z": [str(c) for c in sp.Poly(bp.as_expr(), z).all_coeffs()],
            "competitor_exceptional_point": epdata,
            "exact_exceptional_transition_bracket": epbracket,
            "circulation_ordering_event": ordering_event,
        }
        if name == "n12":
            exact_out["systems"][name]["capacity_utilization"] = gamma_zeta_n12(k, rot, rel)

    for filename, rows in (("pole_residue_map.csv", pole_rows), ("root_derivatives.csv", deriv_rows),
                           ("root_ordering_surfaces.csv", surface_rows), ("circulation_root_locus.csv", locus_rows)):
        with (HERE / filename).open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0]))
            w.writeheader(); w.writerows(rows)
    (HERE / "evans_exact.json").write_text(json.dumps(exact_out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"n12_gap": surface_rows[0]["gap_at_center"], "n11_gap": surface_rows[1]["gap_at_center"],
                      "pole_rows": len(pole_rows), "derivative_rows": len(deriv_rows),
                      "n12_EP": exact_out["systems"]["n12"]["competitor_exceptional_point"],
                      "n11_EP": exact_out["systems"]["n11"]["competitor_exceptional_point"]}, indent=2))


if __name__ == "__main__":
    main()
