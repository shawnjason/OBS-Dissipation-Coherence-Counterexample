"""Exact rational root isolation on slices bracketing circulation events.

This script reconstructs the emitted exact secular polynomial and invokes
SymPy's certified real/complex isolation at rational epsilon endpoints.  The
resulting rational intervals/rectangles are serialized verbatim, so ordering
and visibility claims can be checked without floating-point eigenvectors.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import sympy as sp


ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "work/theta_bridge/circulation/circulation_charpoly_exact.json"
OUT = ROOT / "work/theta_bridge/circulation/circulation_slice_isolations.json"


SLICES = {
    "leadership_below": "0.9993123774700",
    "leadership_above": "0.9993123774701",
    "competitor_EP_below": "0.9995410541966",
    "competitor_EP_above": "0.9995410541968",
    "visibility_below": "0.9909469373",
    "visibility_above": "0.9909469374",
}


def rational_decimal(value: str) -> sp.Rational:
    return sp.Rational(value)


def main() -> None:
    z, s = sp.symbols("z s")
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    secular = 0
    for record in data["coefficients"]:
        coefficient = sp.sympify(record["coefficient_in_s"], locals={"s": s})
        secular += coefficient * z ** record["z_power"]

    if OUT.exists():
        results = json.loads(OUT.read_text(encoding="utf-8")).get("slices", {})
    else:
        results = {}
    requested = set(sys.argv[1:]) if len(sys.argv) > 1 else set(SLICES)
    unknown = requested.difference(SLICES)
    if unknown:
        raise ValueError(f"unknown slice labels: {sorted(unknown)}")
    for label, epsilon_text in SLICES.items():
        if label not in requested:
            continue
        epsilon = rational_decimal(epsilon_text)
        p0 = sp.Poly(secular.subs(s, epsilon ** 2), z, domain=sp.QQ)
        isolated = p0.intervals(eps=sp.Rational(1, 10**8), all=True, fast=True)
        real_intervals, complex_rectangles = isolated
        results[label] = {
            "epsilon": epsilon_text,
            "s_exact": str(epsilon ** 2),
            "real_intervals": [
                {"interval": [str(ab[0]), str(ab[1])], "multiplicity": mult}
                for ab, mult in real_intervals
            ],
            "complex_rectangles": [
                {
                    # SymPy represents a complex isolating rectangle by its
                    # lower-left and upper-right Gaussian-rational corners.
                    "rectangle_corners": [str(corner) for corner in rect],
                    "multiplicity": mult,
                }
                for rect, mult in complex_rectangles
            ],
        }
        print(label, len(real_intervals), len(complex_rectangles), flush=True)

    OUT.write_text(json.dumps({
        "method": "exact QQ polynomial; SymPy certified real/complex root isolation",
        "requested_rectangle_width": "1e-8",
        "slices": results,
    }, indent=2), encoding="utf-8")
    print(OUT)


if __name__ == "__main__":
    main()
