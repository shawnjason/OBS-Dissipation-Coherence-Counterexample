#!/usr/bin/env python3
"""Construct and evaluate the constant-complexity role-layer Theta_(3,L,L) family."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

import numpy as np


DEFAULT = {
    "m_u": 0.0337466520320017,
    "m_v": 0.0242628895877498,
    "M1": 0.852192733775443,
    "M2": 0.00676543954319368,
    "M3": 0.0830322850616121,
    "rho": 0.7438,
    "J1": 259.799579557584,
    "J2": 25.5611346847467,
    "T1": [631.247020695388, 2114.67501856906, 313.517617104862],
    "T2_bulk": 26.1099176743375,
    "T2_exit": 31.3842281858066,
    "T3_entry": 360.210788449310,
    "T3_bulk": 321.7244351103,
}


def build(length: int, pars: dict) -> tuple[np.ndarray, np.ndarray, list[list[int]]]:
    assert length >= 2
    u, v = 0, 1
    r1, r2 = 2, 3
    p2 = list(range(4, 4 + length - 1))
    p3 = list(range(4 + length - 1, 4 + 2 * (length - 1)))
    paths = [[u, r1, r2, v], [u, *p2, v], [u, *p3, v]]
    n = 2 * length + 2
    pi = np.zeros(n)
    pi[u], pi[v] = pars["m_u"], pars["m_v"]
    pi[r1], pi[r2] = pars["M1"] * pars["rho"], pars["M1"] * (1 - pars["rho"])
    pi[p2] = pars["M2"] / (length - 1)
    pi[p3] = pars["M3"] / (length - 1)
    pi /= pi.sum()
    currents = [pars["J1"], pars["J2"], -pars["J1"] - pars["J2"]]
    traffics = [pars["T1"], [pars["T2_bulk"]] * (length - 1) + [pars["T2_exit"]],
                [pars["T3_entry"]] + [pars["T3_bulk"]] * (length - 1)]
    k = np.zeros((n, n))
    for nodes, current, ts in zip(paths, currents, traffics):
        assert len(ts) == len(nodes) - 1
        for a, b, traffic in zip(nodes, nodes[1:], ts):
            if not traffic > abs(current):
                raise ValueError("traffic must exceed absolute path current")
            k[a, b] = (traffic + current) / (2 * pi[a])
            k[b, a] = (traffic - current) / (2 * pi[b])
    return k, pi, paths


def metrics(k: np.ndarray, pi: np.ndarray) -> dict:
    q = k.copy(); np.fill_diagonal(q, -q.sum(axis=1))
    vals, vecs = np.linalg.eig(q)
    pair_indices = [i for i,z in enumerate(vals) if z.imag > 1e-8]
    it = max(pair_indices, key=lambda i: vals[i].real)
    target, v = vals[it], vecs[:, it]
    others = [z.real for z in vals if abs(z) > 1e-8 and abs(z-target) > 1e-7 and abs(z-np.conj(target)) > 1e-7]
    sigma = D = B = C = H = 0.0
    for i in range(len(k)):
        for j in range(i + 1, len(k)):
            if k[i, j] > 0:
                cur = pi[i]*k[i, j] - pi[j]*k[j, i]
                traffic = pi[i]*k[i,j] + pi[j]*k[j,i]
                sigma += cur*np.log((pi[i]*k[i, j])/(pi[j]*k[j, i]))
                D += traffic*abs(v[j]-v[i])**2
                B += cur*np.imag(np.conj(v[i])*v[j])
                C += cur*cur/traffic
                H += cur*cur*(abs(v[i])**2+abs(v[j])**2)/(2*traffic)
    Nv = float(np.sum(pi*abs(v)**2)); M=float(np.max(abs(v)**2))
    tau=sigma/(2*C); kappa=D*H/(B*B); eta_cur=Nv*C/H; eta=Nv/M
    return {"n": len(k), "target": [target.real, target.imag], "sigma": sigma,
            "Y": sigma*(-target.real)/target.imag**2,
            "visibility": target.imag+target.real,
            "leading_gap": target.real-max(others), "pmin": pi.min(),
            "tau":tau,"kappa":kappa,"eta_cur":eta_cur,"eta":eta,
            "factor_product":tau*kappa*eta_cur,
            "full_spectrum":[[float(z.real),float(z.imag)] for z in sorted(vals,key=lambda z:z.real,reverse=True)]}


def exact_payload(length: int, pars: dict) -> dict:
    F=lambda x: Fraction(str(x))
    raw=[F(pars[x]) for x in ("m_u","m_v","M1","M2","M3")]; total=sum(raw)
    pi=[raw[0]/total,raw[1]/total,F(pars["M1"])*F(pars["rho"])/total,
        F(pars["M1"])*(1-F(pars["rho"]))/total]
    pi += [F(pars["M2"])/(length-1)/total]*(length-1)
    pi += [F(pars["M3"])/(length-1)/total]*(length-1)
    paths=[[0,2,3,1],[0,*range(4,4+length-1),1],
           [0,*range(4+length-1,4+2*(length-1)),1]]
    currents=[F(pars["J1"]),F(pars["J2"]),-F(pars["J1"])-F(pars["J2"])]
    traffics=[[F(x) for x in pars["T1"]],[F(pars["T2_bulk"])]*(length-1)+[F(pars["T2_exit"])],
              [F(pars["T3_entry"])]+[F(pars["T3_bulk"])]*(length-1)]
    n=2*length+2; rates=[[Fraction(0) for _ in range(n)] for _ in range(n)]
    for nodes,J,ts in zip(paths,currents,traffics):
        for a,b,T in zip(nodes,nodes[1:],ts):
            rates[a][b]=(T+J)/(2*pi[a]);rates[b][a]=(T-J)/(2*pi[b])
    fs=lambda x:str(x.numerator) if x.denominator==1 else f"{x.numerator}/{x.denominator}"
    return {"family":"role_layer_theta","length":length,"raw_parameter_count":15,
            "constant_complexity":True,"parameters":pars,"stationary_distribution":[fs(x) for x in pi],
            "paths_0based":paths,"rate_matrix_rationals":[[fs(x) for x in row] for row in rates]}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--length", type=int, default=5);ap.add_argument("--write",action="store_true")
    args = ap.parse_args()
    rates, pi, paths = build(args.length, DEFAULT)
    result={"family": "role_layer_theta", "parameters": DEFAULT, "paths": paths,"metrics": metrics(rates, pi)}
    print(json.dumps(result, indent=2))
    if args.write:
        payload=exact_payload(args.length,DEFAULT);payload["floating_metrics"]=result["metrics"]
        out=Path(__file__).resolve().parents[1]/"data/role_layer_exact_member.json"
        out.write_text(json.dumps(payload,indent=2));print(out)
