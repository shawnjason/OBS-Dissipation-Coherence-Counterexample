# Targeted primary-source novelty audit

Disposition: **`PARTIALLY NOVEL — PRIOR COMPONENTS FOUND`**.

## Exact source finding

Gu's primary paper, [arXiv:2606.05498](https://arxiv.org/abs/2606.05498) and the published [Physical Review E article](https://doi.org/10.1103/zxw1-zdb7), explicitly introduces the stationary-mass localization factor

```
η = sum_i π_i |v_i|² / max_i |v_i|²
```

and proves `Y >= η`. Its Appendix A explicitly contains the entropy/current inequality, a traffic-weighted Cauchy--Schwarz step, the two-point complex inequality, and replacement by the global maximum amplitude.

The edgewise entropy/current inequality used by Gu is prior; Gu cites, among other sources, Shiraishi--Funo--Saito's [classical stochastic speed limit](https://doi.org/10.1103/PhysRevLett.121.070601), Shiraishi's [optimal thermodynamic uncertainty relation](https://doi.org/10.1007/s10955-021-02829-8), and Dechant's [minimum-entropy-production result](https://doi.org/10.1088/1751-8111/ac4ac0). The broader dissipation/coherence problem and eigenvalue formulation are likewise prior in [Oberreiter--Seifert--Barato](https://doi.org/10.1103/PhysRevE.106.014106).

## What is not source-new

- The endpoint bound `Y >= η` is Gu's theorem.
- The scalar entropy/current inequality and its small-affinity sharpness are prior.
- Weighted Cauchy--Schwarz and the two-point complex inequality are standard proof components.
- Merely naming ratios between adjacent inequalities would be bookkeeping.

## Source-distinct content found in this project

The searched primary sources did not display the current-weighted quantity

```
η_cur = N_v C/H,
H = sum_e [j_e²/(2T_e)] (|v_i|²+|v_j|²),
```

the universal intermediate bound `Y > η_cur >= η`, or the exact decomposition

```
Y/η = τ κ (η_cur/η).
```

These are absent from Gu's statement and proof. They are not obtained by simply retaining Gu's adjacent slacks: Gu's exact adjacent factors are `κ_Gu=CG/B²` and `s_Gu=MD/G`. The project instead proves a different phase inequality `B² <= DH`, and only the products agree:

```
κ_Gu s_Gu = κ (η_cur/η).
```

That alternative regrouping has concrete mathematical content: it exposes a current-weighted localization observable, yields a strictly sharper universal intermediate bound, supplies its equality characterization, and gives the exact criterion `Y<1 iff η_cur<1/(τκ)` for a fixed mode.

## Hostile “mere bookkeeping” judgment

The objection succeeds against the claim that all three project factors are literally Gu's adjacent proof slacks. That claim must be withdrawn. The objection fails against the narrower theorem that `η_cur` and `B²<=DH` provide a new refinement/regrouping: those objects and the sharper intermediate inequality are not explicit in Gu.

The disposition remains “partially novel” rather than “source-cleared” because the elementary ingredients and Gu endpoint theorem are prior, and a targeted search cannot exclude every equivalent formulation in the full Markov spectral literature. No materially equivalent current-weighted localization factor or three-factor equality theorem was located in the audited primary sources, including the related spectral-perturbation work of [Kolchinsky--Ohga--Ito](https://doi.org/10.1103/PhysRevResearch.6.013082) and the correlation-asymmetry literature cited by Gu.
